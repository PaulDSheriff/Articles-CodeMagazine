﻿using System.Data.Entity;
using WPF.Security;

namespace WPFSecurityBindingSample
{
  public class WpfSecurityDbContext : DbContext
  {
    public WpfSecurityDbContext() : base("name=Sandbox")
    {
    }

    public virtual DbSet<SecurityControl> ControlsToSecure { get; set; }

    protected override void OnModelCreating(DbModelBuilder modelBuilder)
    {
      // Don't let EF create migrations or check database for model consistency
      Database.SetInitializer<WpfSecurityDbContext>(null);

      base.OnModelCreating(modelBuilder);
    }
  }
}
