﻿namespace WPF.Security
{
  /// <summary>
  /// This class contains information about a XAML control
  /// </summary>
  public class XAMLControlInfo
  {
    #region Properties
    public object TheControl { get; set; }
    public string ControlName { get; set; }
    public string Tag { get; set; }
    public string ControlType { get; set; }
    public bool HasIsReadOnlyProperty { get; set; }
    #endregion

    #region ConsiderForSecurity Method
    public bool ConsiderForSecurity()
    {
      return !string.IsNullOrEmpty(ControlName) ||
             !string.IsNullOrEmpty(Tag);
    }
    #endregion

    #region ToString Override
    /// <summary>
    /// Returns either the ControlName, BindingPath, Tag or the ControlType
    /// </summary>
    /// <returns>A String</returns>
    public override string ToString()
    {
      string ret;

      if (!string.IsNullOrEmpty(ControlName)) {
        ret = ControlName;
      }
      else if (!string.IsNullOrEmpty(Tag)) {
        ret = Tag;
      }
      else {
        ret = ControlType;
      }

      return ret;
    }
    #endregion
  }
}
