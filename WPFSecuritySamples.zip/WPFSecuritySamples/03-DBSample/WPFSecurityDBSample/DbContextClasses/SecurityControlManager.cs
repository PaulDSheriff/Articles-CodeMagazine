﻿using System.Collections.Generic;
using System.Linq;
using WPF.Security;

namespace WPFSecurityDBSample
{
  public class SecurityControlManager
  {
    #region GetSecurityControls Method
    public List<SecurityControl> GetSecurityControls(string containerName)
    {
      List<SecurityControl> ret = new List<SecurityControl>();

      using (WPFSecurityDbContext db = new WPFSecurityDbContext()) {
        ret.AddRange(db.ControlsToSecure.Where(s => s.ContainerName == containerName).ToList());
      }

      return ret;
    }
    #endregion
  }
}