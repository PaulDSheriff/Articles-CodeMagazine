﻿using System.Windows;

namespace WPFSecurityDBSample
{
  public partial class App : Application
  {
  }
}
