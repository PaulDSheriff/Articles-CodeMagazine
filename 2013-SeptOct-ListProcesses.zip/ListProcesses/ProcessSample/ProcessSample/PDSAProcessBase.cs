﻿using System;
using System.ComponentModel;

namespace PDSA.Common.Monitor
{
  /// <summary>
  /// Base class for all classes in the PDSA Process Monitoring namespace.
  /// </summary>
  public class PDSAProcessBase : INotifyPropertyChanged
  {
    #region Constructor
    /// <summary>
    /// Constructor for PDSAProcessBase class
    /// </summary>
    public PDSAProcessBase()
    {
    }
    #endregion

    #region Private Variables
    private string _LastMessage = string.Empty;
    private Exception _LastException;
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set the last exception object
    /// </summary>
    public Exception LastException
    {
      get { return _LastException; }
      set
      {
        if (_LastException != value)
        {
          _LastException = value;
          RaisePropertyChanged("LastException");
        }
      }
    }

    /// <summary>
    /// Get/Set the last message generated from this class
    /// </summary>
    public string LastMessage
    {
      get { return _LastMessage; }
      set
      {
        if (_LastMessage != value)
        {
          _LastMessage = value;
          RaisePropertyChanged("LastMessage");
        }
      }
    }
    #endregion

    #region INotifyPropertyChanged
    /// <summary>
    /// The PropertyChanged Event to raise to any UI object
    /// </summary>
    public event PropertyChangedEventHandler PropertyChanged;

    /// <summary>
    /// The PropertyChanged Event to raise to any UI object
    /// The event is only invoked if data binding is used
    /// </summary>
    /// <param name="propertyName">The property name that is changing</param>
    protected void RaisePropertyChanged(string propertyName)
    {
      PropertyChangedEventHandler handler = this.PropertyChanged;
      if (handler != null)
      {
        // Get the cached event args.
        PropertyChangedEventArgs args =
          new PropertyChangedEventArgs(propertyName);

        // Raise the PropertyChanged event.
        handler(this, args);
      }
    }
    #endregion
  }
}
