﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Windows;

using PDSA.Common.Monitor;

namespace ProcessSample
{
  public partial class Sample02 : Window
  {
    public Sample02()
    {
      InitializeComponent();
    }

    private void btnLoad_Click(object sender, RoutedEventArgs e)
    {
      if (string.IsNullOrEmpty(txtMachineName.Text))
        lstProcesses.DataContext = LoadAllProcesses(string.Empty);
      else
        lstProcesses.DataContext = LoadAllProcesses(txtMachineName.Text.Trim());
    }

    private ObservableCollection<PDSAProcess> LoadAllProcesses(string machineName)
    {
      Process[] list = null;
      ObservableCollection<PDSAProcess> ProcessList =
        new ObservableCollection<PDSAProcess>();

      try
      {
        // Get all Processes using the .NET Process class
        if (string.IsNullOrEmpty(machineName))
          list = Process.GetProcesses();
        else
          list = Process.GetProcesses(machineName);

        foreach (Process prc in list)
        {
          PDSAProcess proc = new PDSAProcess();

          // Store process name
          proc.ProcessName = prc.ProcessName;
          // Set machine name, this also sets the IsRemote property
          proc.MachineName = prc.MachineName;
          // Store the actual 'Process' object
          proc.TheProcess = prc;
          // Store the ID
          proc.Id = prc.Id;
          // 'Responding' Property is not supported on remote machines
          if (!proc.IsRemote)
            proc.IsResponding = prc.Responding;
          // Store memory usage
          proc.Memory = prc.WorkingSet64;

          // Add to collection
          ProcessList.Add(proc);
        }

        // Sort the list
        ProcessList = new ObservableCollection<PDSAProcess>(ProcessList.OrderBy(p => p.ProcessName));
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }

      return ProcessList;
    }
  }
}
