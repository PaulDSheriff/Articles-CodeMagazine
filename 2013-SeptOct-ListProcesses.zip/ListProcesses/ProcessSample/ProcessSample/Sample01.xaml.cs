﻿using System;
using System.Diagnostics;
using System.Windows;

namespace ProcessSample
{
  public partial class Sample01 : Window
  {
    public Sample01()
    {
      InitializeComponent();
    }
    
    private void btnLoad_Click(object sender, RoutedEventArgs e)
    {
      Process[] list = null;
      string machineName = string.Empty;

      if (!string.IsNullOrEmpty(txtMachineName.Text))
        machineName = txtMachineName.Text;

      try
      {
        // Get all Processes using the .NET Process class
        if (string.IsNullOrEmpty(machineName))
          list = Process.GetProcesses();
        else
          list = Process.GetProcesses(machineName);
        
        lstProcesses.DataContext = list;
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
    }
  }
}
