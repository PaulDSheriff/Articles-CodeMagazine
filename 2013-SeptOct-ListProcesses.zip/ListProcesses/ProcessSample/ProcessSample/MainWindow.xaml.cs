﻿using System;
using System.Windows;

namespace ProcessSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnSample01_Click(object sender, RoutedEventArgs e)
    {
      Sample01 win = new Sample01();

      win.Show();
    }

    private void btnSample02_Click(object sender, RoutedEventArgs e)
    {
      Sample02 win = new Sample02();

      win.Show();
    }
  }
}