﻿using System;
using System.Diagnostics;

namespace PDSA.Common.Monitor
{
  /// <summary>
  /// This class holds a single Process that is running in Windows
  /// </summary>
  public class PDSAProcess : PDSAProcessBase
  {
    #region Constructor
    /// <summary>
    /// Constructor for the PDSAProcess Class
    /// </summary>
    public PDSAProcess() : base()
    {
    }
    #endregion

    #region Private Variables
    private int _Id = 0;
    private long _Memory = 0;
    private string _ProcessName = string.Empty;
    private string _MemoryInMB = string.Empty;
    private bool? _IsResponding = null;
    private Process _TheProcess = null;
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set Id
    /// </summary>
    public int Id
    {
      get { return _Id; }
      set
      {
        if (_Id != value)
        {
          _Id = value;
          RaisePropertyChanged("Id");
        }
      }
    }

    /// <summary>
    /// Get/Set ProcessName
    /// </summary>
    public string ProcessName
    {
      get { return _ProcessName; }
      set
      {
        if (_ProcessName != value)
        {
          _ProcessName = value;
          RaisePropertyChanged("ProcessName");
        }
      }
    }

    /// <summary>
    /// Get/Set Memory
    /// </summary>
    public long Memory
    {
      get { return _Memory; }
      set
      {
        if (_Memory != value)
        {
          _Memory = value;
          RaisePropertyChanged("Memory");
        }
      }
    }

    /// <summary>
    /// Get the Memory in KB
    /// </summary>
    public string MemoryInKB
    {
      get
      {
        string ret = "n/a";
        decimal value = 0;

        if (Memory > 0)
        {
          value = Convert.ToDecimal(Memory) / 1024;
          ret = value.ToString("###,###,###") + "kb";
        }

        return ret;
      }
      set { string temp = value; }
    }

    /// <summary>
    /// Get the Memory in MB
    /// </summary>
    public string MemoryInMB
    {
      get
      {
        string ret = "n/a";
        decimal value = 0;

        if (Memory > 0)
        {
          value = Convert.ToDecimal(Memory) / 1024 / 1024;
          ret = value.ToString("###,###,##0.0") + "mb";
        }

        return ret;
      }
      set { string temp = value; }
    }
    
    /// <summary>
    /// Get/Set Whether or not the EXE is Responding
    /// NOTE: This property may not be accessible when accessing a remote machine.
    /// </summary>
    public bool? IsResponding
    {
      get { return _IsResponding; }
      set
      {
        if (_IsResponding != value)
        {
          _IsResponding = value;
          RaisePropertyChanged("IsResponding");
        }
      }
    }

    /// <summary>
    /// Get/Set the actual Windows process object
    /// </summary>
    public Process TheProcess
    {
      get { return _TheProcess; }
      set
      {
        if (_TheProcess != value)
        {
          _TheProcess = value;
          RaisePropertyChanged("TheProcess");
        }
      }
    }
    #endregion

    #region ToString Override
    /// <summary>
    /// Returns ProcessName plus MemoryInMB
    /// </summary>
    /// <returns>ProcessName plus MemoryInMB</returns>
    public override string ToString()
    {
      return ProcessName + " (" + MemoryInMB + ")";
    }
    #endregion
  }
}
