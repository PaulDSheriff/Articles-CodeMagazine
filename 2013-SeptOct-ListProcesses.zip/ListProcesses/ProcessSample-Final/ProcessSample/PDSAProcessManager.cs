﻿using System;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;

namespace PDSA.Common.Monitor
{
  /// <summary>
  /// This class will allow you to retrieve a list of processes running on a specified machine.
  /// </summary>
  public class PDSAProcessManager : PDSAProcessBase
  {
    #region Constructor
    /// <summary>
    /// Constructor for PDSAProcessManager Class
    /// </summary>
    public PDSAProcessManager()
      : base()
    {
    }
    #endregion

    #region Private Variables
    private const string PERF_COUNTER_MEMORY = "Working Set - Private";

    private ObservableCollection<PDSAProcess> _ProcessList = new ObservableCollection<PDSAProcess>();
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set the collection of processes
    /// </summary>
    public ObservableCollection<PDSAProcess> ProcessList
    {
      get { return _ProcessList; }
      set
      {
        _ProcessList = value;
        RaisePropertyChanged("ProcessList");
      }
    }
    #endregion

    #region LoadAllProcesses Methods
    /// <summary>
    /// Loads all processes currently running
    /// </summary>
    /// <returns>A collection of PDSAProcess objects</returns>
    public ObservableCollection<PDSAProcess> LoadAllProcesses()
    {
      return LoadAllProcesses(this.MachineName);
    }

    /// <summary>
    /// Loads all processes currently running on the specified machine name
    /// </summary>
    /// <param name="machineName">The machine to load processes from</param>
    /// <returns>A collection of PDSAProcess objects</returns>
    public ObservableCollection<PDSAProcess> LoadAllProcesses(string machineName)
    {
      Process[] list = null;

      // Set MachineName property
      // Also sets the IsRemote Property
      MachineName = machineName;

      LastMessage = string.Empty;
      LastException = null;
      try
      {
        ProcessList.Clear();

        LastMessage = "Reading all Processes on machine: " + this.MachineName;
        // Get all Processes using the .NET Process class
        if (this.IsRemote)
          list = Process.GetProcesses(this.MachineName);
        else
          list = Process.GetProcesses();

        // Create Collection using LINQ
        ProcessList =
          new ObservableCollection<PDSAProcess>(from prc in list
                                                select new PDSAProcess
                                                {
                                                  MachineName = this.MachineName,
                                                  IsRemote = this.IsRemote,
                                                  TheProcess = prc,
                                                  ProcessName = prc.ProcessName,
                                                  Id = prc.Id,
                                                  IsResponding = (this.IsRemote ? default(bool?) : prc.Responding),
                                                  Memory = GetMemory(prc)
                                                });

        // Sort the list
        ProcessList = new ObservableCollection<PDSAProcess>
          (ProcessList.OrderBy(p => p.ProcessName));
      }
      catch (Exception ex)
      {
        LastException = ex;
        LastMessage = ex.Message;
      }

      return ProcessList;
    }
    #endregion

    #region GetMemory Method
    /// <summary>
    /// Attempts to get the memory of the specified process using the Performance Counter 'Working Set - Private' which is the same one reported by Task Manager.
    /// However, if attempting to read processes on another machine then this counter may not be accessible as you must be a member of the Performance Monitor Users group or have Administrator privileges.
    /// If this process can't get memory from the Performance Counter, it will get the WorkingSet property from the Process object.
    /// </summary>
    /// <param name="prc">A Process object</param>
    /// <returns>Estimated Memory Used</returns>
    protected virtual long GetMemory(Process prc)
    {
      PerformanceCounter pc = null;
      long ret = -1;

      try
      {
        if (!this.IsRemote)
          pc = new PerformanceCounter("Process", PERF_COUNTER_MEMORY, prc.ProcessName);
        else
          pc = new PerformanceCounter("Process", PERF_COUNTER_MEMORY,
                prc.ProcessName, this.MachineName);

        if (pc != null)
          ret = pc.RawValue;
      }
      catch (Exception ex)
      {
        LastException = ex;
        LastMessage = ex.Message + Environment.NewLine +
          "Attempting to access performance counter on machine: " + this.MachineName;
      }
      finally
      {
        if (pc != null)
        {
          pc.Close();
          pc.Dispose();
        }
      }

      // Can't get memory from the Performance Counter
      // Get the WorkingSet from the Process
      if (ret == -1)
      {
        try
        {
          ret = prc.WorkingSet64;
        }
        catch
        {
        }
      }

      return ret;
    }
    #endregion
  }
}