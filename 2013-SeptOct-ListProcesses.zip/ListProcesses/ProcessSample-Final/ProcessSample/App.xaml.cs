﻿using System.Windows;

namespace ProcessSample
{
  public partial class App : Application
  {
  }
}
