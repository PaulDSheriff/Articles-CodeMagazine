﻿using System.Windows;

using PDSA.Common.Monitor;

namespace ProcessSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();

      _ViewModel = (PDSAProcessManager)this.Resources["viewModel"];
    }

    PDSAProcessManager _ViewModel = null;

    private void btnLoad_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.LoadAllProcesses();
    }
  }
}
