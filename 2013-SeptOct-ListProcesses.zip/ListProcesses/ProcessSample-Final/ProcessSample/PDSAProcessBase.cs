﻿using System;
using System.ComponentModel;

namespace PDSA.Common.Monitor
{
  /// <summary>
  /// Base class for all classes in the PDSA Process Monitoring namespace.
  /// </summary>
  public class PDSAProcessBase : INotifyPropertyChanged
  {
    #region Constructor
    /// <summary>
    /// Constructor for PDSAProcessBase class
    /// </summary>
    public PDSAProcessBase()
      : base()
    {
    }
    #endregion

    #region Private Variables
    private string _MachineName = string.Empty;
    private bool _IsRemote = false;
    private string _LastMessage = string.Empty;
    private Exception _LastException;
    #endregion

    #region Public Properties
    /// <summary>
    /// Get/Set the Machine Name
    /// </summary>
    public string MachineName
    {
      get { return _MachineName; }
      set
      {
        SetMachineName(value);
        RaisePropertyChanged("MachineName");
      }
    }

    /// <summary>
    /// Get/Set Whether or not this process is on a remote machine
    /// </summary>
    public bool IsRemote
    {
      get { return _IsRemote; }
      set
      {
        if (_IsRemote != value)
        {
          _IsRemote = value;
          RaisePropertyChanged("IsRemote");
        }
      }
    }

    /// <summary>
    /// Get/Set the last exception object
    /// </summary>
    public Exception LastException
    {
      get { return _LastException; }
      set
      {
        if (_LastException != value)
        {
          _LastException = value;
          RaisePropertyChanged("LastException");
        }
      }
    }

    /// <summary>
    /// Get/Set the last message generated from this class
    /// </summary>
    public string LastMessage
    {
      get { return _LastMessage; }
      set
      {
        if (_LastMessage != value)
        {
          _LastMessage = value;
          RaisePropertyChanged("LastMessage");
        }
      }
    }
    #endregion

    #region INotifyPropertyChanged
    /// <summary>
    /// The PropertyChanged Event to raise to any UI object
    /// </summary>
    public event PropertyChangedEventHandler PropertyChanged;

    /// <summary>
    /// The PropertyChanged Event to raise to any UI object
    /// The event is only invoked if data binding is used
    /// </summary>
    /// <param name="propertyName">The property name that is changing</param>
    protected void RaisePropertyChanged(string propertyName)
    {
      PropertyChangedEventHandler handler = this.PropertyChanged;
      if (handler != null)
      {
        // Get the cached event args.
        PropertyChangedEventArgs args =
          new PropertyChangedEventArgs(propertyName);

        // Raise the PropertyChanged event.
        handler(this, args);
      }
    }
    #endregion

    #region SetMachineName Method
    private void SetMachineName(string machineName)
    {
      if (string.IsNullOrEmpty(machineName) ||
          machineName == "." ||
          machineName.ToLower() == Environment.MachineName.ToLower())
      {
        _MachineName = Environment.MachineName;
        IsRemote = false;
      }
      else
      {
        _MachineName = machineName;
        IsRemote = true;
      }
    }
    #endregion
  }
}
