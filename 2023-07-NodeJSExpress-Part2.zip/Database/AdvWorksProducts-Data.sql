USE [AdvWorksProducts]
GO
SET IDENTITY_INSERT [dbo].[Product] ON 
GO
INSERT [dbo].[Product] ([ProductID], [Name], [ProductNumber], [Color], [StandardCost], [ListPrice], [ModifiedDate]) VALUES (345, N'HL Road Frame - Red, 58', N'FR-R92R-58', N'Red', 1059.0000, 1500.0000, CAST(N'2023-02-10T15:36:05.537' AS DateTime))
GO
INSERT [dbo].[Product] ([ProductID], [Name], [ProductNumber], [Color], [StandardCost], [ListPrice], [ModifiedDate]) VALUES (346, N'Sport-100 Helmet, Red', N'HL-U509-R', N'Red', 13.0800, 34.9900, CAST(N'2004-03-11T10:01:36.000' AS DateTime))
GO
INSERT [dbo].[Product] ([ProductID], [Name], [ProductNumber], [Color], [StandardCost], [ListPrice], [ModifiedDate]) VALUES (347, N'Sport-100 Helmet, Black', N'HL-U509', N'Black', 13.0863, 34.9900, CAST(N'2004-03-11T10:01:36.827' AS DateTime))
GO
INSERT [dbo].[Product] ([ProductID], [Name], [ProductNumber], [Color], [StandardCost], [ListPrice], [ModifiedDate]) VALUES (348, N'Mountain Bike Socks, M', N'SO-B909-M', N'White', 3.3963, 9.5000, CAST(N'2004-03-11T10:01:36.827' AS DateTime))
GO
INSERT [dbo].[Product] ([ProductID], [Name], [ProductNumber], [Color], [StandardCost], [ListPrice], [ModifiedDate]) VALUES (349, N'Mountain Bike Socks, L', N'SO-B909-L', N'White', 3.3963, 19.5000, CAST(N'2004-03-11T10:01:36.827' AS DateTime))
GO
INSERT [dbo].[Product] ([ProductID], [Name], [ProductNumber], [Color], [StandardCost], [ListPrice], [ModifiedDate]) VALUES (350, N'Sport-100 Helmet, Blue', N'HL-U509-B', N'Blue', 13.0863, 99.9900, CAST(N'2004-03-11T10:01:36.827' AS DateTime))
GO
INSERT [dbo].[Product] ([ProductID], [Name], [ProductNumber], [Color], [StandardCost], [ListPrice], [ModifiedDate]) VALUES (351, N'AWC Logo Cap', N'CA-1098', N'Multi', 7.0000, 9.0000, CAST(N'2023-02-10T19:15:07.877' AS DateTime))
GO
INSERT [dbo].[Product] ([ProductID], [Name], [ProductNumber], [Color], [StandardCost], [ListPrice], [ModifiedDate]) VALUES (352, N'Long-Sleeve Logo Jersey, S', N'LJ-0192-S', N'Multi', 38.4923, 49.9900, CAST(N'2004-03-11T10:01:36.827' AS DateTime))
GO
INSERT [dbo].[Product] ([ProductID], [Name], [ProductNumber], [Color], [StandardCost], [ListPrice], [ModifiedDate]) VALUES (353, N'Long-Sleeve Logo Jersey, M', N'LJ-0192-M', N'Multi', 38.4923, 45.9900, CAST(N'2004-03-11T10:01:36.827' AS DateTime))
GO
INSERT [dbo].[Product] ([ProductID], [Name], [ProductNumber], [Color], [StandardCost], [ListPrice], [ModifiedDate]) VALUES (354, N'Long-Sleeve Logo Jersey, L', N'LJ-0192-L', N'Multi', 38.4923, 49.9900, CAST(N'2004-03-11T10:01:36.827' AS DateTime))
GO
INSERT [dbo].[Product] ([ProductID], [Name], [ProductNumber], [Color], [StandardCost], [ListPrice], [ModifiedDate]) VALUES (355, N'Long-Sleeve Logo Jersey, XL', N'LJ-0192-X', N'Multi', 38.4923, 59.9900, CAST(N'2004-03-11T10:01:36.827' AS DateTime))
GO
INSERT [dbo].[Product] ([ProductID], [Name], [ProductNumber], [Color], [StandardCost], [ListPrice], [ModifiedDate]) VALUES (356, N'HL Road Frame - Red, 62', N'FR-R92R-62', N'Red', 868.6342, 1431.5000, CAST(N'2004-03-11T10:01:36.827' AS DateTime))
GO
INSERT [dbo].[Product] ([ProductID], [Name], [ProductNumber], [Color], [StandardCost], [ListPrice], [ModifiedDate]) VALUES (357, N'HL Road Frame - Red, 44', N'FR-R92R-44', N'Red', 868.6342, 1431.5000, CAST(N'2004-03-11T10:01:36.827' AS DateTime))
GO
INSERT [dbo].[Product] ([ProductID], [Name], [ProductNumber], [Color], [StandardCost], [ListPrice], [ModifiedDate]) VALUES (358, N'HL Road Frame - Red, 48', N'FR-R92R-48', N'Red', 868.6342, 1451.5000, CAST(N'2004-03-11T10:01:36.827' AS DateTime))
GO
INSERT [dbo].[Product] ([ProductID], [Name], [ProductNumber], [Color], [StandardCost], [ListPrice], [ModifiedDate]) VALUES (359, N'HL Road Frame - Red, 52', N'FR-R92R-52', N'Red', 868.6300, 1431.5000, CAST(N'2004-03-11T10:01:36.827' AS DateTime))
GO
SET IDENTITY_INSERT [dbo].[Product] OFF
GO
