﻿using Common.Library;

namespace WPF.Sample.ViewModelLayer
{
  public class UserFeedbackViewModel : ViewModelBase
  {
    public UserFeedbackViewModel() : base()
    {
      DisplayStatusMessage("Submit User Feedback");
    }
  }
}
