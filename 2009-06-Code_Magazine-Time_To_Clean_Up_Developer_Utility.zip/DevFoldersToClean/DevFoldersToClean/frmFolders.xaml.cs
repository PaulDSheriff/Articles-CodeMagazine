﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DevFoldersToClean
{
  /// <summary>
  /// Interaction logic for Window1.xaml
  /// </summary>
  public partial class frmFolders : Window
  {
    public frmFolders()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      DevFolders folders = new DevFolders();

      lblOS.Content = Environment.OSVersion.Platform;
      lblVer.Content = Environment.OSVersion.VersionString;
      if (IntPtr.Size == 4)
        lblSize.Content = "32 bit";
      else
        lblSize.Content = "64 bit";

      folders.LoadFolders();

      this.DataContext = folders;
    }

    private string GetOSName()
    {
      System.OperatingSystem os = System.Environment.OSVersion;
      string osName = "Unknown";
      switch (os.Platform)
      {
        case System.PlatformID.Win32Windows:
          switch (os.Version.Minor)
          {
            case 0:
              osName = "Windows 95";
              break;
            case 10:
              osName = "Windows 98";
              break;
            case 90:
              osName = "Windows ME";
              break;
          }
          break;
        case System.PlatformID.Win32NT:
          switch (os.Version.Major)
          {
            case 3:
              osName = "Windws NT 3.51";
              break;
            case 4:
              osName = "Windows NT 4";
              break;
            case 5:
              if (os.Version.Minor == 0)
                osName = "Windows 2000";
              else if (os.Version.Minor == 1)
                osName = "Windows XP";
              else if (os.Version.Minor == 2)
                osName = "Windows Server 2003";
              break;
            case 6:
              osName = "Longhorn";
              break;
          }
          break;
      }

      return osName + ", " + os.Version.ToString();
    }
  }
}