﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;

namespace EntityCollectionsReflection
{
  public class ManagerBase
  {
    #region BuildCollection (DataTable) Method
    public List<T> BuildCollection<T>(Type typ, DataTable dt)
    {
      List<T> ret = new List<T>();
      T entity;

      // Get all the properties in Entity Class
      PropertyInfo[] props = typ.GetProperties();

      foreach (DataRow dr in dt.Rows)
      {
        // Create new instance of Entity
        entity = Activator.CreateInstance<T>();

        // Set all properties from the column names
        // NOTE: This assumes your column names are the 
        //       same name as your class property names
        foreach (PropertyInfo col in props)
        {
          if (dr[col.Name] == DBNull.Value)
            col.SetValue(entity, null, null);
          else
            col.SetValue(entity, dr[col.Name], null);
        }

        ret.Add(entity);
      }

      return ret;
    }
    #endregion

    #region BuildCollection (DataReader) Method
    public List<T> BuildCollection<T>(Type typ, SqlDataReader rdr)
    {
      List<T> ret = new List<T>();
      T entity;

      // Get all the properties in Entity Class
      PropertyInfo[] props = typ.GetProperties();

      while (rdr.Read())
      {
        // Create new instance of Entity
        entity = Activator.CreateInstance<T>();

        // Set all properties from the column names
        // NOTE: This assumes your column names are the 
        //       same name as your class property names
        foreach (PropertyInfo col in props)
        {
          if (rdr[col.Name].Equals(DBNull.Value))
            col.SetValue(entity, null, null);
          else
            col.SetValue(entity, rdr[col.Name], null);
        }

        ret.Add(entity);
      }

      return ret;
    }
    #endregion
  }
}
