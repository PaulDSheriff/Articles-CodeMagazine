﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Collections.Generic;

namespace EntityCollections2
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnDataReader_Click(object sender, RoutedEventArgs e)
    {
      lstData.DataContext = GetProducts();
    }

    private List<Product> GetProducts()
    {
      SqlCommand cmd = null;
      List<Product> ret = new List<Product>();
      Product entity = null;

      cmd = new SqlCommand("SELECT * FROM Product");
      using (cmd.Connection = new SqlConnection("Server=Localhost;Database=Sandbox;Integrated Security=Yes"))
      {
        cmd.Connection.Open();
        using (var rdr = cmd.ExecuteReader(CommandBehavior.CloseConnection))
        {
          while (rdr.Read())
          {
            entity = new Product();

            // ProductId is a NOT NULL field
            entity.ProductId = Convert.ToInt32(rdr["ProductId"]);
            // Strings automatically convert to "" if null.
            entity.ProductName = rdr["ProductName"].ToString();
            entity.IntroductionDate =
                    DataConvert.ConvertTo<DateTime>(rdr["IntroductionDate"],
                      default(DateTime));
            entity.Cost =
                    DataConvert.ConvertTo<decimal>(rdr["Cost"],
                      default(decimal));
            entity.Price =
                    DataConvert.ConvertTo<decimal>(rdr["Price"],
                      default(decimal));
            entity.IsDiscontinued =
                    DataConvert.ConvertTo<bool>(rdr["IsDiscontinued"],
                      default(bool));

            ret.Add(entity);
          }
        }
      }

      return ret;
    }

  }
}
