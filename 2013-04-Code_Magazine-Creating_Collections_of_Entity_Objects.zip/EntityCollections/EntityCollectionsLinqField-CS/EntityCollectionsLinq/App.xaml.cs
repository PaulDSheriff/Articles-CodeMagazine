﻿using System.Windows;

namespace EntityCollectionsLinq
{
	public partial class App : Application
	{
	}
}
