﻿Imports System.Data
Imports System.Data.SqlClient

Class MainWindow

  Private Sub btnDataReader_Click(sender As System.Object, e As System.Windows.RoutedEventArgs)
    lstData.DataContext = GetProducts()
  End Sub

  Private Function GetProducts() As List(Of Product)
    Dim cmd As SqlCommand = Nothing
    Dim ret As New List(Of Product)()
    Dim entity As Product = Nothing

    cmd = New SqlCommand("SELECT * FROM Product")
    Using cnn As SqlConnection = New SqlConnection("Server=Localhost;Database=Sandbox;Integrated Security=Yes")
      cmd.Connection = cnn
      cmd.Connection.Open()
      Using rdr As SqlDataReader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
        While rdr.Read()
          entity = New Product()

          ' ProductId is a NOT NULL field
          entity.ProductId = Convert.ToInt32(rdr("ProductId"))
          ' Strings automatically convert to "" if null.
          entity.ProductName = rdr("ProductName").ToString()
          entity.IntroductionDate = DataConvert.ConvertTo(Of DateTime)(rdr("IntroductionDate"), DateTime.MinValue)
          entity.Cost = DataConvert.ConvertTo(Of Decimal)(rdr("Cost"), 0D)
          entity.Price = DataConvert.ConvertTo(Of Decimal)(rdr("Price"), 0D)
          entity.IsDiscontinued = DataConvert.ConvertTo(Of Boolean)(rdr("IsDiscontinued"), False)

          ret.Add(entity)
        End While
      End Using
    End Using

    Return ret
  End Function

End Class
