﻿Imports System.Data.SqlClient
Imports System.Reflection

Public Class ProductHardCodedManager
  Public Function GetProducts() As List(Of Product)
    Dim cmd As SqlCommand = Nothing
    Dim ret As New List(Of Product)()
    Dim entity As Product = Nothing

    ' Get all the properties in Entity Class
    Dim props As PropertyInfo() = GetType(Product).GetProperties()

    cmd = New SqlCommand("SELECT * FROM Product")
    Using cnn = New SqlConnection(AppSettings.Instance.ConnectString)
      cmd.Connection = cnn
      cmd.Connection.Open()
      Using rdr = cmd.ExecuteReader()
        While rdr.Read()
          ' Create new instance of Product Class
          entity = New Product()

          ' Set all properties from the column names
          ' NOTE: This assumes your column names are the 
          '       same name as your class property names
          For Each col As PropertyInfo In props
            ' The following is the slow method of setting properties
            'If rdr(col.Name) Is DBNull.Value Then
            '  GetType(Product).InvokeMember(col.Name, BindingFlags.SetProperty, Type.DefaultBinder, entity, New [Object]() {Nothing})
            'Else
            '  GetType(Product).InvokeMember(col.Name, BindingFlags.SetProperty, Type.DefaultBinder, entity, New [Object]() {rdr(col.Name)})
            'End If

            If rdr(col.Name).Equals(DBNull.Value) Then
              col.SetValue(entity, Nothing, Nothing)
            Else
              col.SetValue(entity, rdr(col.Name), Nothing)
            End If
          Next

          ret.Add(entity)
        End While
      End Using
    End Using

    Return ret
  End Function
End Class
