﻿Imports System.Reflection

Class MainWindow

#Region "Window_Loaded Event Procedure"
  Private Sub Window_Loaded(sender As Object, e As RoutedEventArgs)
    DisplayRowsRead()
  End Sub
#End Region

#Region "DisplayRowsRead Method"
  Private Sub DisplayRowsRead()
    If lstData.Items.Count > 0 Then
      txtRowsRead.Text = lstData.Items.Count.ToString("###,###")
    Else
      txtRowsRead.Text = "0"
    End If
  End Sub
#End Region

  Private Sub btnHardCoded_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnHardCoded.Click
    Dim mgr As New ProductHardCodedManager()

    lstData.View = PDSAListView.CreateGridViewColumns(GetType(Product))
    lstData.DataContext = mgr.GetProducts()
    DisplayRowsRead()
  End Sub

  Private Sub btnDataTable_Click(sender As Object, e As RoutedEventArgs) Handles btnDataTable.Click
    Dim mgr As New ProductManager()

    lstData.View = PDSAListView.CreateGridViewColumns(GetType(Product))
    lstData.DataContext = mgr.GetProductsDataTable()
    DisplayRowsRead()
  End Sub

  Private Sub btnDataReader_Click(sender As Object, e As RoutedEventArgs) Handles btnDataReader.Click
    Dim mgr As New ProductManager()

    lstData.View = PDSAListView.CreateGridViewColumns(GetType(Product))
    lstData.DataContext = mgr.GetProductsDataReader()
    DisplayRowsRead()
  End Sub

  Private Sub btnSetProperty1_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnSetProperty1.Click
    Dim entity As New Product()

    GetType(Product).InvokeMember("ProductName", _
       BindingFlags.SetProperty, _
         Type.DefaultBinder, entity, _
            New Object() {"A New Product"})

    MessageBox.Show(entity.ProductName)
  End Sub

  Private Sub btnSetProperty2_Click(sender As System.Object, e As System.Windows.RoutedEventArgs) Handles btnSetProperty2.Click
    Dim entity As New Product()

    GetType(Product).GetProperty("ProductName"). _
       SetValue(entity, "A New Product", Nothing)

    MessageBox.Show(entity.ProductName)
  End Sub
End Class
