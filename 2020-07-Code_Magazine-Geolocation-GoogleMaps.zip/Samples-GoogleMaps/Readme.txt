﻿To run this sample
---------------------------------
You need to get your own Google Maps Developer Key. Read the following:
    https://developers.google.com/maps/documentation/javascript/get-api-key

Replace any occurence of AIzaSyB..... in this project with your developer key 

npm install
npm run dev


Google Maps Samples
-------------------------------------------------------
01 - Send coordinates to google maps
02 - Embed google map on web page
    Requires a Google developer key
03 - Add a marker
    Added addMarker(mapObject) method
04 - Add multiple markers
    Create an array of map definition objects
05 - Center Map to Show All Markers
06 - Display one info window at a time
    Added 'infoWindow' private variable
      Only use one to display only one info window at a time
    Added addInfoWindow() method
07 - Display multiple info windows



Resources
-----------------------------------------------------------------------
https://developers.google.com/maps/documentation/javascript/examples

Markers
https://cloud.google.com/maps-platform/pricing/?_ga=2.97117535.1561004022.1584909684-1428491045.1582637298

Display Text Directions
https://developers.google.com/maps/documentation/javascript/examples/directions-panel

Rectangles
https://developers.google.com/maps/documentation/javascript/examples/rectangle-simple
