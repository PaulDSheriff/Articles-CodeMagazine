﻿using System.Windows;

namespace WPFToWCF
{
	public partial class App : Application
	{
	}
}
