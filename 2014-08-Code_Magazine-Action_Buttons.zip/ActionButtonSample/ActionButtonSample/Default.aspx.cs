﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;

namespace ActionButtonSample
{
  public partial class Default : System.Web.UI.Page
  {
    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void discontinueButton_ServerClick(object sender, EventArgs e)
    {
      ProductManager mgr = new ProductManager();

      // Get list of products selected
      List<int> list = GetSelectedProducts();

      // Call method to discontinue list of Product IDs
      mgr.Discontinue(list);

      System.Diagnostics.Debugger.Break();
    }

    protected void deleteButton_ServerClick(object sender, EventArgs e)
    {
      ProductManager mgr = new ProductManager();

      // Get list of products selected
      List<int> list = GetSelectedProducts();

      // Call method to discontinue list of Product IDs
      mgr.Delete(list);

      System.Diagnostics.Debugger.Break();
    }

    /// <summary>
    /// Get list of selected Product IDs
    /// </summary>
    /// <returns>A list of integers (Product IDs)</returns>
    protected List<int> GetSelectedProducts()
    {
      List<int> list = new List<int>();

      // Loop through all rows in the GridView
      foreach (GridViewRow row in grdProducts.Rows)
      {
        if (row.RowType == DataControlRowType.DataRow)
        {
          // Get the checkbox
          CheckBox chkRow = (row.Cells[0].FindControl("chkSelect") as CheckBox);
          if (chkRow.Checked)
          {
            // Get Product ID from checkbox attribute and add to list
            list.Add(Convert.ToInt32(chkRow.Attributes["ProductId"]));
          }
        }
      }

      return list;
    }
  }
}