﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace ActionButtonSample
{
  public class ProductManager
  {
    #region GetProducts Method
    /// <summary>
    /// Get all Products from Product table
    /// </summary>
    /// <returns>A List of Product objects</returns>
    public List<Product> GetProducts()
    {
      DataTable dt = new DataTable();
      SqlDataAdapter da = null;

      da = new SqlDataAdapter("SELECT * FROM Product",
                              AppSettings.Instance.ConnectString);

      da.Fill(dt);

      var query = 
        (from dr in dt.AsEnumerable()
          select new Product
          {
            ProductId = Convert.ToInt32(dr["ProductId"]),
            ProductName = dr["ProductName"].ToString(),
            IntroductionDate =
              DataConvert.ConvertTo<DateTime>(dr["IntroductionDate"],
                default(DateTime)),
            Cost = DataConvert.ConvertTo<decimal>(
              dr["Cost"], default(decimal)),
            Price = DataConvert.ConvertTo<decimal>(
              dr["Price"], default(decimal)),
            IsDiscontinued = DataConvert.ConvertTo<bool>(
              dr["IsDiscontinued"], default(bool))
          });

      return query.ToList();
    }
    #endregion

    #region GetProduct Method
    /// <summary>
    /// Get a single Product from the Product table
    /// </summary>
    /// <param name="productId">A Product ID to find</param>
    /// <returns>A Product object</returns>
    public Product GetProduct(int productId)
    {
      DataTable dt = new DataTable();
      SqlDataAdapter da = null;
      SqlCommand cmd = null;

      cmd = new SqlCommand("SELECT * FROM Product WHERE ProductId = @ProductId",
        new SqlConnection(AppSettings.Instance.ConnectString));
      cmd.Parameters.Add(new SqlParameter("@ProductId", productId));

      da = new SqlDataAdapter(cmd);
      da.Fill(dt);

      Product entity =
        (from dr in dt.AsEnumerable()
         select new Product
         {
           ProductId = Convert.ToInt32(dr["ProductId"]),
           ProductName = dr["ProductName"].ToString(),
           IntroductionDate =
             DataConvert.ConvertTo<DateTime>(dr["IntroductionDate"],
               default(DateTime)),
           Cost = DataConvert.ConvertTo<decimal>(
             dr["Cost"], default(decimal)),
           Price = DataConvert.ConvertTo<decimal>(
             dr["Price"], default(decimal)),
           IsDiscontinued = DataConvert.ConvertTo<bool>(
             dr["IsDiscontinued"], default(bool))
         }).FirstOrDefault();
      
      return entity;
    }
    #endregion

    #region Insert Method
    /// <summary>
    /// Insert a new Product
    /// </summary>
    /// <param name="entity">The product to insert</param>
    /// <returns>True if successful, false otherwise</returns>
    public bool Insert(Product entity)
    {
      return true;
    }
    #endregion

    #region Update Method
    /// <summary>
    /// Update an Existing Product
    /// </summary>
    /// <param name="entity">The product to update</param>
    /// <returns>True if successful, false otherwise</returns>
    public bool Update(Product entity)
    {
      return true;
    }
    #endregion

    #region Delete Methods
    /// <summary>
    /// Delete an Existing Product
    /// </summary>
    /// <param name="entity">The product to delete</param>
    /// <returns>True if successful, false otherwise</returns>
    public bool Delete(Product entity)
    {
      return true;
    }

    /// <summary>
    /// Delete an Existing Product
    /// </summary>
    /// <param name="productId">The product id to delete</param>
    /// <returns>True if successful, false otherwise</returns>
    public bool Delete(int productId)
    {
      return true;
    }

    /// <summary>
    /// Delete a list of products
    /// </summary>
    /// <param name="list">A collection of </param>
    /// <returns>True if successful, false otherwise</returns>
    public bool Delete(List<int> list)
    {
      // Write code to delete the list of Product IDs
      return true;
    }
    #endregion

    #region Discontinue Methods
    /// <summary>
    /// Discontinue a product
    /// </summary>
    /// <param name="entity">The product to discontinue</param>
    /// <returns>True if successful, false otherwise</returns>
    public bool Discontinue(Product entity)
    {
      // Write code to set the IsDiscontinued field to true from the list of Product IDs
      return true;
    }
    
    /// <summary>
    /// Discontinue a product
    /// </summary>
    /// <param name="productId">The product id to discontinue</param>
    /// <returns>True if successful, false otherwise</returns>
    public bool Discontinue(int productId)
    {
      return true;
    }
    
    /// <summary>
    /// Discontinue a list of products
    /// </summary>
    /// <param name="products">The list of product ids to discontinue</param>
    /// <returns>True if successful, false otherwise</returns>
    public bool Discontinue(List<int> products)
    {
      // Write code to set the IsDiscontinued field to true from the list of Product IDs
      return true;
    }
    #endregion
  }
}
