﻿Closure Samples Simple (\ClosureSamplesSimple folder)
--------------------------------------------------------------------------------------
Closure1.html
  Normal JavaScript to list data in an HTML table

Closure2.html
  Using a Closure to list data in an HTML table

Templating Samples
--------------------------------------------------------------------------------------
Template1.html
  Simple template using a closure and hard-coded data
Template2.html
  Adding function for formatting the date
Template3.html
  Template using a closure and calling Ajax
  NOTE: You have to use the .done() function to have Ajax finish before giving the data to the mustache to_html() function.
Template4.html
  Using the new Promise syntax for the Ajax call

Final Samples (\FinalSamples folder)
--------------------------------------------------------------------------------------
These samples are refactors of the previous article samples

ClosureSample.html 
  A sample to list, add, edit and delete product data using closures
TemplatingSample.html 
  Using templates to list, add, edit and delete product data


Mustache References
--------------------------------------------------------------------------------------
https://github.com/mustache/mustache.github.com
http://coenraets.org/blog/2011/12/tutorial-html-templates-with-mustache-js/
