﻿namespace Common.Library;

public abstract class EntityBase : CommonBase {
}