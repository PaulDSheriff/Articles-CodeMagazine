using AdventureWorks.EntityLayer;

namespace AdventureWorks.MAUI.Views;

public partial class UserDetailView : ContentPage
{
	public UserDetailView()
	{
		InitializeComponent();

    _ViewModel = (User)this.Resources["viewModel"];
  }

  private readonly User _ViewModel;

  protected override void OnAppearing() {
    base.OnAppearing();

    _ViewModel.LoginId = "PeterPiper384";
    _ViewModel.FirstName = "Peter";
    _ViewModel.LastName = "Piper";
    _ViewModel.Email = "Peter@pipering.com";
  }

  private void SaveButton_Clicked(object sender, EventArgs e) {
    // TODO: Respond to the event here

    System.Diagnostics.Debugger.Break();
  }
}