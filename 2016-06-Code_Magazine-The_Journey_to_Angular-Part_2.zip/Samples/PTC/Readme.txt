﻿Sample01 - Hard coded HTML page with all areas displayed
Sample02 - Handling UI state
           Add Angular
           Only handles Add and Cancel
Sample03.html
           Handles all events
           Add saveData(), insertData(), updateData() and validate()
Sample04 - Call a Web API to get products.
           Add $http DI
           Added data binding to <tbody>
           Add products array to $scope
           Format the date and price
