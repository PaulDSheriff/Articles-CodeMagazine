﻿using Common.Library;

namespace WPF.Sample.ViewModelLayer
{
  public class UserMaintenanceViewModel : ViewModelBase
  {
    public UserMaintenanceViewModel() : base()
    {
      DisplayStatusMessage("Maintain Users");
    }
  }
}
