﻿(function () {
  'use strict';

  angular.module('ptcApp').controller('ProductController', ProductController);

  function ProductController($scope) {
    // Property Declarations
    var vm = $scope;      // Reference to $scope

    // Public properties
    vm.uiState = {};

    // Public events
    vm.addClick = addClick;
    vm.cancelClick = cancelClick;
    vm.editClick = editClick;
    vm.deleteClick = deleteClick;
    vm.saveClick = saveClick;

    // Private Variables
    const pageMode = {
      LIST: 'List',
      EDIT: 'Edit',
      ADD: 'Add',
      EXCEPTION: 'Exception',
      VALIDATION: 'Validation'
    };

    // Initialize controller
    init();

    // Initialize variables
    function init() {
      // Initialize UI State
      vm.uiState = initUIState();
      setUIState(pageMode.LIST);
    }

    // Event procedures
    function addClick() {
      setUIState(pageMode.ADD);
    }

    function cancelClick() {
      setUIState(pageMode.LIST);
    }

    function editClick(id) {
      // TODO: Get Data Here

      setUIState(pageMode.EDIT);
    }

    function deleteClick(id) {
      // TODO: Delete data here
    }

    function saveClick() {
      saveData();
    }

    // Get a Product and go into Edit Mode
    function get(id) {
      // TODO: Get a single product

      // Put page into edit mode
      setUIState(pageMode.EDIT);
    }

    // Save data
    function saveData() {
      // Insert or Update the data
      if (vm.uiState.mode === pageMode.ADD) {
        insertData();
      }
      else if (vm.uiState.mode === pageMode.EDIT) {
        updateData();
      }

      if (vm.uiState.mode === pageMode.EXCEPTION ||
          vm.uiState.mode === pageMode.VALIDATION) {
        // Check for validation error
        setUIState(vm.uiState.mode);
      }
      else {
        setUIState(pageMode.LIST);
      }
    }

    // Insert a new product
    function insertData() {
      // Check data
      if (validate()) {
        // TODO: Insert a product here

      }
    }

    // Update a product
    function updateData() {
      // Check data
      if (validate()) {
        // TODO: Update a product here

      }
    }

    // Perform client-side validation
    function validate() {
      // Simulate a data validation error
      vm.uiState.mode = pageMode.VALIDATION;

      vm.uiState.messages.push({ property: 'ProductName', message: 'Product Name must be filled in.' });      
      vm.uiState.messages.push({ property: 'Url', message: 'Url must be filled in.' });
      vm.uiState.messages.push({ property: 'Price', message: 'Price must be greater than zero.' });

      return false;
    }

    // Create the uiState object literal
    function initUIState() {
      return {
        mode: pageMode.LIST,
        isDetailAreaVisible: false,
        isListAreaVisible: false,
        isMessageAreaVisible: false,
        isSearchAreaVisible: false,
        messages: []
      };
    }

    // Set appropriate UI state
    function setUIState(state) {
      // Set page state
      vm.uiState.mode = state;
      switch (state) {
        case pageMode.LIST:
          vm.uiState.isDetailAreaVisible = false;
          vm.uiState.isListAreaVisible = true;
          vm.uiState.isSearchAreaVisible = true;
          vm.uiState.isMessageAreaVisible = false;
          break;
        case pageMode.ADD:
          vm.uiState.isDetailAreaVisible = true;
          vm.uiState.isListAreaVisible = false;
          vm.uiState.isSearchAreaVisible = false;
          vm.uiState.messages = [];
          break;
        case pageMode.EDIT:
          vm.uiState.isDetailAreaVisible = true;
          vm.uiState.isListAreaVisible = false;
          vm.uiState.isSearchAreaVisible = false;
          vm.uiState.messages = [];
          break;
        case pageMode.EXCEPTION:
          vm.uiState.isMessageAreaVisible = true;
          break;
        case pageMode.VALIDATION:
          vm.uiState.isMessageAreaVisible = true;
          break;
      }
    }
  }
})();
