﻿Sample01 - Hard coded HTML page with all areas displayed
Sample02 - Handling UI state
           Add Angular
           Only handles Add and Cancel
Sample03.html
           Handles all events
           Add saveData(), insertData(), updateData() and validate()
Sample04 - Call a Web API to get products.
           Add $http DI
           Added data binding to <tbody>
           Add products array to $scope
           Format the date and price
Sample05 - Get a Product
           Modify the get() function to call Web API
           Add product object in closure
Sample06 - Save a Product
           Modify insertData() function to call Web API to add a new product
           Modify updateData() function to call Web API to update product
Sample07 - Delete a Product
           Add deleteData() function to call Web API to delete a product
           Call deleteData() from deleteClick()
