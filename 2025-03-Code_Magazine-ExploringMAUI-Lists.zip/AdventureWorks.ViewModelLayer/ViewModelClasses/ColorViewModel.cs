﻿using AdventureWorks.EntityLayer;
using Common.Library;
using System.Collections.ObjectModel;

namespace AdventureWorks.ViewModelLayer;

public class ColorViewModel : ViewModelBase {
  #region Constructors
  public ColorViewModel() : base() {
  }

  public ColorViewModel(
    IRepository<Color> repo) : base() {
    _Repository = repo;
  }
  #endregion

  #region Private Variables
  private readonly IRepository<Color>? _Repository;
  private ObservableCollection<Color> _Colors = new();
  private Color? _CurrentEntity = new();
  #endregion

  #region Public Properties
  public ObservableCollection<Color> Colors {
    get { return _Colors; }
    set {
      _Colors = value;
      RaisePropertyChanged(nameof(Colors));
    }
  }

  public Color? CurrentEntity {
    get { return _CurrentEntity; }
    set {
      _CurrentEntity = value;
      RaisePropertyChanged(nameof(CurrentEntity));
    }
  }
  #endregion

  #region GetAsync Method
  public async
    Task<ObservableCollection<Color>>
    GetAsync() {
    RowsAffected = 0;

    try {
      if (_Repository == null) {
        LastErrorMessage = REPO_NOT_SET;
      }
      else {
        Colors = await _Repository.GetAsync();
        RowsAffected = Colors.Count;
        InfoMessage =
          $"Found {RowsAffected} Colors";
      }
    }
    catch (Exception ex) {
      PublishException(ex);
    }

    return Colors;
  }
  #endregion

  #region GetAsync(id) Method
  public async Task<Color?> GetAsync(int id) {
    try {
      // Get a Color from a data store
      if (_Repository != null) {
        CurrentEntity = await _Repository.GetAsync(id);
        if (CurrentEntity == null) {
          InfoMessage = $"Color id={id} was not found.";
        }
        else {
          InfoMessage = "Found the Color";
        }
      }
      else {
        LastErrorMessage = REPO_NOT_SET;
        InfoMessage = "Found a MOCK Color";

        // MOCK Data
        CurrentEntity = await Task.FromResult(new Color {
          ColorId = 1,
          ColorName = "Black",
        });
      }

      RowsAffected = 1;
    }
    catch (Exception ex) {
      PublishException(ex);
    }
    return CurrentEntity;
  }
  #endregion

  #region SaveAsync Method
  public async virtual Task<Color?> SaveAsync() {
    // TODO: Write code to save data

    return await Task.FromResult(new Color());
  }
  #endregion
}
