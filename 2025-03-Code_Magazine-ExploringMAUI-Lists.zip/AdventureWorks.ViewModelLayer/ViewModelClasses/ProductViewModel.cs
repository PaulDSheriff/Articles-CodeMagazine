﻿using AdventureWorks.EntityLayer;
using Common.Library;
using System.Collections.ObjectModel;

namespace AdventureWorks.ViewModelLayer;

public class ProductViewModel : ViewModelBase {
  #region Constructors
  public ProductViewModel() : base() {
  }

  public ProductViewModel(
    IRepository<Product> repo) : base() {
    _Repository = repo;
  }
  #endregion

  #region Private Variables
  private readonly IRepository<Product>? _Repository;

  private ObservableCollection<Product> _Products = new();
  private Product? _CurrentEntity = new();
  #endregion

  #region Public Properties
  public ObservableCollection<Product> Products {
    get { return _Products; }
    set {
      _Products = value;
      RaisePropertyChanged(nameof(Products));
    }
  }

  public Product? CurrentEntity {
    get { return _CurrentEntity; }
    set {
      _CurrentEntity = value;
      RaisePropertyChanged(nameof(CurrentEntity));
    }
  }
  #endregion

  #region GetAsync Method
  public async Task<ObservableCollection<Product>> GetAsync() {
    RowsAffected = 0;

    try {
      if (_Repository == null) {
        LastErrorMessage = REPO_NOT_SET;
      }
      else {
        Products = await _Repository.GetAsync();
        RowsAffected = Products.Count;
        InfoMessage = $"Found {RowsAffected} Products";
      }
    }
    catch (Exception ex) {
      PublishException(ex);
    }

    return Products;
  }
  #endregion

  #region GetAsync(id) Method
  public async Task<Product?> GetAsync(int id) {
    try {
      // Get a Product from a data store
      if (_Repository != null) {
        CurrentEntity = await _Repository.GetAsync(id);
        if (CurrentEntity == null) {
          InfoMessage = $"Product id={id} was not found.";
        }
        else {
          InfoMessage = "Found the Product";
        }
      }
      else {
        LastErrorMessage = REPO_NOT_SET;
        InfoMessage = "Found a MOCK Product";

        // MOCK Data
        CurrentEntity =
          await Task.FromResult(new Product {
            ProductID = id,
            Name = "A New Product",
            Color = "Black",
            StandardCost = 10,
            ListPrice = 20,
            SellStartDate = Convert.ToDateTime("7/1/2023"),
            Size = "LG"
          });
      }

      RowsAffected = 1;
    }
    catch (Exception ex) {
      RowsAffected = 0;
      PublishException(ex);
    }

    return CurrentEntity;
  }
  #endregion

  #region SaveAsync Method
  public async virtual Task<Product?>
    SaveAsync() {
    // TODO: Write code to save data

    return await Task.FromResult(new Product());
  }
  #endregion
}
