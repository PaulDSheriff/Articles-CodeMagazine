﻿using AdventureWorks.EntityLayer;
using Common.Library;
using System.Collections.ObjectModel;

namespace AdventureWorks.DataLayer;

/// <summary>
/// Creates a set of Product mock data
/// </summary>
public partial class ProductRepository
  : IRepository<Product> {
  #region GetAsync Method
  public async Task<ObservableCollection<Product>> GetAsync() {
    return await Task.FromResult(new ObservableCollection<Product>
    {
      new() {
        ProductID = 680,
        Name = @"HL Road Frame - Black, 58",
        ProductNumber = @"FR-R92B-58",
        Color = @"Black",
        StandardCost = 100.0000m,
        ListPrice = 1431.5000m,
        Size = @"58",
        Weight = 1016.04m,
        ProductCategoryID = 18,
        ProductModelID = 6,
        SellStartDate = new DateTime(2002, 6, 1),
        SellEndDate = null,
        DiscontinuedDate = null,
        ModifiedDate = new DateTime(2008, 3, 11),
      },
      new() {
        ProductID = 707,
        Name = @"Sport-100 Helmet, Red",
        ProductNumber = @"HL-U509-R",
        Color = @"Red",
        StandardCost = 13.0863m,
        ListPrice = 34.9900m,
        Size = null,
        Weight = 3.4m,
        ProductCategoryID = 35,
        ProductModelID = 33,
        SellStartDate = new DateTime(2005, 7, 1),
        SellEndDate = null,
        DiscontinuedDate = null,
        ModifiedDate = new DateTime(2008, 3, 11),
      },
      new() {
        ProductID = 712,
        Name = @"AWC Logo Cap",
        ProductNumber = @"CA-1098",
        Color = @"Multi",
        StandardCost = 6.9223m,
        ListPrice = 8.9900m,
        Size = null,
        Weight = 0.80m,
        ProductCategoryID = 23,
        ProductModelID = 2,
        SellStartDate = new DateTime(2005, 7, 1),
        SellEndDate = null,
        DiscontinuedDate = null,
        ModifiedDate = new DateTime(2008, 3, 11),
      },
      new() {
        ProductID = 713,
        Name = @"Long-Sleeve Logo Jersey, S",
        ProductNumber = @"LJ-0192-S",
        Color = @"Multi",
        StandardCost = 38.4923m,
        ListPrice = 49.9900m,
        Size = "S",
        Weight = null,
        ProductCategoryID = 25,
        ProductModelID = 11,
        SellStartDate = new DateTime(2005, 7, 1),
        SellEndDate = null,
        DiscontinuedDate = null,
        ModifiedDate = new DateTime(2008, 3, 11),
      }
    });
  }
  #endregion

  #region GetAsync(id) Method
  public async Task<Product?> GetAsync(int id) {
    ObservableCollection<Product> list = await GetAsync();
    Product? entity = list.Where(row => row.ProductID == id).FirstOrDefault();

    return entity;
  }
  #endregion
}
