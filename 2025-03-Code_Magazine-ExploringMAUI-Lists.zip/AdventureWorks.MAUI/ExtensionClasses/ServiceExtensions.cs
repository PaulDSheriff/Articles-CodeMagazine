﻿using AdventureWorks.DataLayer;
using AdventureWorks.EntityLayer;
using AdventureWorks.MAUI.Views;
using Common.Library;

namespace AdventureWorks.MAUI.ExtensionClasses;

public static class ServiceExtensions {
  public static void AddServicesToDIContainer(this IServiceCollection services) {
    // Add Repository Classes
    AddRepositoryClasses(services);
    // Add View Model Classes
    AddViewModelClasses(services);
    // Add View Classes
    AddViewClasses(services);
  }

  private static void AddRepositoryClasses(IServiceCollection services) {
    // Add Repository Classes
    services.AddScoped<IRepository<User>, UserRepository>();
    services.AddScoped<IRepository<PhoneType>, PhoneTypeRepository>();
    services.AddScoped<IRepository<Product>, ProductRepository>();
    services.AddScoped<IRepository<EntityLayer.Color>, ColorRepository>();
  }

  private static void AddViewModelClasses(IServiceCollection services) {
    // Add View Model Classes
    services.AddScoped<MauiViewModelClasses.UserViewModel>();
    services.AddScoped<MauiViewModelClasses.ProductViewModel>();
    services.AddScoped<MauiViewModelClasses.ColorViewModel>();
  }

  private static void AddViewClasses(IServiceCollection services) {
    // Add View Classes
    services.AddScoped<UserDetailView>();
    services.AddScoped<UserListView>();
    services.AddScoped<ProductDetailView>();
    services.AddScoped<ProductListView>();
    services.AddScoped<ColorDetailView>();
    services.AddScoped<ColorListView>();
  }
}
