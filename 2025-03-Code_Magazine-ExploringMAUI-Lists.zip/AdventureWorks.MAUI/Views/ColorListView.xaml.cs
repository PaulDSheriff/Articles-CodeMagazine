using AdventureWorks.MAUI.MauiViewModelClasses;

namespace AdventureWorks.MAUI.Views;

public partial class ColorListView : ContentPage {
  public ColorListView(ColorViewModel viewModel) {
    InitializeComponent();

    _ViewModel = viewModel;
  }

  private readonly ColorViewModel _ViewModel;

  protected async override void OnAppearing() {
    base.OnAppearing();

    BindingContext = _ViewModel;

    await _ViewModel.GetAsync();
  }
}
