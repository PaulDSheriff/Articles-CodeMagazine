using AdventureWorks.MAUI.MauiViewModelClasses;

namespace AdventureWorks.MAUI.Views;

public partial class ProductListView : ContentPage {
  public ProductListView(ProductViewModel viewModel) {
    InitializeComponent();

    _ViewModel = viewModel;
  }

  private readonly ProductViewModel _ViewModel;

  protected async override void OnAppearing() {
    base.OnAppearing();

    BindingContext = _ViewModel;

    await _ViewModel.GetAsync();
  }
}
