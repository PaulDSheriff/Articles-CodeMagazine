﻿using AdventureWorks.EntityLayer;
using Common.Library;
using System.Windows.Input;

namespace AdventureWorks.MAUI.MauiViewModelClasses;

public class UserViewModel : AdventureWorks.ViewModelLayer.UserViewModel {
  #region Constructors
  public UserViewModel() : base() {
  }

  public UserViewModel(IRepository<User> repo) : base(repo) {
  }

  public UserViewModel(IRepository<User> repo, IRepository<PhoneType> phoneRepo) : base(repo, phoneRepo) {
  }
  #endregion

  #region Commands
  public ICommand? SaveCommand { get; private set; }
  public ICommand? EditCommand { get; private set; }
  public ICommand? CancelCommand { get; private set; }
  #endregion

  #region Init Method
  public override void Init() {
    base.Init();

    // Create commands for this view
    SaveCommand = new Command(async () => await SaveAsync());
    EditCommand = new Command<int>(async (int id) => await EditAsync(id));
    CancelCommand = new Command(async () => await CancelAsync());
  }
  #endregion

  #region SaveAsync Method
  public override async Task<User?> SaveAsync() {
    User? ret = await base.SaveAsync();

    if (ret != null) {
      await Shell.Current.GoToAsync("..");
    }

    return ret;
  }
  #endregion

  #region EditAsync Method
  protected async Task EditAsync(int id) {
    await Shell.Current.GoToAsync($"{nameof(Views.UserDetailView)}?id={id}");
  }
  #endregion

  #region CancelAsync Method
  public async Task CancelAsync() {
    await Shell.Current.GoToAsync("..");
  }
  #endregion
}
