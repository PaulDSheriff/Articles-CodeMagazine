"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var Observable_1 = require("rxjs/Observable");
require("rxjs/add/observable/of");
// ****************************************************
// Log Publisher Abstract Class
// NOTE: This class must be located BEFORE
//       all those that extend this class
// ****************************************************
var LogPublisher = (function () {
    function LogPublisher() {
    }
    return LogPublisher;
}());
exports.LogPublisher = LogPublisher;
// ****************************************************
// Console Logging Class
// ****************************************************
var LogConsole = (function (_super) {
    __extends(LogConsole, _super);
    function LogConsole() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    LogConsole.prototype.log = function (entry) {
        // Log to console
        console.log(entry.buildLogString());
        return Observable_1.Observable.of(true);
    };
    LogConsole.prototype.clear = function () {
        console.clear();
        return Observable_1.Observable.of(true);
    };
    return LogConsole;
}(LogPublisher));
exports.LogConsole = LogConsole;
// ****************************************************
// Local Storage Logging Class
// ****************************************************
var LogLocalStorage = (function (_super) {
    __extends(LogLocalStorage, _super);
    function LogLocalStorage() {
        var _this = 
        // Must call super() from derived classes
        _super.call(this) || this;
        // Set location
        _this.location = "logging";
        return _this;
    }
    // Append log entry to local storage
    LogLocalStorage.prototype.log = function (entry) {
        var ret = false;
        var values;
        try {
            // Retrieve previous values from local storage
            values = JSON.parse(localStorage.getItem(this.location)) || [];
            // Add new log entry to array
            values.push(entry);
            // Store array into local storage
            localStorage.setItem(this.location, JSON.stringify(values));
            // Set return value
            ret = true;
        }
        catch (ex) {
            // Display error in console
            console.log(ex);
        }
        return Observable_1.Observable.of(ret);
    };
    // Clear all log entries from local storage
    LogLocalStorage.prototype.clear = function () {
        localStorage.removeItem(this.location);
        return Observable_1.Observable.of(true);
    };
    return LogLocalStorage;
}(LogPublisher));
exports.LogLocalStorage = LogLocalStorage;
//# sourceMappingURL=log-publishers.js.map