﻿Add LogLocalStorage class

Modify LogPublishersService
  Modify buildPublishers() method
  Add LogLocalStorage object to publishers array
