﻿Add LogLevel enumeration
  Keep track of what kind of logging to perform
Add LogOption class
  Property to set LogLevel
  Property to set whether or not to add a date to the log entry

Added debug, info, warn, error, and fatal methods to log service
Added shouldLog() method to determine if logging should occur based on the LogLevel in the LogOptions class
Added writeLog() method to perform logging