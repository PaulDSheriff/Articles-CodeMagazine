"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
// ****************************************************
// Log Level Enumeration
// ****************************************************
var LogLevel;
(function (LogLevel) {
    LogLevel[LogLevel["All"] = 0] = "All";
    LogLevel[LogLevel["Debug"] = 1] = "Debug";
    LogLevel[LogLevel["Info"] = 2] = "Info";
    LogLevel[LogLevel["Warn"] = 3] = "Warn";
    LogLevel[LogLevel["Error"] = 4] = "Error";
    LogLevel[LogLevel["Fatal"] = 5] = "Fatal";
    LogLevel[LogLevel["Off"] = 6] = "Off";
})(LogLevel = exports.LogLevel || (exports.LogLevel = {}));
// ****************************************************
// Log Service Class
// ****************************************************
var LogService = (function () {
    function LogService() {
        // Public Properties
        this.level = LogLevel.All;
        this.logWithDate = true;
    }
    // *************************
    // Public methods
    // *************************
    LogService.prototype.debug = function (msg) {
        var optionalParams = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            optionalParams[_i - 1] = arguments[_i];
        }
        this.writeToLog(msg, LogLevel.Debug, optionalParams);
    };
    LogService.prototype.info = function (msg) {
        var optionalParams = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            optionalParams[_i - 1] = arguments[_i];
        }
        this.writeToLog(msg, LogLevel.Info, optionalParams);
    };
    LogService.prototype.warn = function (msg) {
        var optionalParams = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            optionalParams[_i - 1] = arguments[_i];
        }
        this.writeToLog(msg, LogLevel.Warn, optionalParams);
    };
    LogService.prototype.error = function (msg) {
        var optionalParams = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            optionalParams[_i - 1] = arguments[_i];
        }
        this.writeToLog(msg, LogLevel.Error, optionalParams);
    };
    LogService.prototype.fatal = function (msg) {
        var optionalParams = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            optionalParams[_i - 1] = arguments[_i];
        }
        this.writeToLog(msg, LogLevel.Fatal, optionalParams);
    };
    LogService.prototype.log = function (msg) {
        var optionalParams = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            optionalParams[_i - 1] = arguments[_i];
        }
        this.writeToLog(msg, LogLevel.All, optionalParams);
    };
    // *************************
    // Private methods
    // *************************
    LogService.prototype.shouldLog = function (level) {
        var ret = false;
        if ((level >= this.level &&
            level !== LogLevel.Off) ||
            this.level === LogLevel.All) {
            ret = true;
        }
        return ret;
    };
    LogService.prototype.writeToLog = function (msg, level, params) {
        if (this.shouldLog(level)) {
            var valueToLog = "";
            // Build log string
            if (this.logWithDate) {
                valueToLog = new Date() + " - ";
            }
            valueToLog += "Type: " + LogLevel[this.level];
            valueToLog += " - Message: " + msg;
            if (params.length) {
                valueToLog += " - Extra Info: "
                    + this.formatParams(params);
            }
            // Log the value
            console.log(valueToLog);
        }
    };
    LogService.prototype.formatParams = function (params) {
        var value = params.join(",");
        // Is there at least one object in the array?
        if (params.some(function (p) { return typeof p == "object"; })) {
            value = "";
            // Build comma-delimited string
            for (var _i = 0, params_1 = params; _i < params_1.length; _i++) {
                var item = params_1[_i];
                value += JSON.stringify(item) + ",";
            }
        }
        return value;
    };
    return LogService;
}());
LogService = __decorate([
    core_1.Injectable()
], LogService);
exports.LogService = LogService;
//# sourceMappingURL=log.service.js.map