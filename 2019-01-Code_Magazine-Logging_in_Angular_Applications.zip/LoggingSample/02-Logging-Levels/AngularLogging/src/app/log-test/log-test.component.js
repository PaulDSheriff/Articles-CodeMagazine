"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var log_service_1 = require("../shared/log.service");
var product_1 = require("./product");
var LogTestComponent = (function () {
    function LogTestComponent(logger) {
        this.logger = logger;
    }
    LogTestComponent.prototype.toggleLogging = function () {
        this.logger.level = this.logger.level == log_service_1.LogLevel.All ? log_service_1.LogLevel.Off : log_service_1.LogLevel.All;
    };
    LogTestComponent.prototype.toggleDate = function () {
        this.logger.logWithDate = !this.logger.logWithDate;
    };
    LogTestComponent.prototype.logTest = function () {
        this.logger.log("Test log() method");
    };
    LogTestComponent.prototype.debugTest = function () {
        this.logger.debug("Test debug() method");
    };
    LogTestComponent.prototype.infoTest = function () {
        this.logger.info("Test info() method");
    };
    LogTestComponent.prototype.warnTest = function () {
        this.logger.warn("Test warn() method");
    };
    LogTestComponent.prototype.errorTest = function () {
        this.logger.error("Test error() method");
    };
    LogTestComponent.prototype.fatalTest = function () {
        this.logger.fatal("Test fatal() method");
    };
    LogTestComponent.prototype.stringTest = function () {
        this.logger.log("Message and string test", "Paul", "Smith");
    };
    LogTestComponent.prototype.boolTest = function () {
        this.logger.log("Message and boolean test", true, false);
    };
    LogTestComponent.prototype.numberTest = function () {
        this.logger.log("Message and number test", 1, 2, 3, 4, 5);
    };
    LogTestComponent.prototype.objectTest = function () {
        var product = new product_1.Product();
        product.productId = 10;
        product.productName = "A New Product";
        product.introductionDate = new Date();
        product.price = 20;
        product.url = "http://www.fairwaytech.com";
        this.logger.log("Message and object test", product, "a string", 1, true);
    };
    LogTestComponent.prototype.arrayTest = function () {
        var values = ["1", "Paul", "Smith"];
        this.logger.log("Message and array test", "another string", values);
    };
    LogTestComponent.prototype.allTypesTest = function () {
        var values = ["1", "Paul", "Smith"];
        var product = new product_1.Product();
        product.productId = 10;
        product.productName = "A New Product";
        product.introductionDate = new Date();
        product.price = 20;
        product.url = "http://www.fairwaytech.com";
        this.logger.log("Message and All Types test", "another string", 1, 2, true, false, values, product);
    };
    LogTestComponent.prototype.setOptionsTest = function () {
        // Get current logging level
        var oldLevel = this.logger.level;
        // Set level to error and above
        this.logger.level = log_service_1.LogLevel.Error;
        // Attempt some logging
        this.logger.log("This one should not show up");
        this.logger.warn("This one should not show up either");
        this.logger.error("This is an ERROR");
        this.logger.fatal("This is a FATAL ERROR");
        // Reset level back to old value
        this.logger.level = oldLevel;
    };
    return LogTestComponent;
}());
LogTestComponent = __decorate([
    core_1.Component({
        selector: "log-test",
        templateUrl: "./log-test.component.html"
    }),
    __metadata("design:paramtypes", [log_service_1.LogService])
], LogTestComponent);
exports.LogTestComponent = LogTestComponent;
//# sourceMappingURL=log-test.component.js.map