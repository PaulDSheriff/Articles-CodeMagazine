﻿Added \shared\logging.service.ts
This is a simple wrapper around console.log