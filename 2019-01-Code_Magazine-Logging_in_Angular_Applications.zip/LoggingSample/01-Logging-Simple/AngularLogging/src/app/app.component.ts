import { Component } from '@angular/core';

@Component({
  selector: "log-app",
  templateUrl: "app/app.component.html"
})
export class AppComponent {
  pageTitle: string = "Logging Service Sample";
}
