import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { LogTestComponent } from './log-test/log-test.component';
import { LogService } from "./shared/log.service";

@NgModule({
  imports: [BrowserModule, FormsModule],
  declarations: [AppComponent, LogTestComponent],
  bootstrap: [AppComponent],
  providers: [LogService]
})
export class AppModule { }
