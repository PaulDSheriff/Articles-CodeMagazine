﻿import { Component } from "@angular/core";

import { LogService } from '../shared/log.service';
import { Product } from './product';

@Component({
  selector: "log-test",
  templateUrl: "./log-test.component.html"
})
export class LogTestComponent {
  constructor(private logger: LogService) {
  }

  stringToLog(): void {
    this.logger.log("String to log test");
  }
  
  objectToLog(): void {
    let product = new Product();

    product.productId = 1;
    product.productName = "A sample product";
    product.introductionDate = new Date();
    product.price = 10;
    product.url = "www.fairwaytech.com";

    this.logger.log(product);
  }
}