﻿using System;
using System.Collections.Generic;
using System.Web.Http;

namespace AngularLogging
{
  public class LogController : ApiController
  {
    // POST api/<controller>
    [HttpPost]
    public IHttpActionResult Post([FromBody]LogEntry value)
    {
      IHttpActionResult ret;

      // TODO: Write code to store logging data in a database table
      ret = Ok(true);

      return ret;
    }
  }
}