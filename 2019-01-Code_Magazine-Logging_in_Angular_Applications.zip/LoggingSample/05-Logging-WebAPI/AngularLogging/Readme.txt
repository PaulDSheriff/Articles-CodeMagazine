﻿Add LogWebApi class
  Add appropriate import statements to log-publishers.ts file to support Web API call
  
Modify LogPublishersService
  Inject Http into class
  Pass http to LogWebApi class

Add C# Classes
  LogEntry
  LogLevel enumeration
  LogController