"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
var Observable_1 = require("rxjs/Observable");
require("rxjs/add/operator/map");
require("rxjs/add/operator/catch");
require("rxjs/add/observable/throw");
var log_publishers_1 = require("./log-publishers");
var PUBLISHERS_FILE = "/src/app/assets/log-publishers.json";
// ****************************************************
// Logging Publishers Service Class
// ****************************************************
var LogPublishersService = (function () {
    function LogPublishersService(http) {
        this.http = http;
        // Public properties
        this.publishers = [];
        // Build publishers arrays
        this.buildPublishers();
    }
    // *************************
    // Public methods
    // *************************
    // Build publishers array
    LogPublishersService.prototype.buildPublishers = function () {
        var _this = this;
        this.getLoggers().subscribe(function (response) {
            for (var _i = 0, _a = response.filter(function (p) { return p.isActive; }); _i < _a.length; _i++) {
                var pub = _a[_i];
                var logPub = void 0;
                switch (pub.loggerName.toLowerCase()) {
                    case "console":
                        logPub = new log_publishers_1.LogConsole();
                        break;
                    case "localstorage":
                        logPub = new log_publishers_1.LogLocalStorage();
                        break;
                    case "webapi":
                        logPub = new log_publishers_1.LogWebApi(_this.http);
                        break;
                }
                // Set location of logging
                logPub.location = pub.loggerLocation;
                // Add publisher to array
                _this.publishers.push(logPub);
            }
        });
    };
    // Get logger configuration info from JSON file
    LogPublishersService.prototype.getLoggers = function () {
        return this.http.get(PUBLISHERS_FILE)
            .map(function (response) { return response.json(); })
            .catch(this.handleErrors);
    };
    // *************************
    // Private methods
    // *************************  
    LogPublishersService.prototype.handleErrors = function (error) {
        var errors = [];
        var msg = "";
        msg = "Status: " + error.status;
        msg += " - Status Text: " + error.statusText;
        if (error.json()) {
            msg += " - Exception Message: " + error.json().exceptionMessage;
        }
        errors.push(msg);
        console.error('An error occurred', errors);
        return Observable_1.Observable.throw(errors);
    };
    return LogPublishersService;
}());
LogPublishersService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [http_1.Http])
], LogPublishersService);
exports.LogPublishersService = LogPublishersService;
// ****************************************************
// Log Publisher Config Definition Class
// ****************************************************
var LogPublisherConfig = (function () {
    function LogPublisherConfig() {
    }
    return LogPublisherConfig;
}());
//# sourceMappingURL=log-publishers.service.js.map