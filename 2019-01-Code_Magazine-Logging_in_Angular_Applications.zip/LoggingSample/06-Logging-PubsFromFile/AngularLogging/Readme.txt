﻿Add \assets\log-publisher.json file

Add LogPublisherConfig class
  Maps to objects in JSON file

Modified LogPublishersService
  Add getLoggers() method to read JSON file
  Modify buildPublishers() to build publishers from JSON file
    Creates instances of LogConsole, LogLocalStorage and/or LogWebApi classes based on values in JSON file