﻿Add log-publishers.ts
  Add abstract class LogPublisher
  Add class LogConsole that extends LogPublisher

Add log-publishers.service.ts
  Create LogPublishersService

Add LogEntry class
  Holds all log information that needs to be recorded
  Method to build a string of log information

Modify LogService
  Inject LogPublishersService class
  Set 'publishers' property with values from this class
  writeToLog() loops through all publishers and calls each ones log() method
