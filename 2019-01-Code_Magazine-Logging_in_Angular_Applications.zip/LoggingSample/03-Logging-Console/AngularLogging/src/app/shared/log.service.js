"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var log_publishers_service_1 = require("./log-publishers.service");
// ****************************************************
// Log Level Enumeration
// ****************************************************
var LogLevel;
(function (LogLevel) {
    LogLevel[LogLevel["All"] = 0] = "All";
    LogLevel[LogLevel["Debug"] = 1] = "Debug";
    LogLevel[LogLevel["Info"] = 2] = "Info";
    LogLevel[LogLevel["Warn"] = 3] = "Warn";
    LogLevel[LogLevel["Error"] = 4] = "Error";
    LogLevel[LogLevel["Fatal"] = 5] = "Fatal";
    LogLevel[LogLevel["Off"] = 6] = "Off";
})(LogLevel = exports.LogLevel || (exports.LogLevel = {}));
// ****************************************************
// Log Entry Class
// ****************************************************
var LogEntry = (function () {
    function LogEntry() {
        // Public Properties
        this.entryDate = new Date();
        this.message = "";
        this.level = LogLevel.Debug;
        this.extraInfo = [];
        this.logWithDate = true;
    }
    // **************
    // Public Methods
    // **************
    LogEntry.prototype.buildLogString = function () {
        var value = "";
        if (this.logWithDate) {
            value = new Date() + " - ";
        }
        value += "Type: " + LogLevel[this.level];
        value += " - Message: " + this.message;
        if (this.extraInfo.length) {
            value += " - Extra Info: "
                + this.formatParams(this.extraInfo);
        }
        return value;
    };
    // ***************
    // Private Methods
    // ***************
    LogEntry.prototype.formatParams = function (params) {
        var ret = params.join(",");
        // Is there at least one object in the array?
        if (params.some(function (p) { return typeof p == "object"; })) {
            ret = "";
            // Build comma-delimited string
            for (var _i = 0, params_1 = params; _i < params_1.length; _i++) {
                var item = params_1[_i];
                ret += JSON.stringify(item) + ",";
            }
        }
        return ret;
    };
    return LogEntry;
}());
exports.LogEntry = LogEntry;
// ****************************************************
// Log Service Class
// ****************************************************
var LogService = (function () {
    function LogService(publishersService) {
        this.publishersService = publishersService;
        this.level = LogLevel.All;
        this.logWithDate = true;
        // Set publishers
        this.publishers = this.publishersService.publishers;
    }
    // *************************
    // Public methods
    // *************************
    LogService.prototype.debug = function (msg) {
        var optionalParams = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            optionalParams[_i - 1] = arguments[_i];
        }
        this.writeToLog(msg, LogLevel.Debug, optionalParams);
    };
    LogService.prototype.info = function (msg) {
        var optionalParams = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            optionalParams[_i - 1] = arguments[_i];
        }
        this.writeToLog(msg, LogLevel.Info, optionalParams);
    };
    LogService.prototype.warn = function (msg) {
        var optionalParams = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            optionalParams[_i - 1] = arguments[_i];
        }
        this.writeToLog(msg, LogLevel.Warn, optionalParams);
    };
    LogService.prototype.error = function (msg) {
        var optionalParams = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            optionalParams[_i - 1] = arguments[_i];
        }
        this.writeToLog(msg, LogLevel.Error, optionalParams);
    };
    LogService.prototype.fatal = function (msg) {
        var optionalParams = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            optionalParams[_i - 1] = arguments[_i];
        }
        this.writeToLog(msg, LogLevel.Fatal, optionalParams);
    };
    LogService.prototype.log = function (msg) {
        var optionalParams = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            optionalParams[_i - 1] = arguments[_i];
        }
        this.writeToLog(msg, LogLevel.All, optionalParams);
    };
    LogService.prototype.clear = function () {
        for (var _i = 0, _a = this.publishers; _i < _a.length; _i++) {
            var logger = _a[_i];
            logger.clear()
                .subscribe(function (response) { return console.log(response); });
        }
    };
    // *************************
    // Private methods
    // *************************
    LogService.prototype.shouldLog = function (level) {
        var ret = false;
        if ((level >= this.level &&
            level !== LogLevel.Off) ||
            this.level === LogLevel.All) {
            ret = true;
        }
        return ret;
    };
    LogService.prototype.writeToLog = function (msg, level, params) {
        if (this.shouldLog(level)) {
            // Declare variables
            var entry = new LogEntry();
            // Build Log Entry
            entry.message = msg;
            entry.level = level;
            entry.extraInfo = params;
            entry.logWithDate = this.logWithDate;
            for (var _i = 0, _a = this.publishers; _i < _a.length; _i++) {
                var logger = _a[_i];
                logger.log(entry)
                    .subscribe(function (response) { return console.log(response); });
            }
        }
    };
    return LogService;
}());
LogService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [log_publishers_service_1.LogPublishersService])
], LogService);
exports.LogService = LogService;
//# sourceMappingURL=log.service.js.map