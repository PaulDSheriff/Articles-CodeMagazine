﻿using SchemaInfo;

string conn = "Data Source=Localhost;Initial Catalog=AdventureWorksLT;Integrated Security=True;";

//*****************************************************
// Hard-Coded Samples
//*****************************************************
//SqlServerSchemaHelper.GetAllTablesAndViews();
//SqlServerSchemaHelper.GetAllTablesInSchema();

//*****************************************************
// Meta-Data Information
//*****************************************************
//GetSchemaHelper.GetMetaData(conn);

//*****************************************************
// Meta-Data Restriction Information
//*****************************************************
//GetSchemaHelper.GetMetaDataRestrictions(conn);

//*****************************************************
// SQL Server Information
//*****************************************************
//GetSchemaHelper.GetDataSourceInformation(conn);

//*****************************************************
// SQL Server Data Types
//*****************************************************
//GetSchemaHelper.GetDataSourceDataTypes(conn);

//*****************************************************
// SQL Server Reserved Words
//*****************************************************
//GetSchemaHelper.GetDataSourceReservedWords(conn);

//*****************************************************
// SQL Server User Defined Types
//*****************************************************
//GetSchemaHelper.GetDataSourceUserDefinedTypes(conn);

//*****************************************************
// Database Information
//*****************************************************
// Get All Databases
//GetSchemaHelper.GetDatabases(conn);

//*****************************************************
// User Information
//*****************************************************
// Get All Users
//SqlServerSchemaHelper.GetUsers(conn);
// Get A User
//SqlServerSchemaHelper.GetUsers(conn, "dbo");

//*****************************************************
// Table Information
//*****************************************************
// Get All Tables
//SqlServerSchemaHelper.GetTables(conn);
// Get Tables in 'dbo' Schema
//SqlServerSchemaHelper.GetTables(conn, "dbo");
// Get Table 'SalesLT.Address'
//SqlServerSchemaHelper.GetTables(conn, "SalesLT", "Address");

//*****************************************************
// Column Information
//*****************************************************
// Get All Columns
//SqlServerSchemaHelper.GetColumns(conn);
// Get Columns in 'dbo' Schema
//SqlServerSchemaHelper.GetColumns(conn, "dbo");
// Get Columns for 'SalesLT.Address' Table
//SqlServerSchemaHelper.GetColumns(conn, "SalesLT", "Address");
// Get Specific Column for 'SalesLT.Address' Table
//SqlServerSchemaHelper.GetColumns(conn, "SalesLT", "Address", "AddressID");

//*****************************************************
// View Information
//*****************************************************
// Get All Views
//SqlServerSchemaHelper.GetViews(conn);
// Get Views in 'SaleLT' Schema
//SqlServerSchemaHelper.GetViews(conn, "SalesLT");
// Get View 'SalesLT.vProductAndDescription'
//SqlServerSchemaHelper.GetViews(conn, "SalesLT", "vProductAndDescription");

//*****************************************************
// View Column Information
//*****************************************************
// Get All View Columns
//SqlServerSchemaHelper.GetColumns(conn);
// Get View Columns in 'SaleLT' Schema
//SqlServerSchemaHelper.GetColumns(conn, "SaleLT");
// Get View Columns for 'SalesLT.vProductAndDescription' Table
//SqlServerSchemaHelper.GetColumns(conn, "SalesLT", "vProductAndDescription");
// Get Specific View Column for 'SalesLT.vProductAndDescription' Table
//SqlServerSchemaHelper.GetColumns(conn, "SalesLT", "vProductAndDescription", "ProductModel");

//*****************************************************
// Index Information
//*****************************************************
// Get All Indexes
//SqlServerSchemaHelper.GetIndexes(conn);
// Get Indexes in 'dbo' Schema
//SqlServerSchemaHelper.GetIndexes(conn, "dbo");
// Get Indexes for 'SalesLT.Address' Table
//SqlServerSchemaHelper.GetIndexes(conn, "SalesLT", "Address");
// Get Specific Index for 'SalesLT.Address' Table
//SqlServerSchemaHelper.GetIndexes(conn, "SalesLT", "Address", "PK_Address_AddressID");

//*****************************************************
// Index Column Information
//*****************************************************
// Get All Columns in Indexes
//SqlServerSchemaHelper.GetIndexColumns(conn);
// Get All Columns in Indexes in 'SalesLT' Schema
//SqlServerSchemaHelper.GetIndexColumns(conn, "SalesLT");
// Get All Columns in Indexes for 'SalesLT.Product' Table
//SqlServerSchemaHelper.GetIndexColumns(conn, "SalesLT", "Product");
// Get All Columns in Specific Index for 'SalesLT.Product' Table
//SqlServerSchemaHelper.GetIndexColumns(conn, "SalesLT", "Product", "PK_Product_ProductID");

//*****************************************************
// Stored Procedure Information
//*****************************************************
// Get All Procedures
//SqlServerSchemaHelper.GetProcedures(conn);
// Get All Procedures in 'SalesLT' Schema
//SqlServerSchemaHelper.GetProcedures(conn, "SalesLT");
// Get Procedures 'SalesLT.SalesOrderDetail_GetAll'
//SqlServerSchemaHelper.GetProcedures(conn, "SalesLT", "SalesOrderDetail_GetAll");

//*****************************************************
// Stored Procedure Parameter Information
//*****************************************************
// Get All Procedure Parameters
//SqlServerSchemaHelper.GetProcedureParameters(conn);
// Get All Procedure Parameters in 'SalesLT' Schema
//SqlServerSchemaHelper.GetProcedureParameters(conn, "SalesLT");
// Get Procedure Parameters 'SalesLT.SalesOrderDetail_GetBySalesOrderID'
//SqlServerSchemaHelper.GetProcedureParameters(conn, "SalesLT", "SalesOrderDetail_GetBySalesOrderID");

//*****************************************************
// Function Information
// NOTE: No way to get function parameters
//*****************************************************
// Get All Functions
//SqlServerSchemaHelper.GetFunctions(conn);
// Get All Functions in 'dbo' Schema
//SqlServerSchemaHelper.GetFunctions(conn, "dbo");
// Get Function 'SalesLT.ufnGetSalesOrderStatusText'
//SqlServerSchemaHelper.GetFunctions(conn, "dbo", "ufnGetSalesOrderStatusText");

//*****************************************************
// Foreign Key Information
//*****************************************************
// Get All Foreign Keys
//SqlServerSchemaHelper.GetForeignKeys(conn);
// Get All Foreign Keys in 'SalesLT' Schema
//SqlServerSchemaHelper.GetForeignKeys(conn, "SalesLT");
// Get Foreign Keys in table 'SalesLT.FK_SalesOrderHeader_Customer_CustomerID'
//SqlServerSchemaHelper.GetForeignKeys(conn, "SalesLT", null, "FK_SalesOrderDetail_Product_ProductID");

//*****************************************************
// Compare Tables & Columns
//*****************************************************
//List<TableSchema> tables = SqlServerCompareHelper.CompareTables(conn, conn);
//foreach (TableSchema item in tables) {
//  Console.WriteLine(item);
//}

//List<ColumnSchema> columns = SqlServerCompareHelper.CompareColumns(conn, conn);
//foreach (ColumnSchema item in columns) {
//  Console.WriteLine(item);
//}