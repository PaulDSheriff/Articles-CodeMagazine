﻿using System.Data;
using System.Data.SqlClient;

namespace SchemaInfo;

public static class GetSchemaHelper
{
  #region GetMetaData Method
  /// <summary>
  /// Returns the list of collection names you can pass to the GetSchema() method
  /// </summary>
  /// <param name="conn">A Connection String</param>
  public static void GetMetaData(string conn)
  {
    using SqlConnection cn = new(conn);

    cn.Open();

    DisplayDataTable(cn.GetSchema());
  }
  #endregion

  #region GetMetaDataRestrictions Method
  /// <summary>
  /// Returns the list of restriction array parameters for each Meta-Data collection you can pass to the GetSchema() method
  /// </summary>
  /// <param name="conn">A Connection String</param>
  public static void GetMetaDataRestrictions(string conn)
  {
    DataTable dt = GetData(conn, "Restrictions");

    DisplayDataTable(dt);
  }
  #endregion

  #region GetDataSourceInformation Method
  /// <summary>
  /// Returns information about the SQL Server
  /// </summary>
  /// <param name="conn">A Connection String</param>
  public static void GetDataSourceInformation(string conn)
  {
    DataTable dt = GetData(conn, "DataSourceInformation");

    DisplayDataTable(dt);
  }
  #endregion

  #region GetDataSourceDataTypes Method
  /// <summary>
  /// Get Data Types from the Data Source
  /// </summary>
  /// <param name="conn">A Connection String</param>
  public static void GetDataSourceDataTypes(string conn)
  {
    DataTable dt = GetData(conn, "DataTypes");

    DisplayDataTable(dt);
  }
  #endregion

  #region GetDataSourceReservedWords Method
  /// <summary>
  /// Get Reserved Words from the Data Source
  /// </summary>
  /// <param name="conn">A Connection String</param>
  public static void GetDataSourceReservedWords(string conn)
  {
    DataTable dt = GetData(conn, "ReservedWords");

    DisplayDataTable(dt);
  }
  #endregion

  #region GetDataSourceUserDefinedTypes Method
  /// <summary>
  /// Get User Defined Types from the Data Source
  /// </summary>
  /// <param name="conn">A Connection String</param>
  public static void GetDataSourceUserDefinedTypes(string conn)
  {
    DataTable dt = GetData(conn, "UserDefinedTypes");

    DisplayDataTable(dt);
  }
  #endregion

  #region GetDatabases Method
  public static void GetDatabases(string conn)
  {
    DataTable dt = GetSchemaHelper.GetData(conn, "Databases");

    GetSchemaHelper.DisplayDataTable(dt);
  }
  #endregion

  #region GetData Methods   
  public static DataTable GetData(string conn, string name)
  {
    using SqlConnection cn = new(conn);

    cn.Open();

    // Get the Meta Data
    return cn.GetSchema(name);
  }

  public static DataTable GetData(string conn, string name, string?[] restrictions)
  {
    using SqlConnection cn = new(conn);

    cn.Open();

    // Get the Meta Data
    return cn.GetSchema(name, restrictions);
  }
  #endregion

  #region DisplayDataTable Methods
  public static void DisplayDataTable(DataTable dt)
  {
    // Display Column Names
    foreach (DataColumn col in dt.Columns) {
      Console.Write("{0,-26}", col.ColumnName);
    }
    Console.WriteLine();

    // Display Column Data
    foreach (DataRow row in dt.Rows) {
      foreach (DataColumn col in dt.Columns) {
        Console.Write("{0,-26}", row[col]);
      }
      Console.WriteLine();
    }
  }
  #endregion

  #region DisplayColumns Method
  public static void DisplayColumns(DataTable dt)
  {
    // Build anonymous type from DataTable information
    var rows = from info in dt.AsEnumerable()
               select new
               {
                 TableCatalog = info["TABLE_CATALOG"],
                 TableSchema = info["TABLE_SCHEMA"],
                 TableName = info["TABLE_NAME"],
                 ColumnName = info["COLUMN_NAME"],
                 DataType = info["DATA_TYPE"]
               };

    string format = "{0,-20}{1,-20}{2,-30}{3,-20}{4,-20}";

    Console.WriteLine(format, "Table Catalog",
      "Table Schema", "Table Name", "Column Name",
      "Data Type");
    foreach (var row in rows) {
      Console.WriteLine(format, row.TableCatalog,
        row.TableSchema, row.TableName,
        row.ColumnName, row.DataType);
    }
  }
  #endregion

  #region DisplayIndexColumns Method
  public static void DisplayIndexColumns(DataTable dt)
  {
    // Build anonymous type from DataTable information
    var rows = from info in dt.AsEnumerable()
               select new
               {
                 TableSchema = info["TABLE_SCHEMA"],
                 TableName = info["TABLE_NAME"],
                 ColumnName = info["COLUMN_NAME"],
                 ConstraintSchema = info["CONSTRAINT_SCHEMA"],
                 ConstraintName = info["CONSTRAINT_NAME"],
                 KeyType = info["KEYTYPE"]
               };

    string format = "{0,-20}{1,-30}{2,-20}{3,-20}{4,-20}";

    Console.WriteLine(format, "Table Schema",
      "Table Name", "Column Name", "Constraint Schema",
      "Constraint Name", "Key Type");
    foreach (var row in rows) {
      Console.WriteLine(format, row.TableSchema,
        row.TableName, row.ColumnName,
        row.ConstraintSchema, row.ConstraintName,
        row.KeyType);
    }
  }
  #endregion
}
