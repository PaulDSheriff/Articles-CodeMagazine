﻿Add System.Data.SqlClient from NuGet

https://learn.microsoft.com/en-us/dotnet/api/system.data.sqlclient.sqlconnection.getschema?view=dotnet-plat-ext-7.0
https://learn.microsoft.com/en-us/dotnet/framework/data/adonet/common-schema-collections
https://learn.microsoft.com/en-us/dotnet/framework/data/adonet/sql-server-schema-collections
https://learn.microsoft.com/en-us/dotnet/framework/data/adonet/retrieving-database-schema-information

The following collections gather data about the meta-data you can query
MetaDataCollections      0                        0
Restrictions             0                        0

The following collections gather information from the data source
Databases                1                        1
DataSourceInformation    0                        0
DataTypes                0                        0
ReservedWords            0                        0
UserDefinedTypes         2                        1

For the collections above you do not need to specify a Data Source in the connection string. For example: Data Source=Localhost;Integrated Security=True;


The following collections are for a specific database, or the master database if Data Source is not specified in the connection string
Columns                  4                        4
IndexColumns             5                        4
Indexes                  4                        3
ForeignKeys              4                        3
ProcedureParameters      4                        1
Procedures               4                        3
Tables                   4                        3
Users                    1                        1
Views                    3                        3
ViewColumns              4                        4


The following collections are used with sparse columns
AllColumns               4                        4
ColumnSetColumns         3                        3
StructuredTypeMembers    4                        4
