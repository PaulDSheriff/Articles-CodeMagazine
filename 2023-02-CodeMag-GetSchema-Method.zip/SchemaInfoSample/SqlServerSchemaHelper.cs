﻿using System.Data;
using System.Data.SqlClient;

namespace SchemaInfo;

public static class SqlServerSchemaHelper
{
  #region Hard-Coded Samples
  public static void GetAllTablesAndViews()
  {
    string conn = "Data Source=Localhost;Initial Catalog=AdventureWorksLT;Integrated Security=True;";
    using SqlConnection cn = new(conn);

    cn.Open();

    // Get the Meta Data
    DataTable dt = cn.GetSchema("Tables");

    // Display Column Names
    string format = "{0,-20}{1,-10}{2,-35}{3,-15}";
    Console.WriteLine(format, "Catalog", "Schema",
      "Name", "Type");

    // Display Column Data
    foreach (DataRow row in dt.Rows) {
      Console.WriteLine(format, row["TABLE_CATALOG"],
        row["TABLE_SCHEMA"], row["TABLE_NAME"],
        row["TABLE_TYPE"]);
    }
  }

  public static void GetAllTablesInSchema()
  {
    string conn = "Data Source=Localhost;Initial Catalog=AdventureWorksLT;Integrated Security=True;";
    using SqlConnection cn = new(conn);

    cn.Open();

    // restrictions[0] = Catalog/Database
    // restrictions[1] = Owner/Schema
    // restrictions[2] = Table Name
    // restrictions[3] = Table Type
    string?[] restrictions = new string?[4];
    restrictions[0] = null;
    restrictions[1] = "SalesLT";
    restrictions[2] = null;
    // Use 'BASE TABLE' or you get views too
    restrictions[3] = "BASE TABLE";

    // Get the Meta Data
    DataTable dt = cn.GetSchema("Tables", restrictions);

    // Display Column Names
    string format = "{0,-20}{1,-10}{2,-35}{3,-15}";
    Console.WriteLine(format, "Catalog", "Schema",
      "Name", "Type");

    // Display Column Data
    foreach (DataRow row in dt.Rows) {
      Console.WriteLine(format, row["TABLE_CATALOG"],
        row["TABLE_SCHEMA"], row["TABLE_NAME"],
        row["TABLE_TYPE"]);
    }
  }
  #endregion

  #region GetUsers Method
  public static void GetUsers(string conn)
  {
    GetUsers(conn, null);
  }

  public static void GetUsers(string conn, string? name)
  {
    // restrictions[0] = name
    string?[] restrictions = new string?[1];
    restrictions[0] = name;

    DataTable dt = GetSchemaHelper.GetData(conn, "Users", restrictions);

    GetSchemaHelper.DisplayDataTable(dt);
  }
  #endregion

  #region GetTables Methods
  public static void GetTables(string conn)
  {
    GetTables(conn, null, null, null);
  }

  public static void GetTables(string conn, string? schema)
  {
    GetTables(conn, schema, null, null);
  }

  public static void GetTables(string conn, string? schema, string? table)
  {
    GetTables(conn, schema, table, null);
  }

  public static void GetTables(string conn, string? schema, string? table, string? catalog)
  {
    // restrictions[0] = Catalog/Database
    // restrictions[1] = Owner/Schema
    // restrictions[2] = Table Name
    // restrictions[3] = Table Type
    string?[] restrictions = new string?[4];
    restrictions[0] = catalog;
    restrictions[1] = schema;
    restrictions[2] = table;
    // Must use 'BASE TABLE' or you get views too
    restrictions[3] = "BASE TABLE";

    DataTable dt = GetSchemaHelper.GetData(conn, "Tables", restrictions);

    GetSchemaHelper.DisplayDataTable(dt);
  }
  #endregion

  #region GetColumns Methods
  public static void GetColumns(string conn)
  {
    GetColumns(conn, null, null, null, null);
  }

  public static void GetColumns(string conn, string? schema)
  {
    GetColumns(conn, schema, null, null, null);
  }

  public static void GetColumns(string conn, string? schema, string? table)
  {
    GetColumns(conn, schema, table, null, null);
  }

  public static void GetColumns(string conn, string? schema, string? table, string? column)
  {
    GetColumns(conn, schema, table, column, null);
  }

  public static void GetColumns(string conn, string? schema, string? table, string? column, string? catalog)
  {
    // restrictions[0] = Catalog/Database
    // restrictions[1] = Owner/Schema
    // restrictions[2] = Table/View Name
    // restrictions[3] = Column Name
    string?[] restrictions = new string?[4];
    restrictions[0] = catalog;
    restrictions[1] = schema;
    restrictions[2] = table;
    restrictions[3] = column;

    DataTable dt = GetSchemaHelper.GetData(conn, "Columns", restrictions);

    GetSchemaHelper.DisplayColumns(dt);
  }
  #endregion

  #region GetViews Methods
  public static void GetViews(string conn)
  {
    GetViews(conn, null, null, null);
  }

  public static void GetViews(string conn, string? schema)
  {
    GetViews(conn, schema, null, null);
  }

  public static void GetViews(string conn, string? schema, string? view)
  {
    GetViews(conn, schema, view, null);
  }

  public static void GetViews(string conn, string? schema, string? view, string? catalog)
  {
    // restrictions[0] = Catalog/Database
    // restrictions[1] = Owner/Schema
    // restrictions[2] = View Name
    string?[] restrictions = new string?[3];
    restrictions[0] = catalog;
    restrictions[1] = schema;
    restrictions[2] = view;

    DataTable dt = GetSchemaHelper.GetData(conn, "Views", restrictions);

    GetSchemaHelper.DisplayDataTable(dt);
  }
  #endregion

  #region GetViewColumns Methods
  public static void GetViewColumns(string conn)
  {
    GetViewColumns(conn, null, null, null, null);
  }

  public static void GetViewColumns(string conn, string? schema)
  {
    GetViewColumns(conn, schema, null, null, null);
  }

  public static void GetViewColumns(string conn, string? schema, string? table)
  {
    GetViewColumns(conn, schema, table, null, null);
  }

  public static void GetViewColumns(string conn, string? schema, string? view, string? column)
  {
    GetViewColumns(conn, schema, view, column, null);
  }

  public static void GetViewColumns(string conn, string? schema, string? view, string? column, string? catalog)
  {
    // restrictions[0] = Catalog/Database
    // restrictions[1] = Owner/Schema
    // restrictions[2] = View Name
    // restrictions[3] = Column Name
    string?[] restrictions = new string?[4];
    restrictions[0] = catalog;
    restrictions[1] = schema;
    restrictions[2] = view;
    restrictions[3] = column;

    DataTable dt = GetSchemaHelper.GetData(conn, "ViewColumns", restrictions);

    GetSchemaHelper.DisplayColumns(dt);
  }
  #endregion

  #region GetIndexes Methods
  public static void GetIndexes(string conn)
  {
    GetIndexes(conn, null, null, null, null);
  }

  public static void GetIndexes(string conn, string? schema)
  {
    GetIndexes(conn, schema, null, null, null);
  }

  public static void GetIndexes(string conn, string? schema, string? table)
  {
    GetIndexes(conn, schema, table, null, null);
  }

  public static void GetIndexes(string conn, string? schema, string? table, string? index)
  {
    GetIndexes(conn, schema, table, index, null);
  }

  public static void GetIndexes(string conn, string? schema, string? table, string? index, string? catalog)
  {
    // restrictions[0] = Catalog/Database
    // restrictions[1] = Owner/Schema
    // restrictions[2] = Table Name
    // restrictions[3] = Index Name
    string?[] restrictions = new string?[4];
    restrictions[0] = catalog;
    restrictions[1] = schema;
    restrictions[2] = table;
    restrictions[3] = index;

    DataTable dt = GetSchemaHelper.GetData(conn, "Indexes", restrictions);

    GetSchemaHelper.DisplayDataTable(dt);
  }
  #endregion

  #region GetIndexColumns Methods
  public static void GetIndexColumns(string conn)
  {
    GetIndexColumns(conn, null, null, null, null, null);
  }

  public static void GetIndexColumns(string conn, string? schema)
  {
    GetIndexColumns(conn, schema, null, null, null, null);
  }

  public static void GetIndexColumns(string conn, string? schema, string? table)
  {
    GetIndexColumns(conn, schema, table, null, null, null);
  }

  public static void GetIndexColumns(string conn, string? schema, string? table, string? index)
  {
    GetIndexColumns(conn, schema, table, index, null, null);
  }

  public static void GetIndexColumns(string conn, string? schema, string? table, string? index, string? column)
  {
    GetIndexColumns(conn, schema, table, index, column, null);
  }

  public static void GetIndexColumns(string conn, string? schema, string? table, string? index, string? column, string? catalog)
  {
    // restrictions[0] = Catalog/Database
    // restrictions[1] = Owner/Schema
    // restrictions[2] = Table Name
    // restrictions[3] = Index Name
    // restrictions[4] = Column Name
    string?[] restrictions = new string?[5];
    restrictions[0] = catalog;
    restrictions[1] = schema;
    restrictions[2] = table;
    restrictions[3] = index;
    restrictions[4] = column;

    DataTable dt = GetSchemaHelper.GetData(conn, "IndexColumns", restrictions);

    GetSchemaHelper.DisplayIndexColumns(dt);
  }
  #endregion

  #region GetProcedures Methods
  public static void GetProcedures(string conn)
  {
    GetProcedures(conn, null, null, null);
  }

  public static void GetProcedures(string conn, string? schema)
  {
    GetProcedures(conn, schema, null, null);
  }

  public static void GetProcedures(string conn, string? schema, string? procedure)
  {
    GetProcedures(conn, schema, procedure, null);
  }

  public static void GetProcedures(string conn, string? schema, string? procedure, string? catalog)
  {
    // restrictions[0] = Catalog/Database
    // restrictions[1] = Owner/Schema
    // restrictions[2] = Procedure Name
    // restrictions[3] = Procedure Type
    string?[] restrictions = new string?[4];
    restrictions[0] = catalog;
    restrictions[1] = schema;
    restrictions[2] = procedure;
    // Must use 'PROCEDURE' or you get functions too
    restrictions[3] = "PROCEDURE";

    DataTable dt = GetSchemaHelper.GetData(conn, "Procedures", restrictions);

    GetSchemaHelper.DisplayDataTable(dt);
  }
  #endregion

  #region GetProcedureParameters Methods
  public static void GetProcedureParameters(string conn)
  {
    GetProcedureParameters(conn, null, null, null, null);
  }

  public static void GetProcedureParameters(string conn, string? schema)
  {
    GetProcedureParameters(conn, schema, null, null, null);
  }

  public static void GetProcedureParameters(string conn, string? schema, string? procedure)
  {
    GetProcedureParameters(conn, schema, procedure, null, null);
  }

  public static void GetProcedureParameters(string conn, string? schema, string? procedure, string? param, string? catalog)
  {
    // restrictions[0] = Catalog/Database
    // restrictions[1] = Owner/Schema
    // restrictions[2] = Procedure Name
    // restrictions[3] = Parameter Name
    string?[] restrictions = new string?[4];
    restrictions[0] = catalog;
    restrictions[1] = schema;
    restrictions[2] = procedure;
    restrictions[3] = param;

    DataTable dt = GetSchemaHelper.GetData(conn, "ProcedureParameters", restrictions);

    GetSchemaHelper.DisplayDataTable(dt);
  }
  #endregion

  #region GetFunctions Methods
  public static void GetFunctions(string conn)
  {
    GetFunctions(conn, null, null, null);
  }

  public static void GetFunctions(string conn, string? schema)
  {
    GetFunctions(conn, schema, null, null);
  }

  public static void GetFunctions(string conn, string? schema, string? function)
  {
    GetFunctions(conn, schema, function, null);
  }

  public static void GetFunctions(string conn, string? schema, string? function, string? catalog)
  {
    // restrictions[0] = Catalog/Database
    // restrictions[1] = Owner/Schema
    // restrictions[2] = Procedure Name
    // restrictions[3] = Procedure Type
    string?[] restrictions = new string?[4];
    restrictions[0] = catalog;
    restrictions[1] = schema;
    restrictions[2] = function;
    restrictions[3] = "FUNCTION";

    DataTable dt = GetSchemaHelper.GetData(conn, "Procedures", restrictions);

    GetSchemaHelper.DisplayDataTable(dt);
  }
  #endregion

  #region GetForeignKeys Methods
  public static void GetForeignKeys(string conn)
  {
    GetForeignKeys(conn, null, null, null, null);
  }

  public static void GetForeignKeys(string conn, string? schema)
  {
    GetForeignKeys(conn, schema, null, null, null);
  }

  public static void GetForeignKeys(string conn, string? schema, string? table)
  {
    GetForeignKeys(conn, schema, table, null, null);
  }

  public static void GetForeignKeys(string conn, string? schema, string? table, string? fkname)
  {
    GetForeignKeys(conn, schema, table, fkname, null);
  }

  public static void GetForeignKeys(string conn, string? schema, string? table, string? fkname, string? catalog)
  {
    // restrictions[0] = Catalog/Database
    // restrictions[1] = Owner/Schema
    // restrictions[2] = Table Name
    // restrictions[3] = FK Name
    string?[] restrictions = new string?[4];
    restrictions[0] = catalog;
    restrictions[1] = schema;
    restrictions[2] = table;
    restrictions[3] = fkname;

    DataTable dt = GetSchemaHelper.GetData(conn, "ForeignKeys", restrictions);

    GetSchemaHelper.DisplayDataTable(dt);
  }
  #endregion
}
