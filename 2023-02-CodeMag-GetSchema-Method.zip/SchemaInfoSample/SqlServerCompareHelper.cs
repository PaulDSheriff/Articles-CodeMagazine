﻿#nullable disable

using System.Data;
using System.Data.SqlClient;

namespace SchemaInfo;

public static class SqlServerCompareHelper
{
  public static List<TableSchema> CompareTables(string connSource, string connTarget)
  {
    List<TableSchema> ret = new();
    List<TableSchema> sourceList;
    List<TableSchema> targetList;

    sourceList = TableSchemaToList(GetData(connSource, "Tables"));
    targetList = TableSchemaToList(GetData(connTarget, "Tables"));

    // Simulate missing tables
    targetList.RemoveRange(2, 3);

    // Use ExceptBy to locate differences between the two lists
    ret = sourceList.ExceptBy<TableSchema, object>(
    targetList.Select(row => new { row.Catalog, row.Schema, row.TableName, row.TableType }),
    row => new { row.Catalog, row.Schema, row.TableName, row.TableType }).ToList();

    return ret;
  }

  public static List<ColumnSchema> CompareColumns(string connSource, string connTarget)
  {
    List<ColumnSchema> ret = new();
    List<ColumnSchema> sourceList;
    List<ColumnSchema> targetList;

    sourceList = ColumnSchemaToList(GetData(connSource, "Columns"));
    targetList = ColumnSchemaToList(GetData(connTarget, "Columns"));

    // Simulate missing columns
    targetList.RemoveRange(1, 5);

    // Use ExceptBy to locate differences between the two lists
    ret = sourceList.ExceptBy<ColumnSchema, object>(
    targetList.Select(row => new { row.Catalog, row.Schema, row.TableName, row.ColumnName, row.OrdinalPosition, row.DataType }),
    row => new { row.Catalog, row.Schema, row.TableName, row.ColumnName, row.OrdinalPosition, row.DataType }).ToList();

    return ret;
  }

  #region GetData
  public static DataTable GetData(string conn, string name)
  {
    using SqlConnection cn = new(conn);

    cn.Open();

    // Get the Meta Data
    return cn.GetSchema(name);
  }
  #endregion

  #region TableSchemaToList Method
  private static List<TableSchema> TableSchemaToList(DataTable dt)
  {
    List<TableSchema> ret = new();

    foreach (DataRow row in dt.Rows) {
      TableSchema entity = new()
      {
        Catalog = row["TABLE_CATALOG"].ToString(),
        Schema = row["TABLE_SCHEMA"].ToString(),
        TableName = row["TABLE_NAME"].ToString(),
        TableType = row["TABLE_TYPE"].ToString()
      };

      ret.Add(entity);
    }

    return ret;
  }
  #endregion

  #region ColumnSchemaToList Method
  private static List<ColumnSchema> ColumnSchemaToList(DataTable dt)
  {
    List<ColumnSchema> ret = new();

    foreach (DataRow row in dt.Rows) {
      ColumnSchema entity = new()
      {
        Catalog = row["TABLE_CATALOG"].ToString(),
        Schema = row["TABLE_SCHEMA"].ToString(),
        TableName = row["TABLE_NAME"].ToString(),
        ColumnName = row["COLUMN_NAME"].ToString(),
        OrdinalPosition = Convert.ToInt32(row["ORDINAL_POSITION"]),
        DataType = row["DATA_TYPE"].ToString(),
      };

      ret.Add(entity);
    }

    return ret;
  }
  #endregion
}
