﻿#nullable disable

namespace SchemaInfo;

public class SchemaBase
{
  public string Catalog { get; set; }
  public string Schema { get; set; }
  public string TableName { get; set; }

  public override string ToString()
  {
    return $"{Schema}.{TableName}";
  }
}
