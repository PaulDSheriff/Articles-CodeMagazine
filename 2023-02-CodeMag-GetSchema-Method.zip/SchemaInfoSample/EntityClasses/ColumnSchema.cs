﻿#nullable disable

namespace SchemaInfo;

public class ColumnSchema : SchemaBase
{
  public string ColumnName { get; set; }
  public int OrdinalPosition { get; set; }
  public string DataType { get; set; }

  public override string ToString()
  {
    return $"{base.ToString()}.{ColumnName} ({OrdinalPosition})";
  }
}
