﻿#nullable disable

namespace SchemaInfo;

public class TableSchema : SchemaBase
{
  public string TableType { get; set; }
}
