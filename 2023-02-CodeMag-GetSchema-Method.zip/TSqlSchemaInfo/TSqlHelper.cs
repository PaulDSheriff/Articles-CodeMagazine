﻿using System.Data;
using System.Data.SqlClient;

namespace TSqlSchemaInfo;

public static class TSqlHelper
{
  public static void DisplayTables(string conn, string? schema, string? table)
  {
    DataTable dt = new();
    string sql = "SELECT * FROM INFORMATION_SCHEMA.TABLES";
    sql += " WHERE TABLE_TYPE = 'BASE TABLE'";
    if (schema != null) {
      sql += $" AND TABLE_SCHEMA LIKE '{schema}%'";
    }
    if (table != null) {
      sql += $" AND TABLE_NAME LIKE '{table}%'";
    }

    using SqlDataAdapter da = new(sql, conn);

    da.Fill(dt);

    // Display Column Names
    string format = "{0,-10}{1,-35}{2,-15}";
    Console.WriteLine(format, "Schema",
      "Name", "Type");

    // Display Column Data
    foreach (DataRow row in dt.Rows) {
      Console.WriteLine(format, row["TABLE_SCHEMA"],
        row["TABLE_NAME"], row["TABLE_TYPE"]);
    }
  }

  public static void DisplayColumns(string conn, string? schema, string? table, string? column)
  {
    DataTable dt = new();
    string where = " WHERE ";
    string sql = "SELECT * FROM INFORMATION_SCHEMA.COLUMNS";
    if (schema != null) {
      sql += $" {where} TABLE_SCHEMA LIKE '{schema}%'";
      where = " AND ";
    }
    if (table != null) {
      sql += $" {where} TABLE_NAME LIKE '{table}%'";
      where = " AND ";
    }
    if (column != null) {
      sql += $" {where} COLUMN_NAME LIKE '{column}%'";
      where = " AND ";
    }

    using SqlDataAdapter da = new(sql, conn);

    da.Fill(dt);

    // Display Column Names
    string format = "{0,-10}{1,-35}{2,-15}{3,-15}";
    Console.WriteLine(format, "Schema",
      "Table Name", "Column Name", "Position");

    // Display Column Data
    foreach (DataRow row in dt.Rows) {
      Console.WriteLine(format, row["TABLE_SCHEMA"],
        row["TABLE_NAME"], row["COLUMN_NAME"],
        row["ORDINAL_POSITION"]);
    }
  }

  public static void DisplayCheckConstraints(string conn, string? schema)
  {
    DataTable dt = new();
    string sql = "SELECT * FROM INFORMATION_SCHEMA.CHECK_CONSTRAINTS";
    if (schema != null) {
      sql += $" WHERE CONSTRAINT_SCHEMA LIKE '{schema}%'";
    }

    using SqlDataAdapter da = new(sql, conn);

    da.Fill(dt);

    // Display Column Names
    string format = "{0,-10}{1,-40}{2,-40}";
    Console.WriteLine(format, "Schema",
      "Name", "Clause");

    // Display Column Data
    foreach (DataRow row in dt.Rows) {
      Console.WriteLine(format, row["CONSTRAINT_SCHEMA"],
        row["CONSTRAINT_NAME"], row["CHECK_CLAUSE"]);
    }
  }

  public static void DisplayForeignKeys(string conn, string? table)
  {
    DataTable dt = new();
    string whereSQL = string.Empty;
    if (table != null) {
      whereSQL += $" WHERE parentTab.name LIKE '{table}%' ";
    }

    string sql =
      @$"SELECT
    obj.name AS KeyName,
    sch.name AS SchemaName,
    parentTab.name AS TableName,
    parentCol.name AS ColumnName,
    refTable.name AS ReferencedTableName,
    refCol.name AS ReferencedColumnName
  FROM sys.foreign_key_columns fkc
  INNER JOIN sys.objects obj
    ON obj.object_id = fkc.constraint_object_id
  INNER JOIN sys.tables parentTab
    ON parentTab.object_id = fkc.parent_object_id
  INNER JOIN sys.schemas sch
    ON parentTab.schema_id = sch.schema_id
  INNER JOIN sys.columns parentCol
    ON parentCol.column_id = parent_column_id
    AND parentCol.object_id = parentTab.object_id
  INNER JOIN sys.tables refTable
    ON refTable.object_id = fkc.referenced_object_id
  INNER JOIN sys.columns refCol
    ON refCol.column_id = referenced_column_id
    AND refCol.object_id = refTable.object_id
  {whereSQL}
  ORDER BY TableName";

    using SqlDataAdapter da = new(sql, conn);

    da.Fill(dt);

    // Display Column Names
    string format = "{0,-48}{1,-33}{2,-25}";
    Console.WriteLine(format, "Key Name",
      "Table Name", "Column Name");

    // Display Column Data
    foreach (DataRow row in dt.Rows) {
      string kName = row["KeyName"].ToString() ?? string.Empty;
      string tName = row["TableName"].ToString() ?? string.Empty;
      Console.WriteLine(format,
        kName[0..Math.Min(45, kName.Length)],
        tName[0..Math.Min(30, tName.Length)],
        row["ColumnName"]);
    }
  }
}
