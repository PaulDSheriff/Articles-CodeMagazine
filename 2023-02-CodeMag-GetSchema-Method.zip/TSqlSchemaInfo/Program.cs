﻿using TSqlSchemaInfo;

string conn = "Data Source=Localhost;Initial Catalog=AdventureWorksLT;Integrated Security=True;";

//*******************************
// Get Tables
//*******************************
// Get all Tables
//TSqlHelper.DisplayTables(conn, null, null);

// Get Tables in 'dbo' Schema
//TSqlHelper.DisplayTables(conn, "dbo", null);

// Get any Tables That Starts with 'Cust'
//TSqlHelper.DisplayTables(conn, null, "Cust");

//*******************************
// Get Columns
//*******************************
// Get all Columns
//TSqlHelper.DisplayColumns(conn, null, null, null);

// Get all Columns in 'dbo' Schema
//TSqlHelper.DisplayColumns(conn, "dbo", null, null);

// Get any Columns in Tables That Start with 'Cust'
//TSqlHelper.DisplayColumns(conn, null, "Cust", null);

// Get any Columns That Start with 'ad'
//TSqlHelper.DisplayColumns(conn, null, null, "ad");

//*******************************
// Get Check Constraints
//*******************************
// Get all Check Constraints
//TSqlHelper.DisplayCheckConstraints(conn, null);

// Get all Check Constraints in 'SalesLT' Schema
//TSqlHelper.DisplayCheckConstraints(conn, "SalesLT");

//*********************************
// Get Foreign Keys
//*********************************
// Get all Foreign Keys
TSqlHelper.DisplayForeignKeys(conn, null);

// Get Foreign Keys for a Table
//TSqlHelper.DisplayForeignKeys(conn, "SalesOrderDetail");
