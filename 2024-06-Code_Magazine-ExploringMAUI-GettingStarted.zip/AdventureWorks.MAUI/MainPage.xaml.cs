﻿namespace AdventureWorks.MAUI;

public partial class MainPage : ContentPage
{
  public MainPage()
  {
    InitializeComponent();
  }

  private void SaveButton_Clicked(object sender, EventArgs e)
  {
    // TODO: Respond to the event here
  }
}
