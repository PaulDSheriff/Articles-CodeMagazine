﻿using System.Text.Json.Nodes;

namespace JsonSamples;

public class JsonNodeWriteViewModel
{
  public static void AddNode()
  {
    // Parse string into a JsonObject
    JsonObject? jo = JsonNode.Parse(JsonStrings.PERSON)?.AsObject();

    jo?.Add("hairColor", JsonValue.Create("Brown"));

    Console.WriteLine(jo?.ToString());
  }

  public static void UpdateNode()
  {   
    // Parse string into a JsonNode object
    JsonNode? jo = JsonNode.Parse(JsonStrings.PERSON);

    jo!["age"] = 42;

    Console.WriteLine(jo?.ToString());
  }
}
