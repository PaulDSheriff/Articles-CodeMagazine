﻿using System.Text.Json.Nodes;

namespace JsonSamples;

public class JsonNodeReadViewModel
{
  public static void GetAge()
  {   
    // Parse string into a JsonNode object
    JsonNode? jn =
      JsonNode.Parse(JsonStrings.PERSON);

    // Get the age node
    JsonNode? node = jn!["age"];

    // Get the value as a JsonValue
    JsonValue value = node!.AsValue();
    Console.WriteLine($"Path={value.GetPath()}");
    Console.WriteLine($"Type={value.GetValueKind()}");
    Console.WriteLine($"Age={value}");

    // Get the value as an integer
    int age = node!.GetValue<int>();
    Console.WriteLine($"Age={age}");
  }

  public static void GetCity()
  {
    // Parse string into a JsonNode object
    JsonNode? jn = JsonNode.Parse(JsonStrings.PERSON_ADDRESS);

    // Get the address.city node
    JsonNode? node = jn!["address"]!["city"];

    // Display string value from the JsonNode
    Console.WriteLine($"City={node!.AsValue()}");
  }

  public static void GetHomeNumber()
  {
    // Parse string into a JsonNode object
    JsonNode? jn = JsonNode.Parse(JsonStrings.PERSON_ADDRESS_PHONES);

    // Get the first phoneNumbers node
    JsonNode? node = jn!["phoneNumbers"]![0]!["number"];

    // Display value from the JsonNode
    Console.WriteLine($"Home Number={node!.AsValue()}");
  }

  public static void GetMobileNumber()
  {
    // Parse string into a JsonNode object
    JsonNode? jn = JsonNode.Parse(JsonStrings.PERSON_ADDRESS_PHONES);

    // Get the phoneNumbers node
    JsonNode? numbers = jn!["phoneNumbers"];

    // Get an Array Enumerator from phoneNumbers array
    var enumerator = numbers!.AsArray()!.AsEnumerable();
    // Use LINQ to get the correct JsonNode
    JsonNode? node = enumerator
      .FirstOrDefault(row => row!["type"]!.AsValue().GetValue<string>() == "Mobile");

    // Display the string value from the JsonNode
    Console.WriteLine($"Mobile Number={node!["number"]!.AsValue()}");
  }
}
