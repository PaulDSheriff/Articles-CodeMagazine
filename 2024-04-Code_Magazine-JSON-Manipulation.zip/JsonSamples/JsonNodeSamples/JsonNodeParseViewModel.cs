﻿using System.Text.Json.Nodes;

namespace JsonSamples;

public class JsonNodeParseViewModel
{
  public static void GetPerson()
  {
    // Parse string into a JsonNode object
    JsonNode? jn = JsonNode.Parse(JsonStrings.PERSON);

    // Alternate method
    //JsonNode? jn = JsonObject.Parse(JsonStrings.PERSON);

    Console.WriteLine(jn!.ToString());
    Console.WriteLine(jn!.GetValueKind());
  }

  public static void GetPersonAddress()
  {
    // Parse string into a JsonNode object
    JsonNode? jn = JsonNode.Parse(JsonStrings.PERSON_ADDRESS);

    Console.WriteLine(jn!.ToString());
    Console.WriteLine(jn!.GetValueKind());
  }

  public static void GetPhones()
  {
    // Parse string into a JsonArray object
    JsonNode? jn = JsonNode.Parse(JsonStrings.PHONE_NUMBERS);

    Console.WriteLine(jn?.ToString());
    Console.WriteLine(jn!.GetValueKind());
  }
}
