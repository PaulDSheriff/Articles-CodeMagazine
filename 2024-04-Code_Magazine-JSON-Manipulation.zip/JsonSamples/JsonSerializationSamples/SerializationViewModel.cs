﻿using System.Text.Json;
using System.Text.Json.Serialization;

namespace JsonSamples;

public class SerializationViewModel
{
  public static void SerializePerson()
  {
    Person entity = new() {
      Name = "John Smith",
      Age = 31,
      SSN = null,
      IsActive = true
    };

    // NOTE: The json name is the same
    // casing as the C# property name
    Console.WriteLine(JsonSerializer.Serialize(entity));
  }

  public static void SerializePersonUsingOptions()
  {
    Person entity = new() {
      Name = "John Smith",
      Age = 31,
      SSN = null,
      IsActive = true
    };

    JsonSerializerOptions options = new() {
      PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
      //PropertyNamingPolicy = JsonNamingPolicy.KebabCaseUpper,
      //PropertyNamingPolicy = JsonNamingPolicy.SnakeCaseUpper,
      WriteIndented = true
    };

    Console.WriteLine(JsonSerializer.Serialize(entity, options));
  }

  public static void SerializePersonUsingAttributes()
  {
    PersonWithAttributes entity = new() {
      Name = "John Smith",
      Age = 31,
      SSN = null,
      IsActive = true,
      // This property is never serialized
      CreateDate = DateTime.Now,
      // Comment this property to
      // remove from serialization
      ModifiedDate = DateTime.Now
    };

    JsonSerializerOptions options = new() {
      PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
      WriteIndented = true
    };

    Console.WriteLine(JsonSerializer.Serialize(entity, options));
  }

  public static void SerializePersonUsingEnum()
  {
    PersonWithEnum entity = new() {
      Name = "John Smith",
      PersonType = PersonTypeEnum.Supervisor
    };

    JsonSerializerOptions options = new() {
      PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
      WriteIndented = true
    };

    Console.WriteLine(JsonSerializer.Serialize(entity, options));
  }

  public static void SerializePersonUsingEnumString()
  {
    PersonWithEnum entity = new() {
      Name = "John Smith",
      PersonType = PersonTypeEnum.Supervisor
    };

    JsonSerializerOptions options = new() {
      PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
      WriteIndented = true,
      Converters =
      {
        new JsonStringEnumConverter()
      }
    };

    Console.WriteLine(JsonSerializer.Serialize(entity, options));
  }

  public static void SerializeNested()
  {
    AppSettingsNested entity = new() {
      ApplicationName = "JSON Samples",
      JWTSettings = new() {
        Key = "ALongKeyForASymmetricAlgorithm",
        Issuer = "JsonSamplesAPI",
        Audience = "PDSCJsonSamples",
        MinutesToExpiration = 60
      }
    };

    JsonSerializerOptions options = new() {
      PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
      WriteIndented = true
    };

    Console.WriteLine(JsonSerializer.Serialize(entity, options));
  }

  public static void SerializeDictionary()
  {
    Dictionary<string, object?> dict = new()
    {
      {"name", "John Smith"},
      {"age", 31},
      {"isActive", true}
    };

    JsonSerializerOptions options = new() {
      WriteIndented = true
    };

    Console.WriteLine(JsonSerializer.Serialize(dict, options));
  }

  public static void SerializeArray()
  {
    string[] persons = ["John", "Sally", "Charlie"];

    JsonSerializerOptions options = new() {
      WriteIndented = true
    };

    Console.WriteLine(JsonSerializer.Serialize(persons, options));
  }

  public static void SerializeList()
  {
    List<PersonWithEnum> list = new()
    {
      new PersonWithEnum { Name = "John Smith", PersonType = PersonTypeEnum.Supervisor },
      new PersonWithEnum { Name = "Sally Jones", PersonType = PersonTypeEnum.Employee },
      new PersonWithEnum { Name = "Charlie Chaplin", PersonType = PersonTypeEnum.Customer }
    };

    JsonSerializerOptions options = new() {
      PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
      WriteIndented = true
    };

    Console.WriteLine(JsonSerializer.Serialize(list, options));
  }
}
