﻿using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;

namespace JsonSamples;

public class DeserializationViewModel
{
  public static void StringToPerson()
  {
    // JSON names must match
    // C# properties by default
    string json = @"{
      ""Name"": ""John Smith"",
      ""Age"": 31,
      ""SSN"": null,
      ""IsActive"": true
    }";

    // Deserialize JSON string into Person
    Person? entity = JsonSerializer.Deserialize<Person>(json);

    Console.WriteLine(entity);
  }

  public static void StringToPersonUsingOptions()
  {
    string json = @"{
      ""name"": ""John Smith"",
      ""age"": 31,
      ""ssn"": null,
      ""isActive"": true
    }";

    // Override case matching
    JsonSerializerOptions options = new() {
      // NOTE: In ASP.NET applications
      //       this set to true by default
      PropertyNameCaseInsensitive = true
    };

    // Deserialize JSON string into Person
    Person? entity = JsonSerializer.Deserialize<Person>(json, options);

    Console.WriteLine(entity);
  }

  public static void StringToPersonWithEnum()
  {
    string json = @"{
      ""name"": ""John Smith"",
      ""personType"": ""Supervisor""
    }";

    JsonSerializerOptions options = new() {
      PropertyNameCaseInsensitive = true,
      // Avoid an exception being
      // thrown on Deserialize()
      Converters =
      {
        new JsonStringEnumConverter()
      }
    };

    // Deserialize JSON string into PersonWithEnum
    PersonWithEnum? entity = JsonSerializer.Deserialize<PersonWithEnum>(json, options);

    Console.WriteLine(entity);
  }

  public static void FileToPerson()
  {
    string fileName = $"{AppDomain.CurrentDomain.BaseDirectory}JsonSampleFiles\\person.json";

    using FileStream stream = File.OpenRead(fileName);

    JsonSerializerOptions options = new() {
      PropertyNameCaseInsensitive = true,
    };

    // Deserialize JSON string into Person
    Person? entity = JsonSerializer.Deserialize<Person>(stream, options);

    Console.WriteLine(entity);
  }

  public static void FileToListOfPersons()
  {
    string fileName = $"{AppDomain.CurrentDomain.BaseDirectory}JsonSampleFiles\\persons.json";

    using FileStream stream = File.OpenRead(fileName);

    JsonSerializerOptions options = new() {
      PropertyNameCaseInsensitive = true,
    };

    // Deserialize JSON string into List<Person>
    List<Person>? list = JsonSerializer.Deserialize<List<Person>>(stream, options);

    if (list != null) {
      foreach (var item in list) {
        Console.WriteLine(item);
      }
    }
  }

  public static void GetMaxPersonAge()
  {
    string fileName = $"{AppDomain.CurrentDomain.BaseDirectory}JsonSampleFiles\\persons.json";

    using FileStream stream = File.OpenRead(fileName);

    JsonSerializerOptions options = new() {
      PropertyNameCaseInsensitive = true,
    };

    // Deserialize JSON string into List<Person>
    List<Person>? list = JsonSerializer.Deserialize<List<Person>>(stream, options);

    // Calculate maximum age
    int maxAge = list?.Max(row => row.Age) ?? 0;

    Console.WriteLine(maxAge);
  }

  public static void PersonObjectUsingJsonNode()
  {
    JsonSerializerOptions options = new() {
      PropertyNameCaseInsensitive = true,
    };

    // Parse string into a JsonNode object
    JsonNode? jn = JsonNode.Parse(JsonStrings.PERSON);
    // Deserialize JSON string into Person
    // using the JsonNode object
    Person? entity = jn.Deserialize<Person>(options);

    Console.WriteLine(entity);
  }

  public static void PersonObjectUsingJsonDocument()
  {
    JsonSerializerOptions options = new() {
      PropertyNameCaseInsensitive = true,
    };

    // Parse string into a JsonDocument object
    using JsonDocument jd = JsonDocument.Parse(JsonStrings.PERSON);
    // Deserialize JSON string into Person
    // using the JsonDocument object
    Person? entity = jd.Deserialize<Person>(options);

    Console.WriteLine(entity?.ToString());
  }
}
