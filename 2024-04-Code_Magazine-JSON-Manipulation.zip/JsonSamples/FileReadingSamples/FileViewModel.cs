﻿using System.Text.Json;
using System.Text.Json.Nodes;

namespace JsonSamples;

public class FileViewModel
{
  public static void GetFrameworkVersion()
  {
    string? value = string.Empty;
    string fileName = $"{AppDomain.CurrentDomain.FriendlyName}.runtimeconfig.json";

    if (File.Exists(fileName)) {
      JsonNode? jn = JsonNode.Parse(File.ReadAllText(fileName));
      value = jn!["runtimeOptions"]!["framework"]!["version"]?.GetValue<string>();
    }

    Console.WriteLine(value);
  }

  public static void ReadConnectionString()
  {
    string connectString = string.Empty;
    string fileName = "appsettings.json";

    if (File.Exists(fileName)) {
      // Read settings from file
      JsonNode? jd = JsonNode.Parse(File.ReadAllText(fileName));
      // Extract the default connection string
      connectString = jd!["ConnectionStrings"]!["DefaultConnection"]?.GetValue<string>() ?? string.Empty;
    }

    Console.WriteLine(connectString);
  }

  public static void WriteToAppSettingsFile()
  {
    string fileName = "appsettings.json";
    JsonObject? jo = null;

    if (File.Exists(fileName)) {
      // Read settings from file
      jo = JsonNode.Parse(File.ReadAllText(fileName))?.AsObject();
      if (jo != null) {
        // Locate node to add to
        JsonObject? node = jo!["AdvWorksAppSettings"]?.AsObject();
        // Add new node
        node?.Add("LastDateUsed", JsonValue.Create(DateTime.Now.ToShortDateString()));

        // Write back to file
        File.WriteAllText(fileName, jo?.ToString());
      }
    }

    Console.WriteLine(jo?.ToString());
  }

  public static void GetPhonesUsingJsonNode()
  {
    string? json = string.Empty;

    string fileName = $"{AppDomain.CurrentDomain.BaseDirectory}JsonSampleFiles\\personAddressPhones.json";
    if (File.Exists(fileName)) {
      JsonNode? jn = JsonNode.Parse(File.ReadAllText(fileName));
      json = jn!["phoneNumbers"]?.ToString();
    }

    Console.WriteLine(json);
  }

  /// <summary>
  /// NOTE: The JsonDocument is immutable (can't be changed)
  /// JsonDocument however is faster to access data than JsonNode
  /// </summary>
  public static void GetPersonUsingJsonDocument()
  {
    string? json = string.Empty;

    string fileName = $"{AppDomain.CurrentDomain.BaseDirectory}JsonSampleFiles\\person.json";
    if (File.Exists(fileName)) {
      // JsonDocument is disposable
      using JsonDocument? jd = JsonDocument.Parse(File.ReadAllText(fileName));
      JsonElement elem = jd.RootElement;
      json = elem.GetProperty("name").ToString();
    }

    Console.WriteLine(json);
  }

  public static void GetPhonesArrayFromFile()
  {
    string? json = string.Empty;

    string fileName = $"{AppDomain.CurrentDomain.BaseDirectory}JsonSampleFiles\\phones.json";
    if (File.Exists(fileName)) {
      JsonArray? ja = JsonNode.Parse(File.ReadAllText(fileName))?.AsArray();
      json = ja?.ToString();
    }

    Console.WriteLine(json);
  }
}
