﻿using Microsoft.Extensions.Configuration;
using System.Text.Json.Nodes;

namespace JsonSamples;

/// <summary>
/// To use the code in this class you must add the following two packages using the NuGet Package Manager
/// Microsoft.Extensions.Configuration
/// Microsoft.Extensions.Configuration.Json
/// </summary>
public class ConfigurationViewModel
{
  public static void GetFrameworkVersionUsing()
  {
    string? value;
    string fileName = $"{AppDomain.CurrentDomain.FriendlyName}.runtimeconfig.json";

    IConfiguration config = new ConfigurationBuilder()
      .AddJsonFile(fileName)
      .Build();

    IConfigurationSection section = config.GetSection("runtimeOptions");
    value = section["framework:version"] ?? string.Empty;

    Console.WriteLine(value);
  }

  public static void GetConfigurationValue()
  {
    string connectString;

    IConfiguration config = new ConfigurationBuilder()
      .AddJsonFile("appsettings.json")
      .Build();

    IConfigurationSection section = config.GetSection("ConnectionStrings");
    connectString = section["DefaultConnection"] ?? string.Empty;

    Console.WriteLine(connectString);
  }

  /// <summary>
  /// To use this code you must add the following package using the NuGet Package Manager
  /// Microsoft.Extensions.Configuration.Binder
  /// </summary>
  public static void BindConfigurationSection()
  {
    AppSettings entity = new();

    IConfiguration config = new ConfigurationBuilder()
      .AddJsonFile("appsettings.json")
      .Build();

    config.Bind("AdvWorksAppSettings", entity);

    Console.WriteLine(entity.ApplicationName);
  }
}
