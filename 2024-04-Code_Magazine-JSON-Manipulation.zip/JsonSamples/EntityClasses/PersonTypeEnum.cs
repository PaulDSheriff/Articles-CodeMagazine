﻿namespace JsonSamples;

public enum PersonTypeEnum
{
  Employee = 1,
  Customer = 2,
  Supervisor = 3
}
