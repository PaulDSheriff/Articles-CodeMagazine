﻿namespace JsonSamples;

public class Person
{
  public string? Name { get; set; }
  public int Age { get; set; }
  public string? SSN { get; set; }
  public bool IsActive { get; set; }

  public override string ToString()
  {
    return $"{Name}, Age={Age}, SSN={SSN}, IsActive={IsActive}";
  }
}
