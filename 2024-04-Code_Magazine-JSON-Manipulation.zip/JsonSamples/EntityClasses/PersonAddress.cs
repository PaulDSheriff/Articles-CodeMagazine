﻿namespace JsonSamples;

public class PersonAddress
{
  public string? Name { get; set; }
  public int Age { get; set; }
  public string? SSN { get; set; }
  public bool IsActive { get; set; }
  public Address Address { get; set; } = new();

  public override string ToString()
  {
    return $"{Name}, Age={Age}, SSN={SSN}, IsActive={IsActive}{Environment.NewLine}{Address}";
  }
}
