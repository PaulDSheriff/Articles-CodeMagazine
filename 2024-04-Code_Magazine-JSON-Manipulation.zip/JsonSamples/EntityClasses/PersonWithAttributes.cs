﻿using System.Text.Json.Serialization;

namespace JsonSamples;

public class PersonWithAttributes
{
  [JsonPropertyName("personName")]
  [JsonPropertyOrder(1)]
  public string? Name { get; set; }
  [JsonPropertyName("personAge")]
  [JsonPropertyOrder(2)]
  public int Age { get; set; }  
  public string? SSN { get; set; }
  public bool IsActive { get; set; }

  [JsonIgnore]
  public DateTime? CreateDate { get; set; }
  [JsonIgnore(Condition = JsonIgnoreCondition.WhenWritingNull)]
  public DateTime? ModifiedDate { get; set; }

  public override string ToString()
  {
    return $"{Name}, Age={Age}, SSN={SSN}, IsActive={IsActive}";
  }
}
