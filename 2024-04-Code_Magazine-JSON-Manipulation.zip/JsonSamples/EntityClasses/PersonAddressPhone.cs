﻿namespace JsonSamples;

public class PersonAddressPhone
{
  public string? Name { get; set; }
  public int Age { get; set; }
  public string? SSN { get; set; }
  public bool IsActive { get; set; }
  public Address Address { get; set; } = new();
  public List<Phone> PhoneNumbers { get; set; } = new();

  public override string ToString()
  {
    string ret = $"{Name}, Age={Age}, SSN={SSN}, IsActive={IsActive}{Environment.NewLine}{Address}";

    foreach (var item in PhoneNumbers) {
      ret += Environment.NewLine + item.ToString();
    }

    return ret;
  }
}
