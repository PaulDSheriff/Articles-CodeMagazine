﻿namespace JsonSamples;

public class Phone
{
  public string? Type { get; set; }
  public string? Number { get; set; }

  public override string ToString()
  {
    return $"{Type}={Number}";
  }
}
