﻿using System.Text.Json.Nodes;

namespace JsonSamples;

public class JsonArrayCreateViewModel
{
  public static void CreateNames()
  {
    JsonArray ja = [ "John", "Sally", "Charlie"];

    Console.WriteLine(ja.ToString());
    Console.WriteLine(ja.GetValueKind());
  }

  public static void CreatePersons()
  {
    JsonArray ja = [
      new JsonObject() {
        ["name"] = "John Smith",
        ["age"] = 31
      },
      new JsonObject() {
        ["name"] = "Sally Jones",
        ["age"] = 33
      }
    ];

    Console.WriteLine(ja.ToString());
    Console.WriteLine(ja.GetValueKind());
  }

  public static void GetPersonFromArray()
  {
    JsonArray ja = [
      new JsonObject() {
        ["name"] = "John Smith",
        ["age"] = 31
      },
      new JsonObject() {
        ["name"] = "Sally Jones",
        ["age"] = 33
      }
    ];

    Console.WriteLine(ja[1]!["name"]);
    Console.WriteLine(ja[1]!["age"]);
  }

  public static void InsertAndRemove()
  {
    JsonArray ja = [
     new JsonObject() {
       ["name"] = "John Smith",
       ["age"] = 31
     },
      new JsonObject() {
        ["name"] = "Sally Jones",
        ["age"] = 33
      }
    ];

    ja.Insert(0, new JsonObject() {
      ["name"] = "Charlie Chaplin",
      ["age"] = "50"
    });

    JsonObject jo = new() {
      ["name"] = "Buster Keaton",
      ["age"] = 55
    };
    ja.Add(jo);

    ja.Remove(jo);
    ja.RemoveAt(2);

    Console.WriteLine(ja.ToString());
  }
}
