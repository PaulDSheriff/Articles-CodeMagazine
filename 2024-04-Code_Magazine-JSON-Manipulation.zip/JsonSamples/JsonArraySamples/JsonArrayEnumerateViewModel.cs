﻿using System.Text.Json;
using System.Text.Json.Nodes;

namespace JsonSamples;

public class JsonArrayEnumerateViewModel
{
  public static void EnumerateArray()
  {
    // Parse string into a JsonDocument object
    using JsonDocument jd = JsonDocument.Parse(JsonStrings.PHONE_NUMBERS);

    JsonElement.ArrayEnumerator elements = jd.RootElement.EnumerateArray();
    foreach (JsonElement elem in elements) {
      Console.WriteLine($"Type={elem.GetProperty("type")}, Phone Number={elem.GetProperty("number")}");
    }
  }

  public static void IterateArray()
  {
    // Parse string into a JsonNode object
    JsonNode? jn = JsonNode.Parse(JsonStrings.PHONE_NUMBERS);

    JsonArray? nodes = jn!.AsArray();
    foreach (JsonNode? node in nodes) {
      Console.WriteLine($"Type={node!["type"]}, Phone Number={node!["number"]}");
    }
  }

  public static void GetASinglePhoneNumber()
  {
    string? value = string.Empty;

    // Create JsonNode object from Phone Numbers
    JsonNode? jn = JsonNode.Parse(JsonStrings.PHONE_NUMBERS);
    // Cast phone numbers as an array
    JsonArray ja = jn!.AsArray();
    // Search for Home number
    JsonNode? tmp = ja.FirstOrDefault(row => (string)(row!["type"]!.GetValue<string>()) == "Home");
    // Extract the home number value
    value = tmp!["number"]!.GetValue<string>();

    Console.WriteLine($"Home Number={value}");
  }
}
