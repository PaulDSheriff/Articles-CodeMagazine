﻿using System.Text.Json.Nodes;

namespace JsonSamples;

public class JsonArrayParseViewModel
{
  public static void GetPhones()
  {
    // Parse string into a JsonNode object
    JsonNode? jn = JsonNode.Parse(JsonStrings.PERSON_ADDRESS_PHONES);

    // Get the Phone Numbers Array
    JsonArray? ja = jn!["phoneNumbers"]!.AsArray();
    
    Console.WriteLine(ja.ToString());
  }
}
