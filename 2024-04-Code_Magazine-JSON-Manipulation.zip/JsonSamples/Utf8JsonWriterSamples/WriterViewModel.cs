﻿using System.Text;
using System.Text.Json;

namespace JsonSamples;

public class WriterViewModel
{
  public static void WriteJsonObject()
  {
    JsonWriterOptions options = new() {
      Indented = true
    };

    using MemoryStream ms = new();
    using Utf8JsonWriter writer = new (ms, options);

    writer.WriteStartObject();
    writer.WriteString("name", "John Smith");
    writer.WriteNumber("age", 31);
    writer.WriteBoolean("isActive", true);
    writer.WriteEndObject();
    writer.Flush();

    string json = Encoding.UTF8.GetString(ms.ToArray());

    Console.WriteLine(json);
  }

  public static void WriteJsonArrayOfStrings()
  {
    JsonWriterOptions options = new() {
      Indented = true
    };

    using MemoryStream ms = new();
    using Utf8JsonWriter writer = new(ms, options);

    writer.WriteStartArray();
    writer.WriteStringValue("John Smith");
    writer.WriteStringValue("Sally Jones");
    writer.WriteEndArray();
    writer.Flush();

    string json = Encoding.UTF8.GetString(ms.ToArray());

    Console.WriteLine(json);
  }

  public static void WriteJsonArrayOfObjects()
  {
    JsonWriterOptions options = new() {
      Indented = true
    };

    using MemoryStream ms = new();
    using Utf8JsonWriter writer = new(ms, options);

    writer.WriteStartArray();
    writer.WriteStartObject();
    writer.WriteString("name", "John Smith");
    writer.WriteNumber("age", 31);
    writer.WriteBoolean("isActive", true);
    writer.WriteEndObject();
    writer.WriteStartObject();
    writer.WriteString("name", "Sally Jones");
    writer.WriteNumber("age", 39);
    writer.WriteBoolean("isActive", true);
    writer.WriteEndObject();
    writer.WriteEndArray();
    writer.Flush();

    string json = Encoding.UTF8.GetString(ms.ToArray());

    Console.WriteLine(json);
  }
}
