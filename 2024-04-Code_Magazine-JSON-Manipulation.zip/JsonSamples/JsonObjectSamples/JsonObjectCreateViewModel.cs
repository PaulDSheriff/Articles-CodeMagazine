﻿using System.Text.Json.Nodes;

namespace JsonSamples;

public class JsonObjectCreateViewModel
{
  public static void CreatePersonUsingKeyValuePair()
  {
    JsonObject jo = new();

    jo.Add(new KeyValuePair<string, JsonNode?>("name", "John Smith"));
    jo.Add(new KeyValuePair<string, JsonNode?>("age", 31));

    // Optional Method
    //jo.Add(KeyValuePair.Create<string, JsonNode?>("name", "John Smith"));
    //jo.Add(KeyValuePair.Create<string, JsonNode?>("age", 31));

    Console.WriteLine(jo.ToString());
  }

  public static void CreatePersonUsingKeyValuePairSimpilified()
  {
    JsonObject jo =
    [
      new KeyValuePair<string, JsonNode?>("name", "John Smith"),
      new KeyValuePair<string, JsonNode?>("age", 31),
    ];

    // Display JSON
    Console.WriteLine(jo.ToString());
    // Display JSON without whitespace
    Console.WriteLine(jo.ToJsonString());
  }

  public static void CreatePersonUsingDictionary()
  {
    Dictionary<string, JsonNode?> dict = new() {
      ["name"] = "John Smith",
      ["age"] = 31
    };

    JsonObject jo = new(dict);

    Console.WriteLine(jo.ToString());
  }

  public static void CreatePersonUsingJsonValue()
  {
    JsonObject jo = new() {
      { "name", JsonValue.Create("John Smith") },
      { "age", JsonValue.Create(31) }
    };

    Console.WriteLine(jo.ToString());
  }

  public static void CreatePersonUsingJsonObject()
  {
    JsonObject jo = new() {
      ["name"] = "John Smith",
      ["age"] = 1
    };

    Console.WriteLine(jo.ToString());
  }

  public static void CreatePersonAddress()
  {
    JsonObject jo = new() {
      ["name"] = "John Smith",
      ["age"] = "31",
      ["ssn"] = null,
      ["isActive"] = true,
      ["address"] = new JsonObject() {
        ["street"] = "1 Main Street",
        ["city"] = "Nashville",
        ["stateProvince"] = "TN",
        ["postalCode"] = "37011"
      }
    };

    Console.WriteLine(jo.ToString());
  }
}
