﻿using System.Text.Json;
using System.Text.Json.Nodes;

namespace JsonSamples;

public class JsonObjectEnumerateViewModel
{
  public static void EnumerateProperties()
  {
    // Parse string into a JsonNode object
    JsonNode? jn = JsonNode.Parse(JsonStrings.PERSON);
    // Turn JsonNode into JsonObject
    JsonObject? jo = jn?.AsObject();
    // Get enumerable list of object properties
    IEnumerable<KeyValuePair<string, JsonNode?>>? properties = jo?.AsEnumerable();

    if (properties != null) {
      foreach (KeyValuePair<string, JsonNode?> prop in properties) {
        Console.WriteLine($"Name={prop.Key}, Value={prop.Value}");
      }
    }
  }

  public static void EnumerateNestedProperties()
  {
    JsonNode? jn;

    // Parse string into a JsonDocument object
    jn = JsonNode.Parse(JsonStrings.PERSON_ADDRESS);

    EnumerateObject(jn?.AsObject(), 0);
  }

  private static void EnumerateObject(JsonObject? jo, int level)
  {
    string spaces = new(' ', 2 * level);

    IEnumerable<KeyValuePair<string, JsonNode?>>? properties = jo?.AsEnumerable();
    if (properties != null) {
      foreach (KeyValuePair<string, JsonNode?> prop in properties) {
        if (prop.Value?.GetValueKind() == JsonValueKind.Object) {
          Console.WriteLine($"{spaces}Name={prop.Key}");
          EnumerateObject(prop.Value?.AsObject(), ++level);
          level--;
        }
        else {
          Console.WriteLine($"{spaces}Name={prop.Key}, Value={prop.Value}");
        }
      }
    }
  }
}
