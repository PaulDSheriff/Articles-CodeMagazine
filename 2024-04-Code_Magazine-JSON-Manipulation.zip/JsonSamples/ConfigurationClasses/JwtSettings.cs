﻿namespace JsonSamples;

public class JwtSettings
{
  public string Key { get; set; } = string.Empty; 
  public string Issuer { get; set; } = string.Empty;
  public string Audience { get; set; } = string.Empty;
  public int MinutesToExpiration { get; set; }
  public string[] AllowedIPAddresses { get; set; } = [];

  #region ToString Override
  public override string ToString()
  {
    return $"{Key} - {Issuer} - {Audience} - {MinutesToExpiration}";
  }
  #endregion
}
