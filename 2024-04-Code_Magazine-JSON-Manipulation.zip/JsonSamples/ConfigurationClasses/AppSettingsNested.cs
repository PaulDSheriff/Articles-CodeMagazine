namespace JsonSamples;

public class AppSettingsNested
{
  public string ApplicationName { get; set; } = string.Empty;

  public JwtSettings JWTSettings { get; set; } = new();
}
