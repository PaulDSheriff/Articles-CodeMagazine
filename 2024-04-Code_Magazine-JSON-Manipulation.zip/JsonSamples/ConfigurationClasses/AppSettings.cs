namespace JsonSamples;

public class AppSettings
{
  public string ApplicationName { get; set; } = string.Empty;
}
