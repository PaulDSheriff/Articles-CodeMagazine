﻿using System.Text.Json;

namespace JsonSamples;

public class JsonDocumentReadViewModel
{
  public static void GetNameAndAge()
  {
    // Parse string into a JsonDocument object
    using JsonDocument jd = JsonDocument.Parse(JsonStrings.PERSON);

    // Get a specific property from JSON
    JsonElement je = jd.RootElement!.GetProperty("name");

    // Get the numeric value from the JsonElement
    Console.WriteLine($"Name={je!.GetString()}");
    Console.WriteLine($"Age={jd.RootElement!.GetProperty("age")!.GetInt32()}");
  }

  public static void GetCity()
  {
    // Parse string into a JsonDocument object
    using JsonDocument jd = JsonDocument.Parse(JsonStrings.PERSON_ADDRESS);

    // Get a specific property from JSON
    JsonElement je = jd.RootElement.GetProperty("address").GetProperty("city");

    // Get the string value from the JsonElement
    Console.WriteLine($"City={je!.GetString()}");
  }

  public static void GetHomeNumber()
  {
    // Parse string into a JsonDocument object
    using JsonDocument jd = JsonDocument.Parse(JsonStrings.PERSON_ADDRESS_PHONES);

    // Get a specific property from JSON
    JsonElement je = jd.RootElement.GetProperty("phoneNumbers")[0].GetProperty("elem");

    // Get the string value from the JsonElement
    Console.WriteLine($"Home Number={je!.GetString()}");
  }

  public static void GetMobileNumber()
  {    
    // Parse string into a JsonDocument object
    using JsonDocument jd = JsonDocument.Parse(JsonStrings.PERSON_ADDRESS_PHONES);

    // Get a specific property from JSON
    JsonElement je = jd.RootElement.GetProperty("phoneNumbers");

    // Get an Array Enumerator
    // Apply a LINQ expression to get the correct JsonElement
    JsonElement elem = je.EnumerateArray()
      .FirstOrDefault(row => row.GetProperty("type").ToString() == "Mobile");
      
    // Get the string value from the JsonElement
    Console.WriteLine($"Mobile Number={elem.GetProperty("number").GetString()}");
  }
}
