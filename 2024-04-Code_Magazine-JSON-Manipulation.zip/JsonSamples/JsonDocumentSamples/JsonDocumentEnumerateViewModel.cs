﻿using System.Text.Json;

namespace JsonSamples;

public class JsonDocumentEnumerateViewModel
{
  public static void EnumerateProperties()
  {
    // Parse string into a JsonDocument object
    using JsonDocument jd = JsonDocument.Parse(JsonStrings.PERSON);
    
    JsonElement.ObjectEnumerator properties = jd.RootElement.EnumerateObject();
    foreach (JsonProperty prop in properties) {
      Console.WriteLine($"Name={prop.Name}, Value={prop.Value}");
    }
  }

  public static void EnumerateNestedProperties()
  {
    // Parse string into a JsonDocument object
    using JsonDocument jd = JsonDocument.Parse(JsonStrings.PERSON_ADDRESS);

    EnumerateElement(jd.RootElement, 0);
  }

  private static void EnumerateElement(JsonElement je, int level)
  {
    string spaces = new(' ', 2 * level);

    JsonElement.ObjectEnumerator properties = je.EnumerateObject();
    foreach (JsonProperty prop in properties) {
      if (prop.Value.ValueKind == JsonValueKind.Object) {
        Console.WriteLine($"{spaces}Name={prop.Name}");
        EnumerateElement(prop.Value, ++level);
        level--;
      }
      else {
        Console.WriteLine($"{spaces}Name={prop.Name}, Value={prop.Value}");
      }
    }
  }
}
