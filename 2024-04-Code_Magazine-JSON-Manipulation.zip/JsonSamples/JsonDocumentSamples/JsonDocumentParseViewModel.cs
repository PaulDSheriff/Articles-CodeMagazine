﻿using System.Text.Json;

namespace JsonSamples;

public class JsonDocumentParseViewModel
{
  public static void GetPerson()
  {
    // Parse string into a JsonDocument object
    using JsonDocument jd = JsonDocument.Parse(JsonStrings.PERSON);

    Console.WriteLine(jd.ToString());
    
    // Get Root JsonElement structure
    JsonElement je = jd.RootElement;

    Console.WriteLine(je.ToString());
    Console.WriteLine(je.ValueKind);
  }

  public static void GetPersonAddress()
  {
    // Parse string into a JsonDocument object
    using JsonDocument jd = JsonDocument.Parse(JsonStrings.PERSON_ADDRESS);

    // Get Root JsonElement structure
    JsonElement je = jd.RootElement;

    Console.WriteLine(je.ToString());
    Console.WriteLine(je.ValueKind);
  }

  public static void GetPhoneArray()
  {
    // Parse string into a JsonDocument object
    using JsonDocument jd = JsonDocument.Parse(JsonStrings.PHONE_NUMBERS);

    // Get Root JsonElement structure
    JsonElement je = jd.RootElement;

    Console.WriteLine(je.ToString());
    Console.WriteLine(je.ValueKind);
  }

  public static void GetPersonAddressPhones()
  {
    // Parse string into a JsonDocument object
    using JsonDocument jd = JsonDocument.Parse(JsonStrings.PERSON_ADDRESS_PHONES);

    // Get Root JsonElement structure
    JsonElement je = jd.RootElement;

    Console.WriteLine(je.ToString());
    Console.WriteLine(je.ValueKind);
  }
}
