﻿namespace JsonSamples;

public class JsonStrings
{
  public const string PERSON =
    @"{
      ""name"": ""John Smith"",
      ""age"": 31,
      ""ssn"": null,
      ""isActive"": true
    }";

  public const string PHONE_NUMBERS =
    @"[
        {
          ""type"": ""Home"",
          ""number"": ""615.123.4567""
        },
        {
          ""type"": ""Mobile"",
          ""number"": ""615.345.6789""
        },
        {
          ""type"": ""Work"",
          ""number"": ""615.987.6543""
        }
    ]";

  public const string PERSON_ADDRESS =
    @"{
      ""name"": ""John Smith"",
      ""age"": 31,
      ""ssn"": null,
      ""isActive"": true,
      ""address"": {
        ""street"": ""1 Main Street"",
        ""city"": ""Nashville"",
        ""state"": ""TN"",
        ""postalCode"": ""37011""
      }
    }";


  public const string PERSON_ADDRESS_PHONES =
    @"{
      ""name"": ""John Smith"",
      ""age"": 31,
      ""ssn"": null,
      ""isActive"": true,
      ""address"": {
        ""street"": ""1 Main Street"",
        ""city"": ""Nashville"",
        ""state"": ""TN"",
        ""postalCode"": ""37011""
      },
      ""phoneNumbers"": [
        {
          ""type"": ""Home"",
          ""number"": ""615.123.4567""
        },
        {
          ""type"": ""Mobile"",
          ""number"": ""615.345.6789""
        },
        {
          ""type"": ""Work"",
          ""number"": ""615.987.6543""
        }
      ]
    }";
}
