﻿using System.Text.Json;
using System.Text;

JsonWriterOptions options = new() {
  Indented = true
};

using MemoryStream ms = new();
using Utf8JsonWriter writer = new(ms, options);

writer.WriteStartArray();
writer.WriteStringValue("John Smith");
writer.WriteStringValue("Sally Jones");
writer.WriteEndArray();
writer.Flush();

string json = Encoding.UTF8.GetString(ms.ToArray());

Console.WriteLine(json);