﻿using AdventureWorks.MAUI.ConfigurationClasses;
using Common.Library;
using System.Windows.Input;

namespace AdventureWorks.MAUI.MauiViewModelClasses;

public class LoginViewModel : ViewModelBase {
  public LoginViewModel(PrivacyPolicyViewModel pviewModel, AppSettings settings) {
    _PrivacyViewModel = pviewModel;
    _Settings = settings;
  }

  #region Private Variables
  private readonly PrivacyPolicyViewModel _PrivacyViewModel;
  private AppSettings _Settings;
  #endregion

  #region Public Properties
  public AppSettings Settings {
    get { return _Settings; }
    set { _Settings = value; }
  }
  #endregion

  #region Commands
  public ICommand? PrivacyPolicyDisplay { get; private set; }
  #endregion

  #region Init Method
  public override void Init() {
    base.Init();

    // Create commands for this view
    PrivacyPolicyDisplay = new Command(async () => await PrivacyPolicyDisplayAsync());
  }
  #endregion

  #region PrivacyPolicyDisplayAsync Method
  public async Task PrivacyPolicyDisplayAsync() {
    await Shell.Current.Navigation.PushModalAsync(new Views.PrivacyPolicyView(_PrivacyViewModel));
  }
  #endregion
}
