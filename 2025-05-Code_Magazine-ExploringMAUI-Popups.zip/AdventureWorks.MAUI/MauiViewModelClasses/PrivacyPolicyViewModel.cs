﻿using Common.Library;
using System.Windows.Input;

namespace AdventureWorks.MAUI.MauiViewModelClasses;

public class PrivacyPolicyViewModel : ViewModelBase {
  #region Commands
  public ICommand? AccceptCommand { get; private set; }
  public ICommand? DontAcceptCommand { get; private set; }
  #endregion

  #region Init Method
  public override void Init() {
    base.Init();

    // Create commands for this view
    AccceptCommand = new Command(async () => await AcceptPolicyAsync());
    DontAcceptCommand = new Command(async () => await DontAcceptPolicyAsync());
  }
  #endregion

  #region AcceptPolicyAsync Method
  public async Task AcceptPolicyAsync() {
    string ret = "..?lastPage=";
    ret += $"{nameof(Views.PrivacyPolicyView)}";
    ret += "&isPrivacyPolicyAccepted=true";
    await Shell.Current.GoToAsync(ret);
  }
  #endregion

  #region DontAcceptPolicyAsync Method
  protected async Task DontAcceptPolicyAsync() {
    string ret = "..?lastPage=";
    ret += $"{nameof(Views.PrivacyPolicyView)}";
    ret += "&isPrivacyPolicyAccepted=false";
    await Shell.Current.GoToAsync(ret);
  }
  #endregion
}
