﻿using Common.Library;

namespace AdventureWorks.MAUI.ConfigurationClasses;

public class AppSettings : CommonBase {
  #region Private Variables
  private bool _IsPrivacyPolicyAccepted;
  #endregion

  #region Public Properties
  public bool IsPrivacyPolicyAccepted {
    get { return _IsPrivacyPolicyAccepted; }
    set {
      _IsPrivacyPolicyAccepted = value;
      RaisePropertyChanged(nameof(IsPrivacyPolicyAccepted));
    }
  }
  #endregion
}
