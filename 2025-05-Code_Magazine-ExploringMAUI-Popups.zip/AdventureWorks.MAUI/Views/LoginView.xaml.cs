using AdventureWorks.MAUI.MauiViewModelClasses;

namespace AdventureWorks.MAUI.Views;

[QueryProperty(nameof(LastPage), "lastPage")]
[QueryProperty(nameof(IsPrivacyPolicyAccepted), "isPrivacyPolicyAccepted")]
public partial class LoginView : ContentPage {
  public LoginView(LoginViewModel viewModel) {
    InitializeComponent();

    _ViewModel = viewModel;
  }

  private readonly LoginViewModel _ViewModel;
  public string? LastPage { get; set; }
  public bool IsPrivacyPolicyAccepted { get; set; }

  protected override void OnAppearing() {
    base.OnAppearing();

    BindingContext = _ViewModel;

    if (LastPage != null && LastPage == nameof(Views.PrivacyPolicyView)) {
      _ViewModel.Settings.IsPrivacyPolicyAccepted = IsPrivacyPolicyAccepted;
    }
    LastPage = null;
  }
}
