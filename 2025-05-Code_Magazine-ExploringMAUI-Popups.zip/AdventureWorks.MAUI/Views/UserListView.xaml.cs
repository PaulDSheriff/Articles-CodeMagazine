using AdventureWorks.MAUI.MauiViewModelClasses;

namespace AdventureWorks.MAUI.Views;

public partial class UserListView
  : ContentPage {
  public UserListView(UserViewModel viewModel) {
    InitializeComponent();

    _ViewModel = viewModel;
  }

  private readonly UserViewModel _ViewModel;

  protected async override void OnAppearing() {
    base.OnAppearing();

    BindingContext = _ViewModel;

    await _ViewModel.GetAsync();
  }
}