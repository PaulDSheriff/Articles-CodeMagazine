using AdventureWorks.MAUI.MauiViewModelClasses;

namespace AdventureWorks.MAUI.Views;

[QueryProperty(nameof(ColorId), "id")]
public partial class ColorDetailView : ContentPage {
  public ColorDetailView(ColorViewModel viewModel) {
    InitializeComponent();

    _ViewModel = viewModel;
  }

  private readonly ColorViewModel _ViewModel;
  public int ColorId { get; set; }

  protected async override void OnAppearing() {
    base.OnAppearing();

    // Set the BindingContext to the ViewModel
    BindingContext = _ViewModel;

    // Retrieve a Color
    await _ViewModel.GetAsync(ColorId);
  }
}
