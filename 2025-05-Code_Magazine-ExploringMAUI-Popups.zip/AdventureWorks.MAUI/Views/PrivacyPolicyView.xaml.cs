using AdventureWorks.MAUI.MauiViewModelClasses;

namespace AdventureWorks.MAUI.Views;

public partial class PrivacyPolicyView : ContentPage {
  public PrivacyPolicyView(PrivacyPolicyViewModel viewModel) {
    InitializeComponent();

    _ViewModel = viewModel;
  }

  private readonly PrivacyPolicyViewModel
    _ViewModel;

  protected override void OnAppearing() {
    base.OnAppearing();

    BindingContext = _ViewModel;
  }
}
