using AdventureWorks.MAUI.MauiViewModelClasses;

namespace AdventureWorks.MAUI.Views;

[QueryProperty(nameof(ProductId), "id")]
public partial class ProductDetailView : ContentPage {
  public ProductDetailView(ProductViewModel viewModel) {
    InitializeComponent();

    _ViewModel = viewModel;
  }

  private readonly ProductViewModel _ViewModel;
  public int ProductId { get; set; }

  protected async override void OnAppearing() {
    base.OnAppearing();

    // Set the Page BindingContext
    BindingContext = _ViewModel;

    // Retrieve a Product
    await _ViewModel.GetAsync(ProductId);
  }
}
