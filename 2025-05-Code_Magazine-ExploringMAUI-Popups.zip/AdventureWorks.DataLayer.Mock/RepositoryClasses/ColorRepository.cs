﻿using AdventureWorks.EntityLayer;
using Common.Library;
using System.Collections.ObjectModel;

namespace AdventureWorks.DataLayer;

/// <summary>
/// Creates fake data for Colors.
/// </summary>
public partial class ColorRepository : IRepository<Color> {
  #region GetAsync Method
  public async Task<ObservableCollection<Color>> GetAsync() {
    return await Task.FromResult(new ObservableCollection<Color>
    {
      new() {
        ColorId = 1,
        ColorName = "Black",
      },
      new() {
        ColorId = 2,
        ColorName = "Blue",
      },
      new() {
        ColorId = 3,
        ColorName = "Gray",
      },
      new() {
        ColorId = 4,
        ColorName = "Multi",
      },
      new() {
        ColorId = 5,
        ColorName = "Red",
      },
      new() {
        ColorId = 6,
        ColorName = "Silver",
      },
      new() {
        ColorId = 7,
        ColorName = "Silver/Black",
      },
      new() {
        ColorId = 8,
        ColorName = "White",
      },
      new() {
        ColorId = 9,
        ColorName = "Yellow",
      }
    });
  }
  #endregion

  #region GetAsync(id) Method
  public async Task<Color?> GetAsync(int id) {
    ObservableCollection<Color> list = await GetAsync();
    Color? entity = list.Where(row => row.ColorId == id).FirstOrDefault();

    return entity;
  }
  #endregion
}
