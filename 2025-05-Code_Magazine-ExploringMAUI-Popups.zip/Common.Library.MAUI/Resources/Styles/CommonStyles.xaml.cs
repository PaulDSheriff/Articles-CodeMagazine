namespace Common.Library.MAUI.Resources.Styles;

public partial class CommonStyles : ResourceDictionary
{
	public CommonStyles()
	{
		InitializeComponent();
	}
}