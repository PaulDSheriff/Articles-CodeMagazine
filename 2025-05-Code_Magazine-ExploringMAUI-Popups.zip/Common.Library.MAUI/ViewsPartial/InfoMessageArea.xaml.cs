namespace Common.Library.MAUI.ViewsPartial;

public partial class InfoMessageArea : ContentView
{
	public InfoMessageArea()
	{
		InitializeComponent();
	}
}