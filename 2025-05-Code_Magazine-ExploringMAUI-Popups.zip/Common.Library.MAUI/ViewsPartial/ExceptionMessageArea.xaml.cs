namespace Common.Library.MAUI.ViewsPartial;

public partial class ExceptionMessageArea : ContentView
{
	public ExceptionMessageArea()
	{
		InitializeComponent();
	}
}