namespace Common.Library.MAUI.ViewsPartial;

public partial class ValidationMessageArea : ContentView
{
	public ValidationMessageArea()
	{
		InitializeComponent();
	}
}