﻿namespace Common.Library;

public class ValidationMessage : CommonBase {
  #region Private Variables
  private string _PropertyName = string.Empty;
  private string _Message = string.Empty;
  #endregion

  #region Public Properties
  public string PropertyName {
    get { return _PropertyName; }
    set {
      _PropertyName = value;
      RaisePropertyChanged(nameof(PropertyName));
    }
  }

  public string Message {
    get { return _Message; }
    set {
      _Message = value;
      RaisePropertyChanged(nameof(Message));
    }
  }
  #endregion

  #region ToString() Override
  public override string ToString() {
    if (string.IsNullOrEmpty(PropertyName)) {
      return $"{Message}";
    }
    else {
      return $"{Message} ({PropertyName})";
    }
  }
  #endregion
}
