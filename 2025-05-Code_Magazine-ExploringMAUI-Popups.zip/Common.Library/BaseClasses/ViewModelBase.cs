﻿using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;

namespace Common.Library;

public class ViewModelBase : CommonBase {
  #region Private Variables
  private int _RowsAffected;
  private bool _IsInfoAreaVisible;
  private bool _IsExceptionAreaVisible;
  private bool _IsValidationAreaVisible;
  private ObservableCollection<ValidationMessage> _ValidationMessages = new();
  #endregion

  #region Public Properties
  public int RowsAffected {
    get { return _RowsAffected; }
    set {
      _RowsAffected = value;
      RaisePropertyChanged(nameof(RowsAffected));
    }
  }

  public bool IsInfoAreaVisible {
    get { return _IsInfoAreaVisible; }
    set {
      _IsInfoAreaVisible = value;
      RaisePropertyChanged(nameof(IsInfoAreaVisible));
    }
  }

  public bool IsExceptionAreaVisible {
    get { return _IsExceptionAreaVisible; }
    set {
      _IsExceptionAreaVisible = value;
      RaisePropertyChanged(nameof(IsExceptionAreaVisible));
    }
  }

  public bool IsValidationAreaVisible {
    get { return _IsValidationAreaVisible; }
    set {
      _IsValidationAreaVisible = value;
      RaisePropertyChanged(
        nameof(IsValidationAreaVisible));
    }
  }

  public ObservableCollection<ValidationMessage>
    ValidationMessages {
    get { return _ValidationMessages; }
    set {
      _ValidationMessages = value;
      RaisePropertyChanged(
        nameof(ValidationMessages));
    }
  }
  #endregion

  #region BeginProcessing Method
  protected virtual void BeginProcessing() {
    InfoMessage = string.Empty;
    LastErrorMessage = string.Empty;
    LastException = null;
    RowsAffected = 0;
    IsInfoAreaVisible = true;
    IsExceptionAreaVisible = false;
    IsValidationAreaVisible = false;
    ValidationMessages.Clear();
  }
  #endregion

  #region EndProcessing Methods
  protected virtual void EndProcessing() {
    if (!string.IsNullOrEmpty(LastErrorMessage) ||
        LastException != null) {
      IsExceptionAreaVisible = true;
    }
    IsValidationAreaVisible = ValidationMessages.Count > 0;
  }
  #endregion

  #region Validate Method
  public bool Validate<T>(T entity) {
    ValidationMessages.Clear();

    if (entity != null) {
      // Create instance of ValidationContext object
      ValidationContext context = new(entity, serviceProvider: null, items: null);
      List<ValidationResult> results = new();

      // Call TryValidateObject() method
      if (!Validator.TryValidateObject(entity, context, results, true)) {
        // Get validation results
        foreach (ValidationResult item in results) {
          string propName = string.Empty;
          if (item.MemberNames.Any()) {
            propName = ((string[])item.MemberNames)[0];
          }
          // Build new ValidationMessage object
          ValidationMessage msg = new() {
            Message = item.ErrorMessage ?? string.Empty,
            PropertyName = propName
          };

          // Add validation object to list
          ValidationMessages.Add(msg);
        }
      }
    }

    IsValidationAreaVisible = ValidationMessages.Count > 0;

    return !IsValidationAreaVisible;
  }
  #endregion

  #region PublishException Method
  protected virtual void PublishException(Exception ex) {
    LastException = ex;

    System.Diagnostics.Debug.WriteLine(ex.ToString());
  }
  #endregion
}
