﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Common.Library;

namespace AdventureWorks.EntityLayer;

/// <summary>
/// This class contains properties that 
/// map to each field in the dbo.User table.
/// </summary>
[Table("User", Schema = "dbo")]
public partial class User : EntityBase {
  #region Private Variables
  private int _UserId;
  private string _LoginId = string.Empty;
  private string _FirstName = string.Empty;
  private string _LastName = string.Empty;
  private string _Email = string.Empty;
  private string _Password = "P@ssW0Rd";
  private string _Phone = string.Empty;
  private string? _PhoneType;
  private bool? _IsFullTime;
  private bool? _IsEnrolledIn401k;
  private bool? _IsEnrolledInHealthCare;
  private bool? _IsEnrolledInHSA;
  private bool? _IsEnrolledInFlexTime;
  private bool? _IsEmployed;
  private DateTime? _BirthDate;
  private TimeSpan? _StartTime;
  #endregion

  #region Public Properties
  [Display(Name = "User Id")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  public int UserId {
    get { return _UserId; }
    set {
      _UserId = value;
      RaisePropertyChanged(nameof(UserId));
    }
  }

  [Display(Name = "Login Id")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [StringLength(20, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  public string LoginId {
    get { return _LoginId; }
    set {
      _LoginId = value;
      RaisePropertyChanged(nameof(LoginId));
    }
  }

  [Display(Name = "First Name")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [StringLength(50, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  public string FirstName {
    get { return _FirstName; }
    set {
      _FirstName = value;
      RaisePropertyChanged(nameof(FirstName));
    }
  }

  [Display(Name = "Last Name")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [StringLength(50, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  public string LastName {
    get { return _LastName; }
    set {
      _LastName = value;
      RaisePropertyChanged(nameof(LastName));
    }
  }

  [Display(Name = "Email")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [StringLength(256, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  [EmailAddress()]
  public string Email {
    get { return _Email; }
    set {
      _Email = value;
      RaisePropertyChanged(nameof(Email));
    }
  }

  [Display(Name = "Password")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [StringLength(50, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  public string Password {
    get { return _Password; }
    set {
      _Password = value;
      RaisePropertyChanged(nameof(Password));
    }
  }

  [Display(Name = "Phone")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [StringLength(25, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  [Phone()]
  public string Phone {
    get { return _Phone; }
    set {
      _Phone = value;
      RaisePropertyChanged(nameof(Phone));
    }
  }

  [Display(Name = "Phone Type")]
  [StringLength(10, MinimumLength = 0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  public string? PhoneType {
    get { return _PhoneType; }
    set {
      _PhoneType = value;
      RaisePropertyChanged(nameof(PhoneType));
    }
  }

  [Display(Name = "Is Full Time")]
  public bool? IsFullTime {
    get { return _IsFullTime; }
    set {
      _IsFullTime = value;
      RaisePropertyChanged(nameof(IsFullTime));
    }
  }

  [Display(Name = "Is Enrolled In 40 1K")]
  public bool? IsEnrolledIn401k {
    get { return _IsEnrolledIn401k; }
    set {
      _IsEnrolledIn401k = value;
      RaisePropertyChanged(nameof(IsEnrolledIn401k));
    }
  }

  [Display(Name = "Is Enrolled In Health Care")]
  public bool? IsEnrolledInHealthCare {
    get { return _IsEnrolledInHealthCare; }
    set {
      _IsEnrolledInHealthCare = value;
      RaisePropertyChanged(nameof(IsEnrolledInHealthCare));
    }
  }

  [Display(Name = "Is Enrolled In Hsa")]
  public bool? IsEnrolledInHSA {
    get { return _IsEnrolledInHSA; }
    set {
      _IsEnrolledInHSA = value;
      RaisePropertyChanged(nameof(IsEnrolledInHSA));
    }
  }

  [Display(Name = "Is Enrolled In Flex Time")]
  public bool? IsEnrolledInFlexTime {
    get { return _IsEnrolledInFlexTime; }
    set {
      _IsEnrolledInFlexTime = value;
      RaisePropertyChanged(nameof(IsEnrolledInFlexTime));
    }
  }

  [Display(Name = "Is Employed")]
  public bool? IsEmployed {
    get { return _IsEmployed; }
    set {
      _IsEmployed = value;
      RaisePropertyChanged(nameof(IsEmployed));
    }
  }

  [Display(Name = "Birth Date")]
  public DateTime? BirthDate {
    get { return _BirthDate; }
    set {
      _BirthDate = value;
      RaisePropertyChanged(nameof(BirthDate));
    }
  }

  [Display(Name = "Start Time")]
  public TimeSpan? StartTime {
    get { return _StartTime; }
    set {
      _StartTime = value;
      RaisePropertyChanged(nameof(StartTime));
    }
  }

  public string FullName {
    get { return FirstName + " " + LastName; }
  }

  public string LastNameFirstName {
    get { return LastName + ", " + FirstName; }
  }
  #endregion

  #region ToString Override
  public override string ToString() {
    return $"{LastName}";
  }
  #endregion
}
