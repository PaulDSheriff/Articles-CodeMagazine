﻿#nullable disable

using AdoNetWrapper.Common;
using ADONETWrapperTimerSample.RepositoryClasses;

namespace ADONETWrapperTimerSample.DatabaseContexts;

public class PaulsAutoPartsAdoNetDbContext : SqlServerDatabaseContext {
  public PaulsAutoPartsAdoNetDbContext(string connectString) : base(connectString) {
    Init();
  }

  public virtual void Init() {
    Database = new(this);
    VehicleTypes = new(this);
  }

  public RepositoryBase Database { get; set; }
  public VehicleTypeRepository VehicleTypes { get; set; }
}
