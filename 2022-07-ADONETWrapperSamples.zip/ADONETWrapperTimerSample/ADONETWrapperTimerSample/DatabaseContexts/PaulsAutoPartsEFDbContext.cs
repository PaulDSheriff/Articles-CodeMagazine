#nullable disable

using Microsoft.EntityFrameworkCore;

using ADONETWrapperTimerSample.EntityLayer;

namespace ADONETWrapperTimerSample.DatabaseContexts;

public partial class PaulsAutoPartsEFDbContext : DbContext {
  public PaulsAutoPartsEFDbContext() : base() { }

  public virtual DbSet<VehicleType> VehicleTypes { get; set; }
  
  protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) {
    optionsBuilder.UseSqlServer(@"Server=Localhost;Database=PaulsAutoParts;Integrated Security=Yes");
  }

  protected override void OnModelCreating(ModelBuilder modelBuilder) {
    base.OnModelCreating(modelBuilder);
  }
}