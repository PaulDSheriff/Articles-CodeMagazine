﻿#nullable disable

using AdoNetWrapper.Common;
using ADONETWrapperTimerSample.DatabaseContexts;
using ADONETWrapperTimerSample.EntityLayer;

namespace ADONETWrapperTimerSample.RepositoryClasses;

public class VehicleTypeRepository : RepositoryBase {
  public VehicleTypeRepository(PaulsAutoPartsAdoNetDbContext context) : base(context) {
  }

  public virtual List<VehicleType> Search() {
    return base.Search<VehicleType>();
  }

  public virtual List<VehicleType> Search(VehicleTypeSearch search) {
    return base.Search<VehicleType, VehicleTypeSearch>(search);
  }

  public virtual VehicleType Find(int id) {
    return base.Find<VehicleType>(id);
  }

  public bool Validate(VehicleType product) {
    base.Validate<VehicleType>(product);

    // Perform any other validation here
   
    return ValidationMessages.Count == 0;
  }

  public VehicleType Insert(VehicleType entity) {
    entity = base.Insert<VehicleType>(entity);

    // OPTIONAL: Re-read from database to get any other generated values
    //product = Find(product.Id);

    return entity;
  }

  public VehicleType Update(VehicleType entity) {
    entity = base.Update<VehicleType>(entity);

    // OPTIONAL: Re-read from database to get any other generated values
    //product = Find(product.Id);

    return entity;
  }

  public bool Delete(int id) {
    VehicleType product = base.Find<VehicleType>(id);

    return Delete(product);
  }

  public bool Delete(VehicleType entity) {
    return base.Delete<VehicleType>(entity);
  }

}
