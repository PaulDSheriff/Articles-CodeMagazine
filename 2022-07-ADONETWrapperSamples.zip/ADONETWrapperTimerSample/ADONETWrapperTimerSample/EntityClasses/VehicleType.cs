#nullable disable

using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ADONETWrapperTimerSample.EntityLayer
{
  /// <summary>
  /// This class contains properties that map to each field in the Lookup.VehicleType table.
  /// </summary>
  [Table("VehicleType", Schema = "Lookup")]
  public partial class VehicleType
  {
    /// <summary>
    /// Get/Set Vehicle Type Id
    /// </summary>
    [Key]
    [Display(Name = "Vehicle Type Id")]
    [Required(ErrorMessage = "{0} must be filled in.")]
    [Column("VehicleTypeId", TypeName = "int")]
    public int VehicleTypeId { get; set; }

    /// <summary>
    /// Get/Set Year
    /// </summary>
    [Display(Name = "Year")]
    [Required(ErrorMessage = "{0} must be filled in.")]
    [Column("Year", TypeName = "int")]
    public int Year { get; set; }

    /// <summary>
    /// Get/Set Make
    /// </summary>
    [Display(Name = "Make")]
    [Required(ErrorMessage = "{0} must be filled in.")]
    [Column("Make", TypeName = "nvarchar")]
    [StringLength(20, MinimumLength=0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
    [MaxLength(20)]
    public string Make { get; set; }

    /// <summary>
    /// Get/Set Model
    /// </summary>
    [Display(Name = "Model")]
    [Required(ErrorMessage = "{0} must be filled in.")]
    [Column("Model", TypeName = "nvarchar")]
    [StringLength(50, MinimumLength=0, ErrorMessage = "{0} must be between {2} and {1} characters long.")]
    [MaxLength(50)]
    public string Model { get; set; }

    #region ToString Override
    public override string ToString() {
      return $"{Make} ({VehicleTypeId})";
    }
    #endregion
  }
}
