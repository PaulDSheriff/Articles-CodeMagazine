﻿#nullable disable

using System;
using System.Data;
using System.Text;

namespace AdoNetWrapper.Common;

public partial class DatabaseException : Exception {
  #region Constructors
  public DatabaseException() : base() { }
  public DatabaseException(string message) : base(message) { }
  public DatabaseException(string message, Exception innerException) : base(message, innerException) { }
  public DatabaseException(string message, Exception innerException, IDbCommand cmd) : base(message, innerException) {
    CommandObject = cmd;
  }
  #endregion

  #region Properties
  public IDbCommand CommandObject { get; set; }
  #endregion

  #region GetCommandParametersAsString Method
  /// <summary>
  /// Gets all parameter names and values from the Command property and returns them all as a CRLF delimited string
  /// </summary>
  /// <returns>A string with all parameter names and values</returns>
  public virtual string GetCommandParametersAsString() {
    StringBuilder sb = new(1024);

    if (CommandObject != null && CommandObject.Parameters != null && CommandObject.Parameters.Count > 0) {
      foreach (IDbDataParameter param in CommandObject.Parameters) {
        sb.Append("  " + param.ParameterName);
        if (param.Value == null)
          sb.AppendLine(" = null");
        else
          sb.AppendLine(" = " + param.Value.ToString());
      }
    }

    return sb.ToString();
  }
  #endregion

  #region HideLoginInfoForConnectionString Method
  /// <summary>
  /// Looks for UID, User Id, Pwd, Password, etc. in a connection string and replaces their 'values' with astericks.
  /// </summary>
  /// <param name="connectString">The connection string to check</param>
  /// <returns>A string with hidden user id and password values</returns>
  public virtual string HideLoginInfoForConnectionString(string connectString) {
    return connectString;
  }
  #endregion

  #region GetDatabaseSpecificError
  protected virtual string GetDatabaseSpecificError(Exception ex) {
    return string.Empty;
  }
  #endregion

  #region GetInnerExceptionInfo Method
  protected virtual string GetInnerExceptionInfo() {
    StringBuilder sb = new(1024);
    Exception ex;
    int index = 1;

    ex = InnerException;
    while (ex != null) {
      sb.AppendLine();
      // See if there is a database-specific error
      var dbSpecific = GetDatabaseSpecificError(ex);
      // If no database-specific error, get normal exception info
      if (string.IsNullOrEmpty(dbSpecific)) {
        sb.AppendLine($"  **** BEGIN: Inner Exception #{index.ToString()} ****");
        sb.AppendLine($"  Type: {ex.GetType().FullName}");
        sb.AppendLine($"  Message: {ex.Message}");
        sb.AppendLine($"  Source: {ex.Source}");
        sb.AppendLine($"  **** END: Inner Exception #{index.ToString()} ****");
        index++;
      }
      else {
        sb.Append(dbSpecific);
      }
      // Get next inner exception
      ex = ex.InnerException;
    }

    return sb.ToString();
  }
  #endregion

  #region Override of ToString Method
  /// <summary>
  /// Gathers all information from the exception information gathered and returns a string
  /// </summary>
  /// <returns>A database specific error string</returns>
  public override string ToString() {
    StringBuilder sb = new(1024);
    string exDate = DateTime.Now.ToString();

    sb.AppendLine(new('-', 52));
    sb.AppendLine($"BEGIN: Exception Generated at {exDate}");
    sb.AppendLine(new('-', 52));
    if (!string.IsNullOrEmpty(Message)) {
      sb.AppendLine($"Message(s): {Message}");
    }
    if (CommandObject != null) {
      if (!string.IsNullOrEmpty(CommandObject.Connection.ConnectionString)) {
        sb.AppendLine($"Connection String: {HideLoginInfoForConnectionString(CommandObject.Connection.ConnectionString)}");
      }
      if (!string.IsNullOrEmpty(CommandObject.CommandText)) {
        sb.AppendLine($"SQL: {CommandObject.CommandText}");
      }
      if (CommandObject.Parameters != null && CommandObject.Parameters.Count > 0) {
        sb.AppendLine("Command Parameters:");
        sb.Append(GetCommandParametersAsString());
      }
    }
    // Get Inner Exception information
    var value = GetInnerExceptionInfo();
    if (!string.IsNullOrEmpty(value)) {
      sb.AppendLine(value);
    }
    // Stack Trace Info
    if (!string.IsNullOrEmpty(StackTrace)) {
      sb.AppendLine($"================== BEGIN: Stack Trace Info ==================");
      sb.AppendLine(StackTrace);
      sb.AppendLine($"================== END: Stack Trace Info ==================");
    }
    sb.AppendLine(new('-', 52));
    sb.AppendLine($"END: Exception Generated at {exDate}");
    sb.AppendLine(new('-', 52));

    return sb.ToString();
  }
  #endregion
}