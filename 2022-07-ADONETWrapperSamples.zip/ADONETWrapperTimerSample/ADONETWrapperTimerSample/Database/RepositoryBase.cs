﻿#nullable disable

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Reflection;
using System.Text;

namespace AdoNetWrapper.Common;

/// <summary>
/// Contains generic methods to populate entity class(es) from a table using ADO.NET
/// </summary>
public class RepositoryBase {
  #region Constructor
  public RepositoryBase(SqlServerDatabaseContext context) {
    DbContext = context;
    SchemaName = "dbo";
    TableName = string.Empty;
    SQL = string.Empty;
    Columns = new();
    ValidationMessages = new();
  }
  #endregion

  #region Private Variables
  protected readonly SqlServerDatabaseContext DbContext;
  #endregion

  #region Public Properties
  public string SchemaName { get; set; }
  public string TableName { get; set; }
  public string SQL { get; set; }
  public List<ColumnMapper> Columns { get; set; }
  public List<ValidationMessage> ValidationMessages { get; set; }
  #endregion

  #region BuildColumnCollection Method
  protected List<ColumnMapper> BuildColumnCollection<TEntity>() {
    List<ColumnMapper> ret = new();
    ColumnMapper colMap;

    // Get all the properties in <TEntity>
    PropertyInfo[] props = typeof(TEntity).GetProperties();

    // Loop through all properties
    foreach (PropertyInfo prop in props) {
      // Does the Property have a [NotMapped] attribute?
      NotMappedAttribute nm = prop.GetCustomAttribute<NotMappedAttribute>();
      // Only add those properties that map to a column
      if (nm == null) {
        // Create a column mapping object
        colMap = new() {
          // Set column properties
          PropertyInfo = prop
        };

        // Is the column name in a [Column] attribute?
        ColumnAttribute ca = prop.GetCustomAttribute<ColumnAttribute>();
        if (ca == null && !string.IsNullOrEmpty(ca.Name)) {
          // Property name is the same as the column name
          colMap.ColumnName = prop.Name;
        }
        else {
          // Set column name from [Column] attribute
          colMap.ColumnName = ca.Name;
        }

        // Is the column a primary [Key]?
        KeyAttribute key = prop.GetCustomAttribute<KeyAttribute>();
        colMap.IsKeyField = key != null;

        // Check for [DatabaseGenerated] attribute
        // Is the column an auto-incrementing column?
        DatabaseGeneratedAttribute dg = prop.GetCustomAttribute<DatabaseGeneratedAttribute>();
        if (dg != null) {
          colMap.IsAutoIncrementing = dg.DatabaseGeneratedOption == DatabaseGeneratedOption.Identity || dg.DatabaseGeneratedOption == DatabaseGeneratedOption.Computed;
        }

        // Create collection of columns
        ret.Add(colMap);
      }
    }

    return ret;
  }
  #endregion

  #region BuildSelectSql Method
  protected string BuildSelectSql<TEntity>() {
    StringBuilder sb = new(2048);
    string comma = string.Empty;
    Type typ = typeof(TEntity);

    // Build Column Mapping Collection
    Columns = BuildColumnCollection<TEntity>();

    // Is there is a [Table] attribute?
    TableAttribute table = typ.GetCustomAttribute<TableAttribute>();
    if (table == null) {
      // Assume table name is the entity class name
      TableName = typ.Name;
    }
    else {
      // Set properties from [Table] attribute
      TableName = table.Name;
      SchemaName = table.Schema;
    }

    // Build the SELECT statement
    sb.Append("SELECT");
    foreach (ColumnMapper item in Columns) {
      // Add column
      sb.Append($"{comma} [{item.ColumnName}]");
      comma = ",";
    }
    // Add FROM schema.table
    sb.Append($" FROM {SchemaName}.{TableName}");

    return sb.ToString();
  }
  #endregion

  #region BuildEntityList Method
  protected virtual List<TEntity> BuildEntityList<TEntity>(IDataReader rdr) {
    List<TEntity> ret = new();

    // Loop through all rows in the data reader
    while (rdr.Read()) {
      // Create new instance of Entity
      TEntity entity = Activator.CreateInstance<TEntity>();

      // Loop through columns collection
      for (int index = 0; index < Columns.Count; index++) {
        // Get the value from the reader
        var value = rdr[Columns[index].ColumnName];
        // Assign the value to the property if not null
        if (!value.Equals(DBNull.Value)) {
          Columns[index].PropertyInfo.SetValue(entity, value, null);
        }
      }

      // Add new entity to the list
      ret.Add(entity);
    }

    return ret;
  }
  #endregion

  #region BuildSearchColumnCollection Method
  protected List<ColumnMapper> BuildSearchColumnCollection<TEntity, TSearch>(TSearch search) {
    List<ColumnMapper> ret = new();
    ColumnMapper colMap;
    object value;

    // Get all the properties in <TSearch>
    PropertyInfo[] props = typeof(TSearch).GetProperties();

    // Loop through all properties
    foreach (PropertyInfo prop in props) {
      value = prop.GetValue(search, null);

      // Is the search property filled in?
      if (value != null || (DbContext.CommandObject != null && DbContext.CommandObject.CommandType == CommandType.StoredProcedure)) {
        // Create a column mapping object
        colMap = new() {
          ColumnName = prop.Name,
          PropertyInfo = prop,
          SearchOperator = "=",
          ParameterValue = value
        };

        // Does the Property have a [Search] attribute
        SearchAttribute sa = prop.GetCustomAttribute<SearchAttribute>();
        if (sa != null) {
          // Set column name from [Search] attribute
          colMap.ColumnName = string.IsNullOrWhiteSpace(sa.ColumnName) ? colMap.ColumnName : sa.ColumnName;
          colMap.SearchOperator = sa.SearchOperator ?? "=";
        }

        // Does the Property have a [OutputParam] attribute
        OutputParamAttribute oa = prop.GetCustomAttribute<OutputParamAttribute>();
        if (oa != null) {
          colMap.Direction = oa.Direction;
          colMap.DbType = oa.DbType;
          colMap.Size = oa.Size;
        }

        // Create collection of columns
        ret.Add(colMap);
      }
    }

    return ret;
  }
  #endregion

  #region BuildSearchWhereClause Method
  protected string BuildSearchWhereClause(List<ColumnMapper> columns) {
    StringBuilder sb = new(1024);
    string and = string.Empty;

    // Create WHERE clause
    sb.Append(" WHERE");
    foreach (var item in columns.Where(c => c.Direction == ParameterDirection.Input || c.Direction == ParameterDirection.InputOutput)) {
      sb.Append($"{and} {item.ColumnName} {item.SearchOperator} {DbContext.ParameterPrefix}{item.ColumnName}");
      and = " AND";
    }

    return sb.ToString();
  }
  #endregion

  #region BuildWhereClauseParameters Method
  protected void BuildWhereClauseParameters(IDbCommand cmd, List<ColumnMapper> whereColumns) {
    // Add parameters for each key value passed in
    foreach (ColumnMapper item in whereColumns.Where(c => c.Direction == ParameterDirection.Input || c.Direction == ParameterDirection.InputOutput)) {
      var param = DbContext.CreateParameter(item.ColumnName,
                    item.SearchOperator == "LIKE" ? item.ParameterValue + "%" : item.ParameterValue);
      param.Value = param.Value ?? DBNull.Value;
      cmd.Parameters.Add(param);
      if (cmd.CommandType != CommandType.StoredProcedure) {
        // Store parameter info
        Columns.Find(c => c.ColumnName == item.ColumnName).ParameterValue = item.ParameterValue;
      }
    }
  }
  #endregion

  #region BuildOutputParameters Method
  protected void BuildOutputParameters(IDbCommand cmd, List<ColumnMapper> columns) {
    // Add output parameters
    foreach (ColumnMapper item in columns.Where(c => c.Direction == ParameterDirection.Output)) {
      var param = DbContext.CreateParameter(item.ColumnName, null);
      param.Direction = item.Direction;
      param.DbType = item.DbType;
      param.Size = item.Size;
      cmd.Parameters.Add(param);
    }
  }
  #endregion

  #region GetOutputParameters Method
  protected void GetOutputParameters<TSearch>(TSearch search, List<ColumnMapper> columns) {
    // Get output parameters
    foreach (ColumnMapper item in columns.Where(c => c.Direction == ParameterDirection.Output || c.Direction == ParameterDirection.InputOutput)) {
      // Get the parameter
      var param = DbContext.GetParameter(item.ColumnName);
      // Set the value on the Search object
      typeof(TSearch).GetProperty(item.ColumnName).SetValue(search, param.Value, null);
    }
  }
  #endregion

  #region Search Methods
  public virtual List<TEntity> Search<TEntity>(IDbCommand cmd) {
    List<TEntity> ret;

    // Build Columns if needed
    if (Columns.Count == 0) {
      Columns = BuildColumnCollection<TEntity>();
    }

    // Set Command Object
    DbContext.CommandObject = cmd;

    // Get the list of entity objects
    ret = BuildEntityList<TEntity>(DbContext.CreateDataReader());

    return ret;
  }

  public virtual List<TEntity> Search<TEntity>() {
    // Build SQL from Entity class
    SQL = BuildSelectSql<TEntity>();

    // Create Command Object with SQL
    DbContext.CreateCommand(SQL);

    return Search<TEntity>(DbContext.CommandObject);
  }

  public virtual List<TEntity> Search<TEntity, TSearch>(TSearch search) {
    // Build SQL from Entity class
    SQL = BuildSelectSql<TEntity>();

    // Build a collection of ColumnMapper objects based on properties in the TSearch object
    var searchColumns = BuildSearchColumnCollection<TEntity, TSearch>(search);

    // Build the WHERE clause for Searching
    SQL += BuildSearchWhereClause(searchColumns);

    // CAUSE ERROR IN SQL
    SQL = SQL.Substring(0, 20);

    // Create DB Context
    DbContext.CreateCommand(SQL);

    // Add any Parameters?
    if (searchColumns != null && searchColumns.Count > 0) {
      BuildWhereClauseParameters(DbContext.CommandObject, searchColumns);
    }

    return Search<TEntity>(DbContext.CommandObject);
  }

  public virtual List<TEntity> Search<TEntity, TSearch>(TSearch search, string sql) {
    List<ColumnMapper> searchColumns = new();
    List<TEntity> ret;

    // Store the SQL submitted
    SQL = sql;

    // Build columns collection for entity class
    Columns = BuildColumnCollection<TEntity>();

    // Create command object
    DbContext.CreateCommand(SQL);
    if (!sql.Contains("SELECT ")) {
      DbContext.CommandObject.CommandType = CommandType.StoredProcedure;
    }

    if (search != null) {
      // Build a collection of ColumnMapper objects based on properties in the TSearch object
      searchColumns = BuildSearchColumnCollection<TEntity, TSearch>(search);

      // Add any Parameters?
      if (searchColumns != null && searchColumns.Count > 0) {
        BuildWhereClauseParameters(DbContext.CommandObject, searchColumns);
      }

      // Add any Output Parameters?
      if (searchColumns.Where(c => c.Direction == ParameterDirection.Output || c.Direction == ParameterDirection.InputOutput).Count() > 0) {
        BuildOutputParameters(DbContext.CommandObject, searchColumns);
      }
    }

    // Build the list of entity objects
    ret = BuildEntityList<TEntity>(DbContext.CreateDataReader());

    // Must close DataReader for output parameters to be available
    DbContext.DataReaderObject.Close();

    // Retrieve Any Output Parameters?
    GetOutputParameters(search, searchColumns);

    return ret;
  }
  #endregion

  #region Find Methods
  public TEntity Find<TEntity>(IDbCommand cmd) where TEntity : class {
    // To assign null, use 'where TEntity : class'
    TEntity ret = null;

    // Build Columns if needed
    if (Columns.Count == 0) {
      Columns = BuildColumnCollection<TEntity>();
    }

    // Get the entity
    var list = Search<TEntity>(cmd);

    // Check for a single record
    if (list != null && list.Count > 0) {
      // Assign the object to the return value
      ret = list[0];
    }

    return ret;
  }

  /// <summary>
  /// Locates an entity within the given primary key value(s)
  /// A null is returned if no entity is located 
  /// </summary>
  /// <typeparam name="TEntity">The type of object to return</typeparam>
  /// <param name="keyValues">A parameter array of value(s) to search for</param>
  /// <returns>A single TEntity object</returns>
  public TEntity Find<TEntity>(params Object[] keyValues) where TEntity : class {
    // To assign null, use 'where TEntity : class'
    TEntity ret = null;

    if (keyValues != null) {
      List<ColumnMapper> searchColumns;

      // Build SQL from Entity class
      SQL = BuildSelectSql<TEntity>();

      // Build a collection of ColumnMapper objects based on [Key] attribute
      searchColumns = Columns.Where(col => col.IsKeyField).ToList();

      // Number of [Key] attributes on entity class
      // must match the number of key values passed in
      if (searchColumns.Count != keyValues.Length) {
        throw new ApplicationException("Not enough parameters passed to Find() method, or not enough [Key] attributes on the entity class.");
      }

      // Set the values into the searchColumns
      for (int i = 0; i < searchColumns.Count; i++) {
        searchColumns[i].ParameterValue = keyValues[i];
        searchColumns[i].SearchOperator = "=";
      }

      // Build the WHERE clause for Searching
      SQL += BuildSearchWhereClause(searchColumns);

      // Create command object
      DbContext.CreateCommand(SQL);

      // Add any Parameters?
      if (searchColumns != null && searchColumns.Count > 0) {
        BuildWhereClauseParameters(DbContext.CommandObject, searchColumns);
      }

      // Get the entity
      ret = Find<TEntity>(DbContext.CommandObject);
    }

    return ret;
  }
  #endregion

  #region ExecuteScalar Methods
  public virtual object ExecuteScalar(IDbCommand cmd) {
    object ret = null;

    try {
      // Open the Connection
      DbContext.CommandObject.Connection.Open();

      // Call the ExecuteScalar() method
      ret = DbContext.CommandObject.ExecuteScalar();
    }
    catch (Exception ex) {
      DbContext.HandleException(ex);
    }

    return ret;
  }

  public virtual object ExecuteScalar(string sql) {
    // Store the SQL submitted
    SQL = sql;

    // Create Command object with SQL
    DbContext.CreateCommand(SQL);

    // Return the value
    return ExecuteScalar(DbContext.CommandObject);
  }
  #endregion

  #region ExecuteNonQuery Methods
  public virtual int ExecuteNonQuery(IDbCommand cmd) {
    int ret = 0;

    try {
      // Open the Connection
      DbContext.CommandObject.Connection.Open();

      // Call the ExecuteNonQuery() method
      ret = DbContext.CommandObject.ExecuteNonQuery();
    }
    catch (Exception ex) {
      DbContext.HandleException(ex);
    }

    return ret;
  }

  public virtual int ExecuteNonQuery(string sql) {
    // Store the SQL submitted
    SQL = sql;

    // Create Command object with SQL
    DbContext.CreateCommand(SQL);

    // Execute the Query
    return ExecuteNonQuery(DbContext.CommandObject);
  }
  #endregion

  #region Insert Method
  public virtual TEntity Insert<TEntity>(TEntity entity) {
    if (Validate<TEntity>(entity)) {
      // Build INSERT Statement
      SQL = BuildInsertStatement<TEntity>(entity);

      // Build Command Object
      DbContext.CreateCommand(SQL);

      // Build Parameters
      BuildParametersForModification(DbContext.CommandObject, Columns);

      // Submit the Query
      ExecuteNonQuery(DbContext.CommandObject);

      // Get IDENTITY if needed
      GetIdentity<TEntity>(DbContext.CommandObject, entity);
    }

    return entity;
  }
  #endregion

  #region GetIdentity Method
  protected virtual void GetIdentity<TEntity>(IDbCommand cmd, TEntity entity) {
    if (Columns.Where(c => c.IsAutoIncrementing).Count() > 0) {
      ColumnMapper colMap = Columns.Find(c => c.IsAutoIncrementing);
      DbContext.GetIdentity(cmd, entity, colMap.PropertyInfo);
    }
  }
  #endregion

  #region BuildParametersForModification Method
  protected void BuildParametersForModification(IDbCommand cmd, List<ColumnMapper> columns) {
    // Add parameters for each value passed in
    foreach (ColumnMapper item in columns) {
      var param = DbContext.CreateParameter(item.ColumnName, item.ParameterValue ?? DBNull.Value);
      cmd.Parameters.Add(param);
    }
  }
  #endregion

  #region SetColumnValues Method
  protected void SetColumnValues<TEntity>(TEntity entity) {
    // Loop through all properties
    foreach (ColumnMapper colMap in Columns) {

      // Set property value
      colMap.ParameterValue = colMap.PropertyInfo.GetValue(entity);
    }
  }
  #endregion

  #region BuildInsertStatement Method
  protected string BuildInsertStatement<TEntity>(TEntity entity) {
    StringBuilder sb = new(2048);
    string comma = string.Empty;
    Type typ = typeof(TEntity);

    // Build Column Mapping Collection
    Columns = BuildColumnCollection<TEntity>();
    // Set Values into ColumnMapper Objects
    SetColumnValues<TEntity>(entity);

    // Is there is a [Table] attribute?
    TableAttribute table = typ.GetCustomAttribute<TableAttribute>();
    if (table == null) {
      // Assume table name is the entity class name
      TableName = typ.Name;
    }
    else {
      // Set properties from [Table] attribute
      TableName = table.Name;
      SchemaName = table.Schema;
    }

    // Build the SELECT statement
    sb.Append($"INSERT INTO {SchemaName}.{TableName} (");
    foreach (ColumnMapper item in Columns.Where(c => !c.IsAutoIncrementing)) {
      // Add column
      sb.Append($"{comma}[{item.ColumnName}]");
      comma = ", ";
    }
    sb.Append(") VALUES (");
    comma = string.Empty;
    foreach (ColumnMapper item in Columns.Where(c => !c.IsAutoIncrementing)) {
      // Add Value
      sb.Append($"{comma}{DbContext.ParameterPrefix}{item.ColumnName}");
      comma = ", ";
    }
    sb.Append(")");

    return sb.ToString();
  }
  #endregion

  #region Update Method
  public virtual TEntity Update<TEntity>(TEntity entity) {
    if (Validate<TEntity>(entity)) {
      // Build UPDATE Statement
      SQL = BuildUpdateStatement<TEntity>(entity);

      // Build Command Object
      DbContext.CreateCommand(SQL);

      // Build Parameters
      BuildParametersForModification(DbContext.CommandObject, Columns);

      // Submit the Query
      ExecuteNonQuery(DbContext.CommandObject);
    }

    return entity;
  }
  #endregion

  #region BuildUpdateStatement Method
  protected string BuildUpdateStatement<TEntity>(TEntity entity) {
    StringBuilder sb = new(2048);
    string comma = string.Empty;
    string and = string.Empty;
    Type typ = typeof(TEntity);

    // Build Column Mapping Collection
    Columns = BuildColumnCollection<TEntity>();
    // Set Values into ColumnMapper Objects
    SetColumnValues<TEntity>(entity);

    // Is there is a [Table] attribute?
    TableAttribute table = typ.GetCustomAttribute<TableAttribute>();
    if (table == null) {
      // Assume table name is the entity class name
      TableName = typ.Name;
    }
    else {
      // Set properties from [Table] attribute
      TableName = table.Name;
      SchemaName = table.Schema;
    }

    // Build the UPDATE statement
    sb.Append($"UPDATE {SchemaName}.{TableName} SET");
    foreach (ColumnMapper item in Columns.Where(c => !c.IsAutoIncrementing)) {
      // Add column
      sb.Append($"{comma}[{item.ColumnName}] = {DbContext.ParameterPrefix}{item.ColumnName}");
      comma = ", ";
    }
    sb.Append(" WHERE ");
    foreach (ColumnMapper item in Columns.Where(c => c.IsKeyField)) {
      // Add WHERE Clause
      sb.Append($"{and}{item.ColumnName} = {DbContext.ParameterPrefix}{item.ColumnName}");
      and = " AND ";
    }

    return sb.ToString();
  }
  #endregion

  #region Delete Method
  public virtual bool Delete<TEntity>(TEntity entity) {
    bool ret = true;

    // Build DELETE Statement
    SQL = BuildDeleteStatement<TEntity>(entity);

    // Build Command Object
    DbContext.CreateCommand(SQL);

    // Build Parameters
    BuildWhereClauseParameters(DbContext.CommandObject, Columns.Where(c => c.IsKeyField).ToList());

    // Submit the Query
    ExecuteNonQuery(DbContext.CommandObject);

    return ret;
  }
  #endregion

  #region BuildDeleteStatement Method
  protected string BuildDeleteStatement<TEntity>(TEntity entity) {
    StringBuilder sb = new(2048);
    string comma = string.Empty;
    string and = string.Empty;
    Type typ = typeof(TEntity);

    // Build Column Mapping Collection
    Columns = BuildColumnCollection<TEntity>();
    // Set Values into ColumnMapper Objects
    SetColumnValues<TEntity>(entity);

    // Is there is a [Table] attribute?
    TableAttribute table = typ.GetCustomAttribute<TableAttribute>();
    if (table == null) {
      // Assume table name is the entity class name
      TableName = typ.Name;
    }
    else {
      // Set properties from [Table] attribute
      TableName = table.Name;
      SchemaName = table.Schema;
    }

    // Build the DELETE statement
    sb.Append($"DELETE FROM {SchemaName}.{TableName}");
    sb.Append(" WHERE ");
    foreach (ColumnMapper item in Columns.Where(c => c.IsKeyField)) {
      // Add WHERE Clause
      sb.Append($"{and}{item.ColumnName} = {DbContext.ParameterPrefix}{item.ColumnName}");
      and = " AND ";
    }

    return sb.ToString();
  }
  #endregion

  #region Validate Method
  public virtual bool Validate<TEntity>(TEntity entity) {
    string propName;
    ValidationMessages.Clear();

    if (entity != null) {
      ValidationContext context = new(entity, serviceProvider: null, items: null);
      List<ValidationResult> results = new();

      if (!Validator.TryValidateObject(entity, context, results, true)) {
        foreach (ValidationResult item in results) {
          propName = string.Empty;
          if (((string[])item.MemberNames).Length > 0) {
            propName = ((string[])item.MemberNames)[0];
          }
          ValidationMessages.Add(new() { Message = item.ErrorMessage, PropertyName = propName });
        }
      }
    }

    return (ValidationMessages.Count == 0);
  }
  #endregion
}
