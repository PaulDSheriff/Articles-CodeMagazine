﻿#nullable disable

namespace AdoNetWrapper.Common;

public class ValidationMessage {
  public string PropertyName { get; set; }
  public string Message { get; set; }

  public override string ToString() {
    return $"{PropertyName} - {Message}";
  }
}
