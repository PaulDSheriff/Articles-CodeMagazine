﻿#nullable disable

using System;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;

namespace AdoNetWrapper.Common;

/// <summary>
/// Database context using ADO.NET for SQL Server Databases
/// </summary>
public partial class SqlServerDatabaseContext : DatabaseContext {
  #region Constructor
  public SqlServerDatabaseContext(string connectString) : base(connectString) {
    ParameterPrefix = "@";
  }
  #endregion

  #region CreateConnection Methods
  public override SqlConnection CreateConnection() {
    return CreateConnection(ConnectionString);
  }

  public override SqlConnection CreateConnection(string connectString) {
    return new SqlConnection(connectString);
  }
  #endregion

  #region CreateCommand Methods
  public override SqlCommand CreateCommand(IDbConnection cnn, string sql) {
    CommandObject = new SqlCommand(sql, (SqlConnection)cnn);
    CommandObject.CommandType = CommandType.Text;
    return (SqlCommand)CommandObject;
  }
  #endregion

  #region CreateParameter Methods
  public override SqlParameter CreateParameter(string paramName, object value) {
    if (!paramName.StartsWith(ParameterPrefix)) {
      paramName = ParameterPrefix + paramName;
    }
    return new SqlParameter(paramName, value);
  }

  public override SqlParameter CreateParameter() {
    return new SqlParameter();
  }
  #endregion

  #region GetParameter Method
  public virtual SqlParameter GetParameter(string paramName) {
    if (!paramName.StartsWith(ParameterPrefix)) {
      paramName = ParameterPrefix + paramName;
    }
    return ((SqlCommand)CommandObject).Parameters[paramName];
  }
  #endregion

  #region CreateDataReader Method
  public override SqlDataReader CreateDataReader() {
    return CreateDataReader(CommandObject, CommandBehavior.CloseConnection);
  }

  public override SqlDataReader CreateDataReader(CommandBehavior cmdBehavior) {
    return CreateDataReader(CommandObject, cmdBehavior);
  }

  public override SqlDataReader CreateDataReader(IDbCommand cmd, CommandBehavior cmdBehavior = CommandBehavior.CloseConnection) {
    try {
      // Open Connection
      cmd.Connection.Open();
      // Create DataReader
      DataReaderObject = cmd.ExecuteReader(cmdBehavior);
    }
    catch (Exception ex) {
      HandleException(ex);
    }

    return (SqlDataReader)DataReaderObject;
  }
  #endregion

  #region HandleException Method
  public override void HandleException(Exception ex) {
    throw new SqlServerDatabaseException(ex.Message, ex, (SqlCommand)CommandObject);
  }
  #endregion

  #region GetIdentity Method
  public override void GetIdentity<TEntity>(IDbCommand cmd, TEntity entity, PropertyInfo prop) {
    cmd.CommandText = "SELECT CONVERT(INT, @@IDENTITY);";
    cmd.CommandType = CommandType.Text;
    try {
      int? value = (int?)cmd.ExecuteScalar();
      if (value.HasValue) {
        prop.SetValue(entity, value, null);
      }
    }
    catch (Exception ex) {
      HandleException(ex);
    }
  }
  #endregion
}
