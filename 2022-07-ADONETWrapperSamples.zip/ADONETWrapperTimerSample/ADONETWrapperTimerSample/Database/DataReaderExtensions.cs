﻿#nullable disable

using System;
using System.Data;

namespace AdoNetWrapper.Common;

public static class DataReaderExtensions {
  public static T GetData<T>(this IDataReader dr, string name, T returnValue = default) {
    if (!dr[name].Equals(DBNull.Value)) {
      returnValue = (T)dr[name];
    }

    return returnValue;
  }
}