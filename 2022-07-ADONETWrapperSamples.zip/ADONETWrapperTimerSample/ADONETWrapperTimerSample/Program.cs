﻿using ADONETWrapperTimerSample.DatabaseContexts;
using ADONETWrapperTimerSample.EntityLayer;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.Diagnostics;

// Setup Host
using IHost host = Host.CreateDefaultBuilder().Build();

// Ask service provider for configuration
IConfiguration config = host.Services.GetRequiredService<IConfiguration>();

// Get connection string
string ConnectString = config.GetValue<string>("ConnectionStrings:DefaultConnection");

//******************************************************
//* ADO.NET
//******************************************************
// Start Timer
Stopwatch stopWatch = new Stopwatch();
stopWatch.Start();
using PaulsAutoPartsAdoNetDbContext db = new(ConnectString);

List<VehicleType> list = db.VehicleTypes.Search();
Console.WriteLine(list.Count());
list = db.VehicleTypes.Search();
Console.WriteLine(list.Count());
list = db.VehicleTypes.Search();
Console.WriteLine(list.Count());
list = db.VehicleTypes.Search();
Console.WriteLine(list.Count());
stopWatch.Stop();
// Get the elapsed time as a TimeSpan value.
TimeSpan ts = stopWatch.Elapsed;

// Format and display the TimeSpan value.
string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",
    ts.Hours, ts.Minutes, ts.Seconds,
    ts.Milliseconds / 10);
Console.WriteLine("RunTime " + elapsedTime);

//******************************************************
//* Entity Framework
//******************************************************
using PaulsAutoPartsEFDbContext db2 = new();

list = db2.VehicleTypes.ToList();
Console.WriteLine(list.Count());
list = db2.VehicleTypes.ToList();
Console.WriteLine(list.Count());
list = db2.VehicleTypes.ToList();
Console.WriteLine(list.Count());
list = db2.VehicleTypes.ToList();
Console.WriteLine(list.Count());
stopWatch.Stop();
// Get the elapsed time as a TimeSpan value.
ts = stopWatch.Elapsed;

// Format and display the TimeSpan value.
elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",
    ts.Hours, ts.Minutes, ts.Seconds,
    ts.Milliseconds / 10);
Console.WriteLine("RunTime " + elapsedTime);
