#nullable disable

using System;
using System.ComponentModel.DataAnnotations;

namespace ADONETWrapperTimerSample.EntityLayer
{
  /// <summary>
  /// This class contains properties for searching
  /// All of the properties in this class should be nullable unless 
  /// you wish to require the user to enter at least one 
  /// search value prior to displaying records
  /// </summary>
  public partial class VehicleTypeSearch
  {
    public string SortExpression { get; set; }

    private string _Make;

    [Display(Name = "Make")]
    public string Make
    {
      get { return _Make; }
      set { _Make = value; }
    }

  }
}
