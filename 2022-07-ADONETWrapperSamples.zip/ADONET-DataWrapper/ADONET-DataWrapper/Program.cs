﻿#nullable disable

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

public partial class Program {

  private static string ConnectString;
  private static string Sql = "SELECT * FROM SalesLT.Product";

  public static void Main() {
    // Setup Host
    using IHost host = Host.CreateDefaultBuilder().Build();

    // Ask the service provider for the configuration abstraction.
    IConfiguration config = host.Services.GetRequiredService<IConfiguration>();

    // Get values from the config given their key and their target type.
    ConnectString = config.GetValue<string>("ConnectionStrings:DefaultConnection");

    // *********************************************
    // Sample 01: Hard-coded ADO.NET
    // *********************************************
    //Program.HardCodedSample();

    // *********************************************
    // Sample 02: Test SQL Server Database Context
    // *********************************************
    //Program.SqlServerSample();

    // *******************************************
    // Sample 03: Use Generic Method/Reflection
    // *******************************************
    //Program.GenericSample();

    // **************************************************
    // Sample 04: Use [Column] Attribute
    // **************************************************
    //Program.AttributesSample();

    // **************************************************
    // Sample 05: Build SELECT SQL
    // **************************************************
    Program.BuildSelectSqlSample();
  }
}
