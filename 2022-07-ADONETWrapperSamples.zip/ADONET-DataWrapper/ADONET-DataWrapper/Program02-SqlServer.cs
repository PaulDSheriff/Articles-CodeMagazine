﻿#nullable disable

using AdoNetWrapperSamples.SqlServer.EntityClasses;
using AdoNetWrapperSamples.SqlServer.RepositoryClasses;

public partial class Program {
  /// <summary>
  /// SQL Server Database Context
  /// </summary>
  public static void SqlServerSample() {
    // Get Data
    ProductRepository repo = new();
    List<Product> list = repo.Search(ConnectString, Sql);

    Console.WriteLine("*** SQL Server Sample ***");
    // Display Data
    foreach (var item in list) {
      Console.WriteLine(item.ToString());
    }
    Console.WriteLine();
    Console.WriteLine($"Total Items: {list.Count}");
    Console.WriteLine();
  }
}
