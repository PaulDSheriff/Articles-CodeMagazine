﻿#nullable disable

using AdoNetWrapperSamples.HardCodedSample.EntityClasses;
using AdoNetWrapperSamples.HardCodedSample.RepositoryClasses;

public partial class Program {
  /// <summary>
  /// Hard-coded ADO.NET
  /// </summary>
  public static void HardCodedSample() {
    // Get Data
    ProductRepository repo = new();
    List<Product> list = repo.Search(ConnectString, Sql);

    Console.WriteLine("*** Hard-Coded Sample ***");
    // Display Data
    foreach (var item in list) {
      Console.WriteLine(item.ToString());
    }
    Console.WriteLine();
    Console.WriteLine($"Total Items: {list.Count}");
    Console.WriteLine();
  }
}
