﻿#nullable disable

using AdoNetWrapperSamples.Generic.EntityClasses;
using AdoNetWrapperSamples.Generic.RepositoryClasses;

public partial class Program {
  /// <summary>
  /// Build SELECT SQL Sample
  /// </summary>
  public static void BuildSelectSqlSample() {
    // Get Data
    ProductRepository repo = new();
    List<Product> list = repo.Search<Product>(ConnectString, Sql);

    Console.WriteLine("*** Build SELECT SQL  Sample ***");
    // Display Data
    foreach (var item in list) {
      Console.WriteLine(item.ToString());
    }
    Console.WriteLine();
    Console.WriteLine($"Total Items: {list.Count}");
    Console.WriteLine();
  }
}
