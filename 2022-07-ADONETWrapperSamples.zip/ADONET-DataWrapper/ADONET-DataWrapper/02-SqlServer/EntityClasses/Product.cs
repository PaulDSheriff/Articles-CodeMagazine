﻿#nullable disable

using System.ComponentModel.DataAnnotations.Schema;

namespace AdoNetWrapperSamples.SqlServer.EntityClasses;

[Table("Product", Schema = "SalesLT")]
public partial class Product {
  public int ProductID { get; set; }
  public string Name { get; set; }
  public string ProductNumber { get; set; }
  public string Color { get; set; }
  public decimal StandardCost { get; set; }
  public decimal ListPrice { get; set; }
  public DateTime SellStartDate { get; set; }
  public DateTime? SellEndDate { get; set; }
  public DateTime? DiscontinuedDate { get; set; }

  public override string ToString() {
    return $"Product Name: {Name} - Product ID: {ProductID} - List Price: {ListPrice:c}";
  }
}
