﻿Simplifying ADO.NET - Part 1
============================================
01-HardCodedSample     -> Hard-coded SqlDataReader to populate a collection of objects, uses SqlDataReaderExtension class
02-SqlServer           -> Use the SQL Server wrapper class around the DatabaseContext base class
03-Generic             -> Use Reflection and a generic method to populate any class where the property name in the class matches the column name in the table
04-UseAttributes       -> Check for [Column] attribute to map column to a property
05-BuildSelectSql      -> Build SELECT SQL from properties in TEntity. Use ColumnMapper class
