﻿#nullable disable

using AdoNetWrapper.Attributes.Common;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Reflection;

namespace AdoNetWrapperSamples.Attributes.RepositoryClasses;

public class ProductRepository {
  public virtual List<TEntity> Search<TEntity>(string connectString, string sql) {
    List<TEntity> ret;

    using SqlServerDatabaseContext dbContext = new(connectString);
    dbContext.CreateCommand(sql);

    ret = BuildEntityList<TEntity>(dbContext.CreateDataReader());

    return ret;
  }

  protected virtual List<TEntity> BuildEntityList<TEntity>(IDataReader rdr) {
    List<TEntity> ret = new();
    string columnName;

    // Get all the properties in <TEntity>
    PropertyInfo[] props = typeof(TEntity).GetProperties();

    // Loop through all rows in the data reader
    while (rdr.Read()) {
      // Create new instance of Entity
      TEntity entity = Activator.CreateInstance<TEntity>();

      // Loop through columns in data reader
      for (int index = 0; index < rdr.FieldCount; index++) {
        // Get field name from data reader
        columnName = rdr.GetName(index);

        // Get property that matches the field name
        PropertyInfo col = props.FirstOrDefault(col => col.Name == columnName);

        if (col == null) {
          // Is column name in a [Column] attribute?
          col = props.FirstOrDefault(
            c => c.GetCustomAttribute
              <ColumnAttribute>()?.Name == columnName);
        }

        if (col != null) {
          // Get the value from the table
          var value = rdr[columnName];
          // Assign value to property if not null
          if (!value.Equals(DBNull.Value)) {
            col.SetValue(entity, value, null);
          }
        }
      }
      // Add new entity to the list
      ret.Add(entity);
    }

    return ret;
  }
}
