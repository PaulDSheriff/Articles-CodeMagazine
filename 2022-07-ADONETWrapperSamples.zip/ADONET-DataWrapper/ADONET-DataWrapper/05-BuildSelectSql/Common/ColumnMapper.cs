﻿#nullable disable

using System.Reflection;

namespace AdoNetWrapper.SelectSql.Common;

public class ColumnMapper {
  public string ColumnName { get; set; }
  public PropertyInfo PropertyInfo { get; set; }
}
