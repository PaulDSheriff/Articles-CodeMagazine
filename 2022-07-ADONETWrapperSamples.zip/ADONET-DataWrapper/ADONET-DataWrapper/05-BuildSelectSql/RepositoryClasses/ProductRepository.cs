﻿#nullable disable

using AdoNetWrapper.SelectSql.Common;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Reflection;
using System.Text;

namespace AdoNetWrapperSamples.SelectSql.RepositoryClasses;

public class ProductRepository {
  public ProductRepository() {
    Init();
  }

  public string SchemaName { get; set; }
  public string TableName { get; set; }
  public List<ColumnMapper> Columns { get; set; }
  public string SQL { get; set; }

  protected virtual void Init() {
    SchemaName = "dbo";
    TableName = string.Empty;
    SQL = string.Empty;
    Columns = new();
  }

  public virtual List<TEntity> Search<TEntity>(string connectString) {
    List<TEntity> ret;

    // Build SELECT statement
    SQL = BuildSelectSql<TEntity>();

    using SqlServerDatabaseContext dbContext = new(connectString);
    dbContext.CreateCommand(SQL);

    ret = BuildEntityList<TEntity>(dbContext.CreateDataReader());

    return ret;
  }

  protected virtual string BuildSelectSql<TEntity>() {
    Type typ = typeof(TEntity);
    StringBuilder sb = new(2048);
    string comma = string.Empty;

    // Build Column Mapping Collection
    Columns = BuildColumnCollection<TEntity>();

    // Set Table and Schema properties
    SetTableAndSchemaName(typ);

    // Build the SELECT statement
    sb.Append("SELECT");
    foreach (ColumnMapper item in Columns) {
      // Add column
      sb.Append($"{comma} [{item.ColumnName}]");
      comma = ",";
    }
    // Add 'FROM schema.table'
    sb.Append($" FROM {SchemaName}.{TableName}");

    return sb.ToString();
  }

  protected virtual void SetTableAndSchemaName(Type typ) {
    // Is there is a [Table] attribute?
    TableAttribute table = typ.GetCustomAttribute<TableAttribute>();
    // Assume table name is the class name
    TableName = typ.Name;
    if (table != null) {
      // Set properties from [Table] attribute
      TableName = table.Name;
      SchemaName = table.Schema ?? SchemaName;
    }
  }

  protected virtual List<ColumnMapper> BuildColumnCollection<TEntity>() {
    List<ColumnMapper> ret = new();
    ColumnMapper colMap;

    // Get all the properties in <TEntity>
    PropertyInfo[] props = typeof(TEntity).GetProperties();

    // Loop through all properties
    foreach (PropertyInfo prop in props) {
      // Is there a [NotMapped] attribute?
      NotMappedAttribute nm = prop.GetCustomAttribute<NotMappedAttribute>();
      // Only add properties that map to a column
      if (nm == null) {
        // Create a column mapping object
        colMap = new() {
          // Set column properties
          PropertyInfo = prop,
          ColumnName = prop.Name
        };

        // Is column name in [Column] attribute?
        ColumnAttribute ca = prop.GetCustomAttribute<ColumnAttribute>();
        if (ca != null && !string.IsNullOrEmpty(ca.Name)) {
          // Set column name from [Column] attr
          colMap.ColumnName = ca.Name;
        }

        // Create collection of columns
        ret.Add(colMap);
      }
    }

    return ret;
  }

  protected virtual List<TEntity> BuildEntityList<TEntity>(IDataReader rdr) {
    List<TEntity> ret = new();

    // Loop through all rows in the data reader
    while (rdr.Read()) {
      // Create new instance of Entity
      TEntity entity = Activator.CreateInstance<TEntity>();

      // Loop through columns collection
      for (int index = 0; index < Columns.Count; index++) {
        // Get the value from the reader
        var value = rdr[Columns[index].ColumnName];

        // Assign value to the property if not null
        if (!value.Equals(DBNull.Value)) {
          Columns[index].PropertyInfo.SetValue(entity, value, null);
        }
      }

      // Add new entity to the list
      ret.Add(entity);
    }

    return ret;
  }
}
