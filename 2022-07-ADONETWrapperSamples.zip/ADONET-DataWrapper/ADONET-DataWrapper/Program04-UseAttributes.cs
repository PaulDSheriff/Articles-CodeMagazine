﻿#nullable disable

using AdoNetWrapperSamples.Generic.EntityClasses;
using AdoNetWrapperSamples.Generic.RepositoryClasses;

public partial class Program {
  /// <summary>
  /// Attributes Sample
  /// </summary>
  public static void AttributesSample() {
    // Get Data
    ProductRepository repo = new();
    List<Product> list = repo.Search<Product>(ConnectString, Sql);

    Console.WriteLine("*** Attributes Sample ***");
    // Display Data
    foreach (var item in list) {
      Console.WriteLine(item.ToString());
    }
    Console.WriteLine();
    Console.WriteLine($"Total Items: {list.Count}");
    Console.WriteLine();
  }
}
