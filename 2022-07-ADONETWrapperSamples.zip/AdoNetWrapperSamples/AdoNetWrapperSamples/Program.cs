﻿#nullable disable

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

using AdoNetWrapperSamples.EntityClasses;
using AdoNetWrapperSamples.RepositoryClasses;

// Setup Host
using IHost host = Host.CreateDefaultBuilder().Build();

// Ask service provider for configuration
IConfiguration config = host.Services.GetRequiredService<IConfiguration>();

// Get connection string
string ConnectString = config.GetValue<string>("ConnectionStrings:DefaultConnection");

ProductRepository repo = new();
List<Product> list = repo.Search<Product>(ConnectString);

Console.WriteLine("*** Display the Data ***");
// Display Data
foreach (var item in list) {
  Console.WriteLine(item.ToString());
}

Console.WriteLine();
Console.WriteLine($"Total Items: {list.Count}");
Console.WriteLine();