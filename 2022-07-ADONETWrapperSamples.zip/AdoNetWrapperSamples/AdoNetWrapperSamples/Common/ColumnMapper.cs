﻿#nullable disable

using System.Reflection;

namespace AdoNetWrapper.Common;

public class ColumnMapper {
  public string ColumnName { get; set; }
  public PropertyInfo PropertyInfo { get; set; }
}
