﻿namespace PaulsAutoParts.Common
{
  public class EntityBase
  {   
  }
}
