﻿using AdventureWorks.EntityLayer;
using Common.Library;
using System.Windows.Input;

namespace AdventureWorks.MAUI.MauiViewModelClasses;

public class UserViewModel : AdventureWorks.ViewModelLayer.UserViewModel {
  #region Constructors
  public UserViewModel() : base() {
  }

  public UserViewModel(IRepository<User> repo) : base(repo) {
  }

  public UserViewModel(IRepository<User> repo, IRepository<PhoneType> phoneRepo) : base(repo, phoneRepo) {
  }
  #endregion

  #region Commands
  public ICommand? SaveCommand { get; private set; }
  #endregion

  #region Init Method
  public override void Init() {
    base.Init();

    // Create commands for this view
    SaveCommand = new Command(async () => await SaveAsync());
  }
  #endregion
}
