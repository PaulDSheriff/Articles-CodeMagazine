using AdventureWorks.MAUI.MauiViewModelClasses;

namespace AdventureWorks.MAUI.Views;

public partial class UserDetailView : ContentPage
{
	public UserDetailView(UserViewModel viewModel)
	{
		InitializeComponent();

    _ViewModel = viewModel;
  }

  private readonly UserViewModel _ViewModel;

  protected async override void OnAppearing() {
    base.OnAppearing();

    // Set the BindingContext to the ViewModel
    BindingContext = _ViewModel;

    // Get the Phone Types
    await _ViewModel.GetPhoneTypes();

    // Retrieve a User
    await _ViewModel.GetAsync(1);
  }
}