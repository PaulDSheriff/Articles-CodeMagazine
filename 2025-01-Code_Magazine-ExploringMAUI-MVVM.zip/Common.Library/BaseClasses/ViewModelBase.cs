﻿namespace Common.Library;

public class ViewModelBase : CommonBase {
  #region Private Variables
  private int _RowsAffected;
  #endregion

  #region Public Properties
  public int RowsAffected {
    get { return _RowsAffected; }
    set {
      _RowsAffected = value;
      RaisePropertyChanged(nameof(RowsAffected));
    }
  }
  #endregion

  #region PublishException Method
  protected virtual void PublishException(Exception ex) {
    LastException = ex;

    System.Diagnostics.Debug.WriteLine(ex.ToString());
  }
  #endregion
}
