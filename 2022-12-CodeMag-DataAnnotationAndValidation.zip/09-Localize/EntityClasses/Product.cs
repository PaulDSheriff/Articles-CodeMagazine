#nullable disable

using System.ComponentModel.DataAnnotations;
using Samples.Resources;

namespace Samples;

public partial class Product {
  public int ProductID { get; set; }

  [Display(Name = "Product Name")]
  [Required(ErrorMessageResourceName = nameof(ValidationMessages.Required),
    ErrorMessageResourceType = typeof(ValidationMessages))]
  [StringLength(50, MinimumLength = 4,
    ErrorMessageResourceName = nameof(ValidationMessages.StringLength),
    ErrorMessageResourceType = typeof(ValidationMessages))]
  public string Name { get; set; }

  [Display(Name = "Product Number")]
  [MaxLength(25, ErrorMessageResourceName = nameof(ValidationMessages.MaxLength),
  ErrorMessageResourceType = typeof(ValidationMessages))]
  public string ProductNumber { get; set; }

  [Display(Name = "Product Color")]
  [MaxLength(15)]
  [MinLength(3, ErrorMessageResourceName = nameof(ValidationMessages.MinLength),
  ErrorMessageResourceType = typeof(ValidationMessages))]
  public string Color { get; set; }

  [Display(Name = "Cost")]
  [Range(0.01, 9999)]
  public decimal? StandardCost { get; set; }

  [Display(Name = "Price")]
  [Range(0.01, 9999)]
  public decimal? ListPrice { get; set; }

  [Display(Name = "Start Selling Date")]
  public DateTime SellStartDate { get; set; }

  [Display(Name = "End Selling Date")]
  public DateTime? SellEndDate { get; set; }

  [Display(Name = "Date Discontinued")]
  public DateTime? DiscontinuedDate { get; set; }
  [Url]
  public string ProductUrl { get; set; }

  public override string ToString() {
    return $"{Name} ({ProductID})";
  }
}