﻿#nullable disable

using System.ComponentModel.DataAnnotations;
using Samples.Resources;

namespace Samples;

public class User {
  public int UserId { get; set; }

  [Required(ErrorMessageResourceName = nameof(ValidationMessages.Required),
    ErrorMessageResourceType = typeof(ValidationMessages))]
  public string LoginId { get; set; }
  [Compare("ConfirmPassword")]
  public string Password { get; set; }
  public string ConfirmPassword { get; set; }
  [EmailAddress(ErrorMessageResourceName = nameof(ValidationMessages.Email),
    ErrorMessageResourceType = typeof(ValidationMessages))]
  public string EmailAddress { get; set; }
  [Phone(ErrorMessageResourceName = nameof(ValidationMessages.Phone),
    ErrorMessageResourceType = typeof(ValidationMessages))]
  public string Phone { get; set; }
}
