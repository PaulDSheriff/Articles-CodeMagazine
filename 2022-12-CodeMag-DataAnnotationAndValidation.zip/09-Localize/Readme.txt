﻿Description of the Samples
--------------------------------------------------
01-LocalizeUser() - Use resource files to display error messages
02-LocalizeProduct() - Use resource files to display error messages