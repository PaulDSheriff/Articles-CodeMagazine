﻿using Samples;
using System.Globalization;

// Change Language
//string culture = "en-US";
string culture = "es-MX";

// Set CultureInfo on Current Thread's CurrentUICulture Object
Thread.CurrentThread.CurrentUICulture = new CultureInfo(culture);

// Validate User
Sample01.Validate();

// Validate Product
//Sample02.Validate();