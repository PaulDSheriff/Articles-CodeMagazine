﻿using Samples;

// Test the [Range] attribute
Sample01.Sample01.Validate();

// Test the [Range] attribute on DateTime properties
//Sample02.Sample02.Validate();

// Test the [RegularExpression] attribute
//Sample03.Sample03.Validate();

// Test the [Compare] attribute
//Sample04.Sample04.Validate();