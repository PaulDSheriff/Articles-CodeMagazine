﻿Description of the Samples
--------------------------------------------------
01-Range() - Using the [Range] attribute
02-DateRange() - Using the [Range] attribute with DateTime
03-RegularExpression() - Using the [RegularExpression] attribute
04-Compare() - Using the [Compare] attribute
