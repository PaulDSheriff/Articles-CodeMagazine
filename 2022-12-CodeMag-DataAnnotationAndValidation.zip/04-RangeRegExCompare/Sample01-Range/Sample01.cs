﻿using Samples;

namespace Sample01;

public class Sample01 {
  /// <summary>
  /// Validate an entity object
  /// Using the [Range] attribute
  /// </summary>
  public static void Validate() {
    // Create view model and initialize Entity object
    ProductViewModel vm = new() {
      Entity = new() {
        ProductID = 1,
        Name = "A New Product",
        Color = "Black",
        StandardCost = 0,
        ListPrice = 10000,
        SellStartDate = DateTime.Now,
        SellEndDate = DateTime.Now.AddDays(+365)
      }
    };

    // Validate the Data
    var msgs = vm.Validate();

    if (msgs.Count > 0) {
      // Display Failed Validation Messages
      foreach (ValidationMessage item in msgs) {
        Console.WriteLine(item);
      }

      // Display Total Count
      Console.WriteLine();
      Console.WriteLine($"Total Validations Failed: {msgs.Count}");
    }
    else {
      Console.WriteLine();
      Console.WriteLine("Entity is Valid");
    }

    // Pause to view the Results
    Console.ReadKey();
  }
}