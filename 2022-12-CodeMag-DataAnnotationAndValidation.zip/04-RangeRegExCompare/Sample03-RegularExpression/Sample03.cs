﻿using Samples;

namespace Sample03;

public class Sample03 {
  /// <summary>
  /// Validate an entity object
  /// Using the [RegularExpression] attribute
  /// </summary>
  public static void Validate() {
    // Create view model and initialize Entity object
    UserViewModel vm = new() {
      Entity = new() {
        UserId = 1,
        LoginId = "JoeSmith",
        Password = "Joe!Smith@2022",
        EmailAddress = "test!test.com",
        Phone = "xxx-xxx-xxxx"
      }
    };

    // Validate the Data
    var msgs = vm.Validate();

    if (msgs.Count > 0) {
      // Display Failed Validation Messages
      foreach (ValidationMessage item in msgs) {
        Console.WriteLine(item);
      }

      // Display Total Count
      Console.WriteLine();
      Console.WriteLine($"Total Validations Failed: {msgs.Count}");
    }
    else {
      Console.WriteLine();
      Console.WriteLine("Entity is Valid");
    }

    // Pause to view the Results
    Console.ReadKey();
  }
}