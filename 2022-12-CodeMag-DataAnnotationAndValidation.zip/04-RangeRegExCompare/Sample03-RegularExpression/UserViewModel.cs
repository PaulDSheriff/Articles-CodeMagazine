﻿using Samples;

namespace Sample03;

public class UserViewModel {
  public UserViewModel() {
    Entity = new();
  }

  public User Entity { get; set; }

  /// <summary>
  /// Validate using a helper class
  /// </summary>
  public List<ValidationMessage> Validate() {
    // Use Helper Class
    return ValidationHelper.Validate(Entity);
  }
}