﻿Description of the Samples
--------------------------------------------------
Validate using the [CustomValidator] attribute