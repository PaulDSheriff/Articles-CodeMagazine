﻿using Samples;

CustomerViewModel vm = new() {
  Entity = new() {
    EntryDate = DateTime.Parse("10/1/2022")
  }
};

// Validate the object
var msgs = vm.Validate();

if (msgs.Count > 0) {
  // Display Failed Validation Messages
  foreach (ValidationMessage item in msgs) {
    Console.WriteLine(item);
  }

  // Display Total Count
  Console.WriteLine();
  Console.WriteLine($"Total Validations Failed: {msgs.Count}");
}
else {
  Console.WriteLine();
  Console.WriteLine("Entity is Valid");
}

// Pause to view the Results
Console.ReadKey();