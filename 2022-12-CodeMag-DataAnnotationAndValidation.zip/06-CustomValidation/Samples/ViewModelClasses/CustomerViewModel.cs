﻿namespace Samples;

public class CustomerViewModel {
  public CustomerViewModel() {
    Entity = new();
  }

  public Customer Entity { get; set; }

  public List<ValidationMessage> Validate() {
    // Use Helper Class
    return ValidationHelper.Validate(Entity);
  }
}
