﻿#nullable disable

using System.ComponentModel.DataAnnotations;

namespace Samples {
  public class WeekdayOnlyValidator {
    public static ValidationResult Validate(DateTime date) {
      return date.DayOfWeek == DayOfWeek.Saturday
       || date.DayOfWeek == DayOfWeek.Sunday
         ? new ValidationResult("Invalid date because it falls on a weekend")
         : ValidationResult.Success;
    }
  }
}