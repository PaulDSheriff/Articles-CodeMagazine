﻿Description of the Samples
--------------------------------------------------
EntityClasses\Product.cs - Class to hold product information
ValidationClasses\ValidationMessage.cs - Class to hold a validation error message
ProductViewModel.cs - Class with the Validate() method