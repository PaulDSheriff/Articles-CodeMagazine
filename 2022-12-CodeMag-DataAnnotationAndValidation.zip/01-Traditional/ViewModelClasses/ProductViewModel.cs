﻿namespace Samples;

public class ProductViewModel {
  public ProductViewModel() {
    Entity = new();
  }

  public Product Entity { get; set; }

  /// <summary>
  /// Validate a Product using C# Code
  /// </summary>
  public List<ValidationMessage> Validate() {
    List<ValidationMessage> msgs = new();

    if (string.IsNullOrWhiteSpace(Entity.Name)) {
      msgs.Add(new ValidationMessage() { ErrorMessage = "Product Name Must Be Filled In.", PropertyName = "Name" });
    }
    else {
      if (Entity.Name.Length > 50) {
        msgs.Add(new ValidationMessage() { ErrorMessage = "Product Name Must Be 50 Characters or Less.", PropertyName = "Name" });
      }
    }

    if (Entity.StandardCost == null || Entity.StandardCost < 0.01M) {
      msgs.Add(new ValidationMessage() { ErrorMessage = "Cost Must Be Greater Than Zero.", PropertyName = "StandardCost" });
    }
    if (Entity.ListPrice == null || Entity.ListPrice < 0.01M) {
      msgs.Add(new ValidationMessage() { ErrorMessage = "Price Must Be Greater Than Zero.", PropertyName = "ListPrice" });
    }
    if (Entity.ListPrice < Entity.StandardCost) {
      msgs.Add(new ValidationMessage() {
        ErrorMessage = $"Price must be greater than the Cost.",
        PropertyName = "ListPrice"
      });
    }

    if (Entity.SellStartDate == DateTime.MinValue) {
      msgs.Add(new ValidationMessage() { ErrorMessage = $"Selling Start Date Must Be Greater Than '{DateTime.Now.AddDays(-5).ToShortDateString()}'.", PropertyName = "SellStartDate" });
    }

    return msgs;
  }
}