﻿#nullable disable

using System.ComponentModel.DataAnnotations;

namespace Samples;

public static class ValidationHelper {
  public static List<ValidationMessage> Validate<T>(T entity) {
    List<ValidationMessage> ret = new();

    // Create instance of ValidationContext object
    ValidationContext context = new(entity, serviceProvider: null, items: null);
    List<ValidationResult> results = new();

    // Call TryValidateObject() method
    if (!Validator.TryValidateObject(entity, context, results, true)) {
      // Get validation results
      foreach (ValidationResult item in results) {
        string propName = string.Empty;
        if (item.MemberNames.Any()) {
          propName = ((string[])item.MemberNames)[0];
        }
        // Build new ValidationMessage object
        ValidationMessage msg = new() {
          ErrorMessage = item.ErrorMessage,
          PropertyName = propName
        };

        // Add validation object to list
        ret.Add(msg);
      }
    }

    return ret;
  }
}
