﻿// Using the [Required] attribute
Sample01.Sample01.Validate();

// Using the [Required(ErrorMessage = "")] attribute
//Sample02.Sample02.Validate();

// Using the [DisplayName] attribute
//Sample03.Sample03.Validate();

// Using a helper class
//Sample04.Sample04.Validate();