#nullable disable

using System.ComponentModel.DataAnnotations;

namespace Sample02;

public partial class Product {
  public int ProductID { get; set; }
[Required(ErrorMessage = "{0} Must Be Filled In.")]
public string Name { get; set; }
[Required(ErrorMessage = "{0} Must Be Filled In.")]
public string ProductNumber { get; set; }
  public string Color { get; set; }
  [Required]
  public decimal? StandardCost { get; set; }
  [Required]
  public decimal? ListPrice { get; set; }
  [Required]
  public DateTime SellStartDate { get; set; }
  public DateTime? SellEndDate { get; set; }
  public DateTime? DiscontinuedDate { get; set; }

  public override string ToString() {
    return $"{Name} ({ProductID})";
  }
}