﻿using Samples;
using System.ComponentModel.DataAnnotations;

namespace Sample02;

public class ProductViewModel {
  public ProductViewModel() {
    Entity = new();
  }

  public Product Entity { get; set; }

  /// <summary>
  /// Validate using Validator Object
  /// </summary>
  public List<ValidationMessage> Validate() {
    List<ValidationMessage> msgs = new();

    if (Entity != null) {
      // Create instance of ValidationContext object
      ValidationContext context = new(Entity, serviceProvider: null, items: null);
      List<ValidationResult> results = new();

      // Call TryValidateObject() method
      if (!Validator.TryValidateObject(Entity, context, results, true)) {
        // Get validation results
        foreach (ValidationResult item in results) {
          string propName = string.Empty;
          if (item.MemberNames.Any()) {
            propName = ((string[])item.MemberNames)[0];
          }
          // Build new ValidationMessage object
          ValidationMessage msg = new() {
            ErrorMessage = item.ErrorMessage,
            PropertyName = propName
          };

          // Add validation object to list
          msgs.Add(msg);
        }
      }
    }

    return msgs;
  }
}