﻿using Samples;

namespace Sample01;

public class Sample01 {
  /// <summary>
  /// Validate an entity object
  /// Show using [Required] attribute
  /// </summary>
  public static void Validate() {
    // Create view model and initialize Entity object
    ProductViewModel vm = new() {
      Entity = new() {
        ProductID = 1
      }
    };

    // Validate the Data
    var msgs = vm.Validate();

    // Display Failed Validation Messages
    foreach (ValidationMessage item in msgs) {
      Console.WriteLine(item);
    }

    // Display Total Count
    Console.WriteLine();
    Console.WriteLine($"Total Validations Failed: {msgs.Count}");

    // Pause to view the Results
    Console.ReadKey();
  }
}