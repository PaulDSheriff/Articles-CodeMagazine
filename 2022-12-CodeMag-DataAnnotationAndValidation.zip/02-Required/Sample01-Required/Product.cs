#nullable disable

using System.ComponentModel.DataAnnotations;

namespace Sample01;

public partial class Product {
  public int ProductID { get; set; }
  [Required]
  public string Name { get; set; }
  [Required]
  public string ProductNumber { get; set; }
  public string Color { get; set; }
  [Required]
  public decimal? StandardCost { get; set; }
  [Required]
  public decimal? ListPrice { get; set; }
  [Required]
  public DateTime SellStartDate { get; set; }
  public DateTime? SellEndDate { get; set; }
  public DateTime? DiscontinuedDate { get; set; }

  public override string ToString() {
    return $"{Name} ({ProductID})";
  }
}