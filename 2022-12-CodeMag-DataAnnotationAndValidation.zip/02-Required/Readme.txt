﻿Description of the Samples
--------------------------------------------------
01-Required() - Validate an entity object use the [Required] attribute
02-RequiredErrorMessage() - Add the ErrorMessage property to the [Required] attribute
03-RequiredDisplayName() - Add the [DisplayName] attribute
04-HelperClass() - Create a Validation Helper Class