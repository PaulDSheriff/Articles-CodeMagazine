#nullable disable

using System.ComponentModel.DataAnnotations;

namespace Sample04;

public partial class Product {
  public int ProductID { get; set; }

  [Display(Name = "Product Name")]
  [Required(ErrorMessage = "{0} Must Be Filled In.")]
  public string Name { get; set; }

  [Display(Name = "Product Number")]
  [Required(ErrorMessage = "{0} Must Be Filled In.")]
  public string ProductNumber { get; set; }

  [Display(Name = "Product Color")]
  public string Color { get; set; }

  [Display(Name = "Cost")]
  [Required]
  public decimal? StandardCost { get; set; }

  [Display(Name = "Price")]
  [Required]
  public decimal? ListPrice { get; set; }

  [Display(Name = "Start Selling Date")]
  [Required]
  public DateTime SellStartDate { get; set; }

  [Display(Name = "End Selling Date")]
  public DateTime? SellEndDate { get; set; }

  [Display(Name = "Date Discontinued")]
  public DateTime? DiscontinuedDate { get; set; }

  public override string ToString() {
    return $"{Name} ({ProductID})";
  }
}