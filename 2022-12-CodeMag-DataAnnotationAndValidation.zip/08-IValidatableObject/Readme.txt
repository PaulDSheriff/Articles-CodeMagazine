﻿Description of the Samples
--------------------------------------------------
Implement IValidatableObject interface on Product object