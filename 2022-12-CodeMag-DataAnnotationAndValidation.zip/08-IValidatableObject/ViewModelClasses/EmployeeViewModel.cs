﻿namespace Samples;

public class EmployeeViewModel {
  public EmployeeViewModel() {
    Entity = new();
  }

  public Employee Entity { get; set; }

  /// <summary>
  /// Validate using a helper class
  /// </summary>
  public List<ValidationMessage> Validate() {
    // Use Helper Class
    return ValidationHelper.Validate(Entity);
  }
}