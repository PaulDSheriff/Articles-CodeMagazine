#nullable disable

using System.ComponentModel.DataAnnotations;

namespace Sample03;

public partial class Product {
  public int ProductID { get; set; }

  [Display(Name = "Product Name")]
  [Required(ErrorMessage = "{0} Must Be Filled In.")]
  [StringLength(50, MinimumLength = 4, ErrorMessage = "{0} Can Only Have Between {2} and {1} Characters.")]
  public string Name { get; set; }

  [Display(Name = "Product Number")]
  [MaxLength(25)]
  public string ProductNumber { get; set; }

  [Display(Name = "Product Color")]
  [MinLength(3, ErrorMessage = "{0} Must Have {1} Characters or More.")]
  [MaxLength(15)]
  public string Color { get; set; }

  [Display(Name = "Cost")]
  public decimal? StandardCost { get; set; }

  [Display(Name = "Price")]
  public decimal? ListPrice { get; set; }

  [Display(Name = "Start Selling Date")]
  public DateTime SellStartDate { get; set; }

  [Display(Name = "End Selling Date")]
  public DateTime? SellEndDate { get; set; }

  [Display(Name = "Date Discontinued")]
  public DateTime? DiscontinuedDate { get; set; }

  public override string ToString() {
    return $"{Name} ({ProductID})";
  }
}