﻿using Samples;

namespace Sample02;

public class Sample02 {
  /// <summary>
  /// Validate an entity object
  /// Show using [MinLength] attribute
  /// </summary>
  public static void Validate() {
    // Create view model and initialize Entity object
    ProductViewModel vm = new() {
      Entity = new() {
        ProductID = 1,
        Name = "Product 1",
        ProductNumber = "PROD001",
        Color = "Re"
      }
    };

    // Validate the Data
    var msgs = vm.Validate();

    if (msgs.Count > 0) {
      // Display Failed Validation Messages
      foreach (ValidationMessage item in msgs) {
        Console.WriteLine(item);
      }

      // Display Total Count
      Console.WriteLine();
      Console.WriteLine($"Total Validations Failed: {msgs.Count}");
    }
    else {
      Console.WriteLine();
      Console.WriteLine("Entity is Valid");
    }

    // Pause to view the Results
    Console.ReadKey();
  }
}