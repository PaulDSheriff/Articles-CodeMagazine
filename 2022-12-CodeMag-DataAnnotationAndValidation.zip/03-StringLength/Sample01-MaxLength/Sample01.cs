﻿using Samples;

namespace Sample01;

public class Sample01 {
  /// <summary>
  /// Validate an entity object
  /// Show using [MaxLength] attribute
  /// </summary>
  public static void Validate() {
    // Create view model and initialize Entity object
    ProductViewModel vm = new() {
      Entity = new() {
        ProductID = 1,
        Name = "Product 1",
        ProductNumber = "A very long product name to illustrate the [MaxLength] property.",
        Color = "A very long color name."
      }
    };

    // Validate the Data
    var msgs = vm.Validate();

    if (msgs.Count > 0) {
      // Display Failed Validation Messages
      foreach (ValidationMessage item in msgs) {
        Console.WriteLine(item);
      }

      // Display Total Count
      Console.WriteLine();
      Console.WriteLine($"Total Validations Failed: {msgs.Count}");
    }
    else {
      Console.WriteLine();
      Console.WriteLine("Entity is Valid");
    }

    // Pause to view the Results
    Console.ReadKey();
  }
}