﻿Description of the Samples
--------------------------------------------------
01-MaxLength - Show [MaxLength] attribute
02-MinLength - Show [MinLength] attribute
03-StringLength() - Show [StringLength] attribute
