﻿using Samples;

// Using the [MaxLength] attribute
Sample01.Sample01.Validate();

// Using the [MinLength] attribute
Sample02.Sample02.Validate();

// Using the [StringLength] attribute
Sample03.Sample03.Validate();