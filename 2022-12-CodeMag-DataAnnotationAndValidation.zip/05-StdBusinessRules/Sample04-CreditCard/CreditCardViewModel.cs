﻿using Samples;

namespace Sample04;

public class CreditCardViewModel {
  public CreditCardViewModel() {
    Entity = new();
  }

  public CreditCard Entity { get; set; }

  /// <summary>
  /// Validate using a helper class
  /// </summary>
  public List<ValidationMessage> Validate() {
    // Use Helper Class
    return ValidationHelper.Validate(Entity);
  }
}