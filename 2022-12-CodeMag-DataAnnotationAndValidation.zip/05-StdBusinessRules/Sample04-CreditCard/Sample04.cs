﻿using Samples;

namespace Sample04;

public class Sample04 {
  /// <summary>
  /// Validate an entity object
  /// Using the [CreditCard] attribute
  /// </summary>
  public static void Validate() {
    // Create view model and initialize Entity object
    CreditCardViewModel vm = new() {
      Entity = new() {
        CardType = "Visa",
        CardNumber = "12 13 123 1234",
        NameOnCard = "Joe Smith",
        BillingPostalCode = "99999",
        ExpMonth = 01,
        ExpYear = 2026,
        SecurityCode = "000"
      }
    };

    // Validate the Data
    var msgs = vm.Validate();

    if (msgs.Count > 0) {
      // Display Failed Validation Messages
      foreach (ValidationMessage item in msgs) {
        Console.WriteLine(item);
      }

      // Display Total Count
      Console.WriteLine();
      Console.WriteLine($"Total Validations Failed: {msgs.Count}");
    }
    else {
      Console.WriteLine();
      Console.WriteLine("Entity is Valid");
    }

    // Pause to view the Results
    Console.ReadKey();
  }
}