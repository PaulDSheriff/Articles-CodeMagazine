﻿// Test the [EmailAddress] attribute
Sample01.Sample01.Validate();

// Test the [Phone] attribute
//Sample02.Sample02.Validate();

// Test the [Url] attribute
//Sample03.Sample03.Validate();

// Test the [CreditCard] attribute
//Sample04.Sample04.Validate();