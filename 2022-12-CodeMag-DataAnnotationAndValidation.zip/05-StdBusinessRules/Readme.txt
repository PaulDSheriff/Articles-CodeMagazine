﻿Description of the Samples
--------------------------------------------------
01-EmailAddress() - Validate using the [EmailAddress] attribute
02-Phone() - Validate using the [Phone]
03-Url() - Validate using the [Url] attribute
04-CreditCard() - Validate using the [CreditCard] attribute