﻿#nullable disable

using System.ComponentModel.DataAnnotations;

namespace Sample01;

public class User {
  public int UserId { get; set; }
  public string LoginId { get; set; }
  [Compare(nameof(ConfirmPassword))]
  public string Password { get; set; }
  public string ConfirmPassword { get; set; }
  [EmailAddress()]
  public string EmailAddress { get; set; }
  public string Phone { get; set; }
}
