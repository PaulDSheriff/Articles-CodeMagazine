#nullable disable

using Samples;
using System.ComponentModel.DataAnnotations;

namespace Sample05;

public partial class Product
{
  public int ProductID { get; set; }

  [Display(Name = "Product Name")]
  [Required]
  [StringLength(50, MinimumLength = 4)]
  public string Name { get; set; }

  [Display(Name = "Product Number")]
  [StringLength(25, MinimumLength = 3)]
  public string ProductNumber { get; set; }

  [StringLength(15, MinimumLength = 3)]
  public string Color { get; set; }

  [Display(Name = "Cost")]
  [Required]
  [Range(0.01, 9999)]
  [CompareDecimalLessThan(nameof(ListPrice), ErrorMessage = "Cost must be less than the Price.")]
  public decimal? StandardCost { get; set; }

  [Display(Name = "Price")]
  [Required]
  [Range(0.01, 9999)]
  public decimal? ListPrice { get; set; }

  [Display(Name = "Start Selling Date")]
  [Required]
  [DateYearRange(-2, 5)]
  [CompareDateLessThan(nameof(SellEndDate), ErrorMessage = "Start Selling Date must be less than the End Selling Date.")]
  public DateTime SellStartDate { get; set; }

  [Display(Name = "End Selling Date")]
  [DateMaximum("12/31/2030")]
  public DateTime? SellEndDate { get; set; }

  [Display(Name = "Date Discontinued")]
  [DateMinimum("7/1/2022")]
  public DateTime? DiscontinuedDate { get; set; }

  public override string ToString()
  {
    return $"{Name} ({ProductID})";
  }
}