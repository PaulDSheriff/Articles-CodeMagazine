﻿using Samples;

namespace Sample05;

public class ProductViewModel {
  public ProductViewModel() {
    Entity = new();
  }

  public Product Entity { get; set; }

  /// <summary>
  /// Validate using a helper class
  /// </summary>
  public List<ValidationMessage> Validate() {
    // Use Helper Class
    return ValidationHelper.Validate(Entity);
  }
}