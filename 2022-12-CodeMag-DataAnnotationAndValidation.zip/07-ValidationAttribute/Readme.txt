﻿Description of the Samples
--------------------------------------------------
01-DateMaximum() - Use a custom [DateMaximum] attribute on the SellEndDate property
02-DateMinimum() - Use a custom [DateMinimum] attribute on the DiscontinuedDate property
03-DateYearRange() - Use a custom [DateYearRange] attribute on the SellStartDate property
04-CompareDateLessThan() - Use a custom [CompareDateLessThan] attribute on the SellStartDate property
05-CompareDecimalLessThan() - Use a custom [CompareDecimalLessThan] attribute on the StandardCost property