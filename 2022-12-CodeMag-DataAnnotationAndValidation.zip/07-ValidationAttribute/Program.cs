﻿// Test [DateMaximum] custom attribute
Sample01.Sample01.Validate();

// Test [DateMinimum] custom attribute
//Sample02.Sample02.Validate();

// Test [DateYearRange] custom attribute
//Sample03.Sample03.Validate();

// Test [CompareDateLessThan] custom attribute
//Sample04.Sample04.Validate();

// Test [CompareDecimalLessThan] custom attribute
//Sample05.Sample05.Validate();