#nullable disable

using Samples;
using System.ComponentModel.DataAnnotations;

namespace Sample02;

public partial class Product {
  public int ProductID { get; set; }

  [Display(Name = "Product Name")]
  [Required]
  [StringLength(50, MinimumLength = 4)]
  public string Name { get; set; }

  [Display(Name = "Product Number")]
  [StringLength(25, MinimumLength = 3)]
  public string ProductNumber { get; set; }

  [StringLength(15, MinimumLength = 3)]
  public string Color { get; set; }

  [Display(Name = "Cost")]
  [Required]
  [Range(0.01, 9999)]
  public decimal? StandardCost { get; set; }

  [Display(Name = "Price")]
  [Required]
  [Range(0.01, 9999)]
  public decimal? ListPrice { get; set; }

  [Display(Name = "Start Selling Date")]
  [Required]
  public DateTime SellStartDate { get; set; }

  [Display(Name = "End Selling Date")]
  [DateMaximum("12/31/2030")]
  public DateTime? SellEndDate { get; set; }

  [Display(Name = "Date Discontinued")]
  [DateMinimum("9/1/2022")]
  public DateTime? DiscontinuedDate { get; set; }

  public override string ToString() {
    return $"{Name} ({ProductID})";
  }
}