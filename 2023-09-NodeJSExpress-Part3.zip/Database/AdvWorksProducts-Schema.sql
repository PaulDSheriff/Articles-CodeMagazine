USE [AdvWorksProducts]
GO
/****** Object:  Table [dbo].[Product]    Script Date: 2/10/2023 1:24:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Product](
	[ProductID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[ProductNumber] [nvarchar](25) NOT NULL,
	[Color] [nvarchar](15) NULL,
	[StandardCost] [money] NOT NULL,
	[ListPrice] [money] NOT NULL,
	[ModifiedDate] [datetime] NOT NULL,
PRIMARY KEY NONCLUSTERED 
(
	[ProductID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  StoredProcedure [dbo].[Product_Search]    Script Date: 2/10/2023 1:24:31 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Product_Search]
	@Name nvarchar(50) null,
	@ListPrice money null
AS
BEGIN

print @Name;
print @ListPrice

	SELECT productID, [name], productNumber, color, standardCost, listPrice, modifiedDate FROM dbo.Product
    WHERE (@Name IS NULL OR [name] LIKE @Name + '%') 
	AND   (@ListPrice IS NULL OR ListPrice >= @ListPrice)
	ORDER BY [name], listPrice
END
GO
