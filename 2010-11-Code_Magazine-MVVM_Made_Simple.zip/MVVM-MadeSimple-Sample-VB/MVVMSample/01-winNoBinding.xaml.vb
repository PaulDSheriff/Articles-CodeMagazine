﻿Imports System
Imports System.Collections.ObjectModel
Imports System.Windows
Imports System.Windows.Controls

Partial Public Class winNoBinding
  Inherits Window

  Private mIsAddMode As Boolean = False

#Region "Constructor"
  Public Sub New()
    InitializeComponent()
  End Sub
#End Region

#Region "Loaded Event"
  Private Sub Window_Loaded(ByVal sender As Object, ByVal e As RoutedEventArgs)
    Dim mgr As New ProductManager()

    lstData.DataContext = mgr.GetProducts()
  End Sub
#End Region

#Region "SelectionChanged Event"
  Private Sub lstData_SelectionChanged(ByVal sender As Object, ByVal e As SelectionChangedEventArgs)
    Dim entity As Product
    entity = DirectCast(lstData.SelectedItem, Product)

    txtProductId.Text = entity.ProductId.ToString()
    txtProductName.Text = entity.ProductName
    txtPrice.Text = entity.Price.ToString()
    chkIsActive.IsChecked = entity.IsActive
  End Sub
#End Region

#Region "Add Click Event"
  Private Sub btnAdd_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    ' Put UI into Add Mode 
    mIsAddMode = True
    SetEditUIDisplay()

    ' Create empty input fields 
    txtProductId.Text = "0"
    txtProductName.Text = String.Empty
    txtPrice.Text = "0"
    chkIsActive.IsChecked = True
  End Sub
#End Region

#Region "Cancel Click Event"
  Private Sub btnCancel_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    ' Cancel the Edit 
    SetNormalUIDisplay()

    ' TODO: Write code to undo changes 

    lstData.SelectedIndex = 0
  End Sub
#End Region

#Region "Save Click Event"
  Private Sub btnSave_Click(ByVal sender As Object, ByVal e As RoutedEventArgs)
    If mIsAddMode Then
      AddData()
    Else
      UpdateData()
    End If

    SetNormalUIDisplay()
  End Sub
#End Region

#Region "AddData Method"
  Private Sub AddData()
    ' Save the Current Item 
    Dim entity As New Product()

    entity.ProductId = Convert.ToInt32(txtProductId.Text)
    entity.ProductName = txtProductName.Text
    entity.Price = Convert.ToDecimal(txtPrice.Text)
    entity.IsActive = Convert.ToBoolean(chkIsActive.IsChecked)

    Dim coll As ObservableCollection(Of Product) = DirectCast(lstData.DataContext, ObservableCollection(Of Product))

    ' TODO: Write code to save data to data store here 
    coll.Add(entity)
  End Sub
#End Region

#Region "UpdateData Method"
  Private Sub UpdateData()
    Dim entity As Product = DirectCast(lstData.SelectedItem, Product)

    entity.ProductId = Convert.ToInt32(txtProductId.Text)
    entity.ProductName = txtProductName.Text
    entity.Price = Convert.ToDecimal(txtPrice.Text)

    ' TODO: Write code to save data to data store here 
    entity.IsActive = Convert.ToBoolean(chkIsActive.IsChecked)
  End Sub
#End Region

#Region "SetNormalUIDisplay Method"
  Private Sub SetNormalUIDisplay()
    mIsAddMode = False
    btnAdd.IsEnabled = True
    btnSave.IsEnabled = False
    btnCancel.IsEnabled = False
  End Sub
#End Region

#Region "SetEditUIDisplay Method"
  Private Sub SetEditUIDisplay()
    btnAdd.IsEnabled = False
    btnSave.IsEnabled = True
    btnCancel.IsEnabled = True
  End Sub
#End Region

#Region "Data Has Changed Methods"
  Private Sub TextHasChanged(ByVal sender As Object, ByVal e As TextChangedEventArgs)
    ' Only Change Mode if Element has Keyboard Focus 
    If DirectCast(sender, UIElement).IsKeyboardFocused Then
      SetEditUIDisplay()
    End If
  End Sub

  Private Sub CheckedHasChanged(ByVal sender As Object, ByVal e As RoutedEventArgs)
    If DirectCast(sender, UIElement).IsKeyboardFocused OrElse DirectCast(sender, UIElement).IsMouseDirectlyOver Then
      SetEditUIDisplay()
    End If
  End Sub
#End Region
End Class