﻿Imports System.ComponentModel

Public Class Product
  Implements INotifyPropertyChanged

#Region "INotifyPropertyChanged"
  Public Event PropertyChanged As PropertyChangedEventHandler Implements INotifyPropertyChanged.PropertyChanged

  Protected Sub RaisePropertyChanged(ByVal propertyName As String)
    RaiseEvent PropertyChanged(Me, New PropertyChangedEventArgs(propertyName))
  End Sub
#End Region

#Region "Private Variables"
  Private mProductId As Integer = 0
  Private mProductName As String = String.Empty
  Private mPrice As Decimal = 0
  Private mIsActive As Boolean = True
#End Region

#Region "Public Properties"
  Public Property ProductId() As Integer
    Get
      Return mProductId
    End Get
    Set(ByVal value As Integer)
      If mProductId <> value Then
        mProductId = value
        RaisePropertyChanged("ProductId")
      End If
    End Set
  End Property

  Public Property ProductName() As String
    Get
      Return mProductName
    End Get
    Set(ByVal value As String)
      If mProductName <> value Then
        mProductName = value
        RaisePropertyChanged("ProductName")
      End If
    End Set
  End Property

  Public Property Price() As Decimal
    Get
      Return mPrice
    End Get
    Set(ByVal value As Decimal)
      If mPrice <> value Then
        mPrice = value
        RaisePropertyChanged("Price")
      End If
    End Set
  End Property

  Public Property IsActive() As Boolean
    Get
      Return mIsActive
    End Get
    Set(ByVal value As Boolean)
      If mIsActive <> value Then
        mIsActive = value
        RaisePropertyChanged("IsActive")
      End If
    End Set
  End Property
#End Region
End Class