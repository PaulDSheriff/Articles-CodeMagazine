﻿using System.Windows;

namespace MVVMSample
{
  public partial class App : Application
  {
  }
}
