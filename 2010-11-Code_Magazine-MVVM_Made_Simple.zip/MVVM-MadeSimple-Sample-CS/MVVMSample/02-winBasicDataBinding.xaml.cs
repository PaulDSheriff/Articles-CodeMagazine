﻿using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

namespace MVVMSample
{
  public partial class winBasicDataBinding : Window
  {
    ProductManager _DataManager;
    Product _Entity;
    bool _IsAddMode = false;

    #region Constructor
    public winBasicDataBinding()
    {
      InitializeComponent();
    }
    #endregion

    #region Loaded Event
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      _DataManager = new ProductManager();

      lstData.DataContext = _DataManager.GetProducts();
    }
    #endregion

    #region SelectionChanged Event
    private void lstData_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      _Entity = (Product)lstData.SelectedItem;

      grdDetail.DataContext = _Entity;
    }
    #endregion

    #region Add Click Event
    private void btnAdd_Click(object sender, RoutedEventArgs e)
    {
      // Create blank Object and Put UI into Add Mode
      // Put UI into Add Mode
      _IsAddMode = true;
      SetEditUIDisplay();

      grdDetail.DataContext = new Product();
    }
     #endregion

    #region Cancel Click Event
    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      // Cancel the Edit
      SetNormalUIDisplay();

      // TODO: Write code to undo changes

      lstData.SelectedIndex = 0;
    }
    #endregion

    #region Save Click Event
    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      if (_IsAddMode)
        AddData();
      else
        UpdateData();

      SetNormalUIDisplay();
    }
    #endregion

    #region AddData Method
    private void AddData()
    {
      // Save the Current Item
      Product entity = (Product)grdDetail.DataContext;

      ObservableCollection<Product> coll = (ObservableCollection<Product>)lstData.DataContext;
      coll.Add(entity);

      // TODO: Write code to save data to data store here
    }
    #endregion

    #region UpdateData Method
    private void UpdateData()
    {
      Product entity = (Product)lstData.SelectedItem;

      // TODO: Write code to save data to data store here
    }
    #endregion

    #region SetNormalUIDisplay Method
    private void SetNormalUIDisplay()
    {
      _IsAddMode = false;
      btnAdd.IsEnabled = true;
      btnSave.IsEnabled = false;
      btnCancel.IsEnabled = false;
    }
    #endregion

    #region SetEditUIDisplay Method
    private void SetEditUIDisplay()
    {
      btnAdd.IsEnabled = false;
      btnSave.IsEnabled = true;
      btnCancel.IsEnabled = true;
    }
    #endregion

    #region Data Has Changed Methods
    private void TextHasChanged(object sender, TextChangedEventArgs e)
    {
      // Only Change Mode if Element has Keyboard Focus
      if (((UIElement)sender).IsKeyboardFocused)
        SetEditUIDisplay();
    }

    private void CheckedHasChanged(object sender, RoutedEventArgs e)
    {
      if (((UIElement)sender).IsKeyboardFocused || ((UIElement)sender).IsMouseDirectlyOver)
        SetEditUIDisplay();
    }
    #endregion
  }
}
