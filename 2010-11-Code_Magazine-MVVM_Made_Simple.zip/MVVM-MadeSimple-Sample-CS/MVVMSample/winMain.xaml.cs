﻿using System.Windows;

namespace MVVMSample
{
  public partial class winMain : Window
  {
    public winMain()
    {
      InitializeComponent();
    }

    private void btnNoBinding_Click(object sender, RoutedEventArgs e)
    {
      winNoBinding win = new winNoBinding();

      win.Show();
    }

    private void btnBasicBinding_Click(object sender, RoutedEventArgs e)
    {
      winBasicDataBinding win = new winBasicDataBinding();

      win.Show();
    }

    private void btnOtherBinding_Click(object sender, RoutedEventArgs e)
    {
      winMoreDataBinding win = new winMoreDataBinding();

      win.Show();
    }

    private void btnSimpleMVVM_Click(object sender, RoutedEventArgs e)
    {
      winSimpleMVVM win = new winSimpleMVVM();

      win.Show();
    }
  }
}
