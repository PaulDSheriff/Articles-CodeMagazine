﻿Sample01 - The original sample from the last article
Sample02 - Add <form> tag, validation attributes and <li> elements
Sample03 - Initialize the product object and validate product form
Sample04 - Create custom validation directive
Sample05 - Add server-side validation and display error messages client-side