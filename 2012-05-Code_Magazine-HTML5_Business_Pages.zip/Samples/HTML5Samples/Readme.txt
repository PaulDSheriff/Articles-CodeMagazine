﻿In order to get the most out of these demos, be sure to download:

- VS 2010 SP 1:  http://bit.ly/nQzsld
- Microsoft .NET Framework Reliability Update 1:  http://bit.ly/qOG7Ni
- Opera Browser or IE 10 (beta or release if available)
  These demos work best in Opera browser or IE 10 beta

Some blog posts to check out:

http://bit.ly/HTML5FormsAndMVC
http://bit.ly/qE7jLz

New in HTML 5
http://www.w3.org/TR/html5-diff/

New in CSS 3
http://www.css3.info/preview/
