﻿// ***************************************************
// * BEGIN: Calculate Total in Product Selection Boxes
// ***************************************************
function calculateTotal(ctl) {
   // Get the total amount
   var total = $("#total").text();
   // Strip currency symbols and thousands separator
   total = stripCurrency(total);

   // Get the price from within this panel
   var price = $(ctl).closest(".panel")
               .find(".price").text();
   // Strip currency symbols and thousands separator
   price = stripCurrency(price);

   if ($(ctl).prop("checked")) {
      // Add to total
      total = parseFloat(total) +
                  parseFloat(price);
   }
   else {
      // Subtract from total
      total = parseFloat(total) -
                  parseFloat(price);
   }
   // Format the total and place into HTML
   $("#total").text(formatCurrency(total));
}

// **************************************************
// * Connect to 'change' event and calculate
// * total for any check boxes that are 'checked'
// **************************************************
$(document).ready(function () {
   // Connect to 'change' event to get price data
   $(checkOptions.id + " .btn-group input[type='checkbox']").change(function () {
      calculateTotal($(this));
   });

   // Get checkboxes that are checked
   var checked = $(checkOptions.id + " .btn-group input:checked");
   // Add all 'checked' values to get total
   for (var i = 0; i < checked.length; i++) {
      calculateTotal($(checked[i]));
   }
});
// *************************************************
// * END: Calculate Total in Product Selection Boxes
// *************************************************