﻿#nullable disable

using AdoNetWrapper.Common;

namespace AdoNetWrapperSamples.SearchClasses;

public class ProductAndDescriptionSearch {
  [Search("=")]
  public string Culture { get; set; }
}
