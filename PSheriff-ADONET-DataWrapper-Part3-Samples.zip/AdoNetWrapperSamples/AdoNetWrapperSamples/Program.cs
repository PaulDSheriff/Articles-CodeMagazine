﻿#nullable disable

using AdoNetWrapper.Common;
using AdoNetWrapperSamples.EntityClasses;
using AdoNetWrapperSamples.Models;
using AdoNetWrapperSamples.ParameterClasses;
using AdoNetWrapperSamples.SearchClasses;
using AdoNetWrapperSamples.ViewModelClasses;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.Data;

// Setup Host
using IHost host = Host.CreateDefaultBuilder().Build();

// Ask service provider for configuration
IConfiguration config = host.Services.GetRequiredService<IConfiguration>();

// Get connection string
string ConnectString = config.GetValue<string>("ConnectionStrings:DefaultConnection");

using AdvWorksDbContext db = new(ConnectString);

IDbCommand cmd= db.CreateCommand("SELECT ID, ProdName FROM SalesLT.Product");

try {
  List<Product> list = db.Database.Search<Product>(cmd);

  Console.WriteLine("*** Exception Handling Sample ***");
  // Display Data
  foreach (var item in list) {
    Console.WriteLine(item.ToString());
  }
  Console.WriteLine();
  Console.WriteLine($"Total Items: {list.Count}");
  Console.WriteLine();
  Console.WriteLine($"SQL Submitted: {db.Products.SQL}");
  Console.WriteLine();
}
catch (DatabaseException ex) {
  string msg = ex.ToString();
  // Check the 'msg' variable here
  //System.Diagnostics.Debugger.Break();
  Console.WriteLine(msg);
  System.Diagnostics.Debug.WriteLine(msg);
}
catch (Exception ex) {
  Console.WriteLine(ex.ToString());
}
