﻿#nullable disable

using AdoNetWrapper.Common;
using AdoNetWrapperSamples.RepositoryClasses;

namespace AdoNetWrapperSamples.Models;

public partial class AdvWorksDbContext : SqlServerDatabaseContext {
  public AdvWorksDbContext(string connectString) : base(connectString) { }

  protected override void Init() {
    base.Init();

    Database = new(this);
    Products = new(this);
    Customers = new(this);
  }

  public SqlServerRepositoryBase Database { get; set; }
  public ProductRepository Products { get; set; }
  public CustomerRepository Customers { get; set; }
}
