﻿#nullable disable

using AdoNetWrapper.Common;

namespace AdoNetWrapperSamples.ParameterClasses;

public class ProductSearchParam {
  public string Name { get; set; }
  public string ProductNumber { get; set; }
  public decimal? BeginningCost { get; set; }
  public decimal? EndingCost { get; set; }
}
