﻿#nullable disable

using AdoNetWrapper.Common;
using System.Data;

namespace AdoNetWrapperSamples.ParameterClasses;

public class ProductGetAllParam {
  [OutputParam(ParameterDirection.Output, Size = 10)]
  public string Result { get; set; }
}