#nullable disable

using AdoNetMVCSample.RepositoryClasses;
using AdoNetMVCSample.ViewModelLayer;
using Microsoft.AspNetCore.Mvc;

namespace AdventureWorksLT.Controllers {
  public class ProductController : Controller
  {
    public ProductController(ProductRepository  repo)
    {
      _Repo = repo;
    }

    private readonly ProductRepository _Repo;

    [HttpGet]
    public IActionResult ProductIndex()
    {
      // Create view model, passing in repository
      ProductViewModel vm = new(_Repo);

      // Call method to load Product objects
      vm.Search();

      return View(vm);
    }
  }
}
