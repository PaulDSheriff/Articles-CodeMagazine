﻿#nullable disable

using AdoNetWrapper.Common;
using System.Data;

namespace AdoNetMVCSample.ParameterClasses;

public class ProductGetAllParam {
  [OutputParam(ParameterDirection.Output, Size = 10)]
  public string Result { get; set; }
}