﻿#nullable disable

using AdoNetMVCSample.EntityClasses;
using AdoNetMVCSample.Models;

namespace AdoNetMVCSample.ViewModelClasses;

public class ProductCustomerViewModel {
  public ProductCustomerViewModel(string connectString) {
    ConnectString = connectString;
  }

  public string ConnectString { get; set; }
  public List<Product> Products { get; set; }
  public List<Customer> Customers { get; set; }

  public void LoadProductsAndCustomers() {
    string sql = "SELECT * FROM SalesLT.Product;";
    sql += "SELECT * FROM SalesLT.Customer";

    using AdvWorksDbContext db = new(ConnectString);

    // Create Command object
    var cmd = db.CreateCommand(sql);

    // Get the Product Data
    Products = db.Database.Search<Product>(cmd);

    // Advance to next result set
    db.DataReaderObject.NextResult();

    // Clear columns to get ready for next result set
    db.Database.Columns = new();

    // Get the Customer Data
    Customers = db.Database.Search<Customer>(cmd, db.DataReaderObject);
  }

  public bool InsertProductAndCustomer() {
    bool ret = true;

    using AdvWorksDbContext db = new(ConnectString);

    try {
      db.BeginTransaction();

      Product product = new() {
        ProductName = "Product to Insert",
        ProductNumber = "INS-001",
        Color = "Green",
        StandardCost = 5,
        ListPrice = 25,
        SellStartDate = DateTime.Now
      };

      product = db.Products.Insert(product);

      Customer customer = new() {
        CompanyName = "New Customer",
        FirstName = "John",
        LastName = "Doe",
        Title = "Mr.",
        PasswordHash = "Qa3aMCxNq9GZSUxcTM=",
        PasswordSalt = "Ls05W4g=",
        Rowguid = Guid.NewGuid(),
        ModifiedDate = DateTime.Now
      };

      customer = db.Customers.Insert(customer);

      // Commit the Transaction
      db.CommitTransaction();
    }
    catch (Exception ex) {
      ret = false;
      Console.Write(ex.ToString());
      // Rollback the Transaction
      db.RollbackTransaction();
    }

    return ret;
  }
}
