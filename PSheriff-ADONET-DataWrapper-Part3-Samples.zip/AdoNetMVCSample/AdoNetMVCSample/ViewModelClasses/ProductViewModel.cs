#nullable disable

using AdoNetMVCSample.EntityClasses;
using AdoNetMVCSample.RepositoryClasses;

namespace AdoNetMVCSample.ViewModelLayer {
  public partial class ProductViewModel {
    #region Constructors
    /// <summary>
    ///  NOTE: You need to have a parameterless constructor for Post-Backs in MVC    
    /// </summary>
    public ProductViewModel() {
      Init();
    }

    public ProductViewModel(ProductRepository repository) : base() {
      Repository = repository;
      Init();
    }
    #endregion

    #region Properties
    public ProductRepository Repository { get; set; }
    public List<Product> Products { get; set; }
    #endregion

    #region Init Method
    public void Init() {
      List<Product> Products = new();
    }
    #endregion

    #region Search Method
    public virtual void Search() {
      Products = Repository.Search();
    }
    #endregion
  }
}
