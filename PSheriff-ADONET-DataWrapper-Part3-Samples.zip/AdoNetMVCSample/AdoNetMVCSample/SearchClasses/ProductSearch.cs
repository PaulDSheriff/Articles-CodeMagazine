﻿#nullable disable

using AdoNetWrapper.Common;

namespace AdoNetMVCSample.SearchClasses;

public class ProductSearch {
  [Search("LIKE")]
  public string Name { get; set; }
  [Search(">=")]
  public decimal? ListPrice { get; set; }
}
