﻿#nullable disable

using AdoNetWrapper.Common;

namespace AdoNetMVCSample.SearchClasses;

public class ProductAndDescriptionSearch {
  [Search("=")]
  public string Culture { get; set; }
}
