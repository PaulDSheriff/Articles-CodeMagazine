﻿#nullable disable

using System.Data;
using System.Reflection;

namespace AdoNetWrapper.Common;

public class ColumnMapper {
  public ColumnMapper() {
    SearchOperator = "=";
    Direction = ParameterDirection.Input;
  }

  public string ColumnName { get; set; }
  public PropertyInfo PropertyInfo { get; set; }
  public object ParameterValue { get; set; }
  public string SearchOperator { get; set; }
  public bool IsKeyField { get; set; }
  public bool IsAutoIncrementing { get; set; }
  public ParameterDirection Direction { get; set; }
  public DbType DbType { get; set; }
  public int Size { get; set; }
}
