﻿#nullable disable

using System.Text;
using System.Data.SqlClient;

namespace AdoNetWrapper.Common;

public class SqlServerDatabaseException : DatabaseException {
  #region Constructors
  public SqlServerDatabaseException() : base() { }
  public SqlServerDatabaseException(string message) : base(message) { }
  public SqlServerDatabaseException(string message, Exception innerException) : base(message, innerException) { }
  public SqlServerDatabaseException(string message, Exception innerException, SqlCommand cmd) : base(message, innerException, cmd) { }
  #endregion

  #region HideLoginInfoForConnectionString
  public override string HideLoginInfoForConnectionString(string connectString) {
    SqlConnectionStringBuilder sb = new(connectString);

    if (!string.IsNullOrEmpty(sb.UserID)) {
      sb.UserID = "******";
    }
    if (!string.IsNullOrEmpty(sb.Password)) {
      sb.Password = "******";
    }

    return sb.ConnectionString;
  }
  #endregion

  #region GetDatabaseSpecificError
  protected override string GetDatabaseSpecificError(Exception ex) {
    StringBuilder sb = new(2048);

    if (ex is SqlException exp) {
      for (int index = 0; index <= exp.Errors.Count - 1; index++) {
        var current = exp.Errors[index];
        sb.AppendLine($"  **** BEGIN: SQL Server Exception #{(index + 1).ToString()} ****");
        sb.AppendLine($"  Type: {current.GetType().FullName}");
        sb.AppendLine($"  Message: {current.Message}");
        sb.AppendLine($"  Source: {current.Source}");
        sb.AppendLine($"  Server: {current.Server}");
        sb.AppendLine($"  Number: {current.Number.ToString()}\tState: {current.State.ToString()}\tClass: {current.Class.ToString()}");
        sb.AppendLine($"  Procedure: {current.Procedure}");
        sb.AppendLine($"  LineNumber: {current.LineNumber.ToString()}");
        sb.AppendLine($"  **** END: SQL Server Exception #{(index + 1).ToString()} ****");
      }
    }

    return sb.ToString();
  }
  #endregion
}
