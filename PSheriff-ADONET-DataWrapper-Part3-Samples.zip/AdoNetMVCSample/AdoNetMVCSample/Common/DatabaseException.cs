﻿#nullable disable

using System.Data;
using System.Text;

namespace AdoNetWrapper.Exceptions.Common;

public partial class DatabaseException : Exception {
  #region Constructors
  public DatabaseException() : base() { }
  public DatabaseException(string message) : base(message) { }
  public DatabaseException(string message, Exception innerException) : base(message, innerException) { }
  public DatabaseException(string message, Exception innerException, IDbCommand cmd) : base(message, innerException) {
    CommandObject = cmd;
  }
  #endregion

  #region Properties
  public IDbCommand CommandObject { get; set; }
  public string ExceptionType { get; set; }
  public string InnerExceptions { get; set; }
  public string SQL { get; set; }
  public string ConnectionString { get; set; }
  public string ParameterValues { get; set; }
  #endregion

  #region GatherExceptionInfo Method
  /// <summary>
  /// Gather exception information and set public properties
  /// </summary>
  public virtual void GatherExceptionInfo() {
    ExceptionType = string.Empty;
    ConnectionString = string.Empty;
    InnerExceptions = string.Empty;
    SQL = string.Empty;
    ParameterValues = string.Empty;

    if (this.InnerException != null) {
      ExceptionType = this.InnerException.GetType().FullName;
    }
    if (CommandObject != null) {
      if (!string.IsNullOrEmpty(CommandObject.Connection.ConnectionString)) {
        ConnectionString = HideLoginInfoForConnectionString(CommandObject.Connection.ConnectionString);
      }
      if (!string.IsNullOrEmpty(CommandObject.CommandText)) {
        SQL = CommandObject.CommandText;
      }
      if (CommandObject.Parameters != null && CommandObject.Parameters.Count > 0) {
        ParameterValues = GetCommandParametersAsString();
      }
    }
    InnerExceptions = GetInnerExceptionInfo();
  }
  #endregion

  #region GetCommandParametersAsString Method
  /// <summary>
  /// Gets all parameter names and values from the Command property and returns them all as a CRLF delimited string
  /// </summary>
  /// <returns>A string with all parameter names and values</returns>
  public virtual string GetCommandParametersAsString() {
    StringBuilder sb = new(1024);

    if (CommandObject != null && CommandObject.Parameters != null && CommandObject.Parameters.Count > 0) {
      foreach (IDbDataParameter param in CommandObject.Parameters) {
        sb.Append("  " + param.ParameterName);
        if (param.Value == null)
          sb.AppendLine(" = null");
        else
          sb.AppendLine(" = " + param.Value.ToString());
      }
    }

    return sb.ToString();
  }
  #endregion

  #region HideLoginInfoForConnectionString Method
  /// <summary>
  /// Looks for user id or password in a connection string and replaces their values with astericks.
  /// </summary>
  /// <param name="connectString">The connection string to check</param>
  /// <returns>A string with hidden user id and password values</returns>
  public virtual string HideLoginInfoForConnectionString(string connectString) {
    return connectString;
  }
  #endregion

  #region GetDatabaseSpecificError
  /// <summary>
  /// See if this exception is an error specific to the database provider
  /// </summary>
  /// <param name="ex">The exception to test</param>
  /// <returns>A string of database-specific error messages</returns>
  protected virtual string GetDatabaseSpecificError(Exception ex) {
    return string.Empty;
  }
  #endregion

  #region GetInnerExceptionInfo Method
  /// <summary>
  /// Looks for all inner exceptions and gets the error information for each
  /// </summary>
  /// <returns>A string of error information</returns>
  protected virtual string GetInnerExceptionInfo() {
    StringBuilder sb = new(1024);
    Exception ex;
    int index = 1;

    ex = InnerException;
    while (ex != null) {
      sb.AppendLine();
      // Is exception a database-specific error?
      string dbSpecific = GetDatabaseSpecificError(ex);
      // If no database-specific error, get normal exception info
      if (string.IsNullOrEmpty(dbSpecific)) {
        sb.AppendLine($"  **** BEGIN: Inner Exception #{index} ****");
        sb.AppendLine($"  Type: {ex.GetType().FullName}");
        sb.AppendLine($"  Message: {ex.Message}");
        sb.AppendLine($"  Source: {ex.Source}");
        sb.AppendLine($"  **** END: Inner Exception #{index} ****");
        index++;
      }
      else {
        sb.Append(dbSpecific);
      }
      // Get next inner exception
      ex = ex.InnerException;
    }

    return sb.ToString();
  }
  #endregion

  #region Override of ToString Method
  /// <summary>
  /// Gathers all information from the exception information gathered and returns a string
  /// </summary>
  /// <returns>A database specific error string</returns>
  public override string ToString() {
    StringBuilder sb = new(1024);
    string exDate = DateTime.Now.ToString();

    // Set all exception information properties
    GatherExceptionInfo();

    sb.AppendLine(new('-', 50));
    sb.AppendLine($"BEGIN: Exception Generated at {exDate}");
    sb.AppendLine(new('-', 50));
    if (!string.IsNullOrEmpty(Message)) {
      sb.AppendLine($"Message(s): {Message}");
    }
    sb.AppendLine($"Exception Type: {ExceptionType}");
    sb.AppendLine($"Connection String: {ConnectionString}");
    sb.AppendLine($"SQL: {SQL}");
    sb.AppendLine($"Command Parameters: {ParameterValues}");
    sb.AppendLine($"Inner Exceptions: {InnerExceptions}");
    // Stack Trace Info
    if (!string.IsNullOrEmpty(StackTrace)) {
      sb.AppendLine($"{new('=', 20)} BEGIN: Stack Trace Info {new('=', 20)}");
      sb.AppendLine(StackTrace);
      sb.AppendLine($"{new('=', 20)} END: Stack Trace Info {new('=', 20)}");
    }
    sb.AppendLine(new('-', 50));
    sb.AppendLine($"END: Exception Generated at {exDate}");
    sb.AppendLine(new('-', 50));

    return sb.ToString();
  }
  #endregion
}
