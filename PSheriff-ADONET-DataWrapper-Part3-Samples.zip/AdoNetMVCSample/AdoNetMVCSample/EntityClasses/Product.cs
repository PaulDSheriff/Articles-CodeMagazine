﻿#nullable disable

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AdoNetMVCSample.EntityClasses;

[Table("Product", Schema = "SalesLT")]
public partial class Product {
  [Key]
  [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
  [Column("ProductID")]
  [Display(Name = "Product Id")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  public int Id { get; set; }
  [Column("Name")]
  [Display(Name = "Product Name")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [StringLength(50, MinimumLength = 3,
  ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  public string ProductName { get; set; }
  [Display(Name = "Product Number")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [StringLength(25, MinimumLength = 2,
  ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  [MaxLength(25)]
  public string ProductNumber { get; set; }
  [Display(Name = "Color")]
  [StringLength(15, MinimumLength = 3,
  ErrorMessage = "{0} must be between {2} and {1} characters long.")]
  public string Color { get; set; }
  [Display(Name = "Standard Cost")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [DataType(DataType.Currency)]
  [Range(0.01, 9999999, ErrorMessage = "{0} must be between {1:c} and {2:c}")]
  public decimal StandardCost { get; set; }
  [Display(Name = "List Price")]
  [Required(ErrorMessage = "{0} must be filled in.")]
  [DataType(DataType.Currency)]
  [Range(0.01, 9999999, ErrorMessage = "{0} must be between {1:c} and {2:c}")]
  public decimal ListPrice { get; set; }
  public DateTime SellStartDate { get; set; }
  public DateTime? SellEndDate { get; set; }
  public DateTime? DiscontinuedDate { get; set; }

  public override string ToString() {
    return $"Product Name: {ProductName} - Product ID: {Id} - List Price: {ListPrice:c}";
  }
}
