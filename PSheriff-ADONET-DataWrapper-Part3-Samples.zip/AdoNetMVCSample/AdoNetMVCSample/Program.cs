using AdoNetMVCSample.Models;
using AdoNetMVCSample.RepositoryClasses;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Read in the connection string from the appSettings.json file
string connString = builder.Configuration.GetConnectionString("DefaultConnection");

// Setup the AdvWorks DB Context
AdvWorksDbContext db = new AdvWorksDbContext(connString);
builder.Services.AddSingleton(typeof(AdvWorksDbContext), db);

// Create a scoped version of Product Repository
builder.Services.AddScoped<ProductRepository, ProductRepository>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment()) {
  app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
