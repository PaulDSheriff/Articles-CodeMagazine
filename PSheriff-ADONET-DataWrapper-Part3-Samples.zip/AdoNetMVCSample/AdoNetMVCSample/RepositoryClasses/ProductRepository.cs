﻿#nullable disable

using AdoNetWrapper.Common;
using AdoNetMVCSample.EntityClasses;
using AdoNetMVCSample.Models;
using AdoNetMVCSample.SearchClasses;

namespace AdoNetMVCSample.RepositoryClasses;

public class ProductRepository : RepositoryBase {
  public ProductRepository(AdvWorksDbContext context) : base(context) {
  }

  public virtual List<Product> Search() {
    return base.Search<Product>();
  }

  public virtual List<Product> Search(ProductSearch search) {
    return base.Search<Product, ProductSearch>(search);
  }

  public virtual Product Find(int id) {
    return base.Find<Product>(id);
  }

  public virtual bool Validate(Product entity) {
    base.Validate<Product>(entity);

    // Perform any other validation here
    if (entity.StandardCost > entity.ListPrice) {
      ValidationMessages.Add(new() {
        PropertyName = "StandardCost",
        Message = "Cost must be Less Than the List Price"
      });
    }
    if (entity.SellStartDate > entity.SellEndDate) {
      ValidationMessages.Add(new() {
        PropertyName = "SellStartDate",
        Message = "Selling Start Date must be Less Than the Selling End Date"
      });
    }

    return ValidationMessages.Count == 0;
  }

  public virtual Product Insert(Product entity) {
    entity = base.Insert<Product>(entity);

    // OPTIONAL: Re-read from database to get any other generated values
    //entity = Find(entity.Id);

    return entity;
  }

  public virtual Product Update(Product entity) {
    entity = base.Update<Product>(entity);

    // OPTIONAL: Re-read from database to get any other generated values
    //entity = Find(entity.Id);

    return entity;
  }

  public virtual bool Delete(int id) {
    Product product = base.Find<Product>(id);

    return Delete(product);
  }

  public virtual bool Delete(Product entity) {
    return base.Delete<Product>(entity);
  }
}
