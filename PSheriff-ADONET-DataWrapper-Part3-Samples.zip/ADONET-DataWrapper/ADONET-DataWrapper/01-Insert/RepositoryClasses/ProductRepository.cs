﻿#nullable disable

using AdoNetWrapper.Insert.Common;
using AdoNetWrapperSamples.Insert.EntityClasses;
using AdoNetWrapperSamples.Insert.Models;
using AdoNetWrapperSamples.Insert.SearchClasses;

namespace AdoNetWrapperSamples.Insert.RepositoryClasses;

public class ProductRepository : RepositoryBase {
  public ProductRepository(AdvWorksDbContext context) : base(context) {
  }

  public virtual List<Product> Search() {
    return base.Search<Product>();
  }

  public virtual List<Product> Search(ProductSearch search) {
    return base.Search<Product, ProductSearch>(search);
  }

  public virtual Product Find(int id) {
    return base.Find<Product>(id);
  }

  public virtual bool Validate(Product entity) {
    bool ret = base.Validate<Product>(entity);

    // Perform any other validation here

    return ret;
  }

  public virtual Product Insert(Product entity) {
    entity = base.Insert<Product>(entity);

    // OPTIONAL: Re-read from database to get any other generated values
    //entity = Find(entity.Id);

    return entity;
  }

}
