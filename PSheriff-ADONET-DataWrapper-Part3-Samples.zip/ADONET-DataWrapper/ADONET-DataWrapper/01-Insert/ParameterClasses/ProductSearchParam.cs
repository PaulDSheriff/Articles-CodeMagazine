﻿#nullable disable

using AdoNetWrapper.Insert.Common;

namespace AdoNetWrapperSamples.Insert.ParameterClasses;

public class ProductSearchParam {
  public string Name { get; set; }
  public string ProductNumber { get; set; }
  public decimal? BeginningCost { get; set; }
  public decimal? EndingCost { get; set; }
}
