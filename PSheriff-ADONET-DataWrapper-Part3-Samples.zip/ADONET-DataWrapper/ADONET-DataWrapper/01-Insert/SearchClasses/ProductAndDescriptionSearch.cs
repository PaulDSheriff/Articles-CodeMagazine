﻿#nullable disable

using AdoNetWrapper.Insert.Common;

namespace AdoNetWrapperSamples.Insert.SearchClasses;

public class ProductAndDescriptionSearch {
  [Search("=")]
  public string Culture { get; set; }
}
