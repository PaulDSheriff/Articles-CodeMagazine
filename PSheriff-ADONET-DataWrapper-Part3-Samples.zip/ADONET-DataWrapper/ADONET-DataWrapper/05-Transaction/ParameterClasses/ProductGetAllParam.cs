﻿#nullable disable

using AdoNetWrapper.Transaction.Common;
using System.Data;

namespace AdoNetWrapperSamples.Transaction.ParameterClasses;

public class ProductGetAllParam {
  [OutputParam(ParameterDirection.Output, Size = 10)]
  public string Result { get; set; }
}