﻿#nullable disable

using AdoNetWrapper.Transaction.Common;

namespace AdoNetWrapperSamples.Transaction.SearchClasses;

public class ProductSearch {
  [Search("LIKE")]
  public string Name { get; set; }
  [Search(">=")]
  public decimal? ListPrice { get; set; }
}
