﻿#nullable disable

using AdoNetWrapper.Transaction.Common;

namespace AdoNetWrapperSamples.Transaction.SearchClasses;

public class ProductAndDescriptionSearch {
  [Search("=")]
  public string Culture { get; set; }
}
