﻿#nullable disable

namespace AdoNetWrapper.Transaction.Common;

[AttributeUsage(AttributeTargets.Property)]
public class SearchAttribute : Attribute {
  public string SearchOperator { get; set; }
  public string ColumnName { get; set; }

  public SearchAttribute(string searchOperator) {
    SearchOperator = searchOperator ?? "=";
  }
}
