﻿#nullable disable

using AdoNetWrapperSamples.Identity.EntityClasses;
using AdoNetWrapperSamples.Identity.Models;

public partial class Program {
  /// <summary>
  /// Insert a Product and Retrieve Identity Column
  /// </summary>
  public static void IdentitySample() {
    using AdvWorksDbContext db = new(ConnectString);

    Product entity = new() {
      ProductName = "Getting IDENTITY",
      ProductNumber = "IDENTITY",
      Color = "Blue",
      StandardCost = 30,
      ListPrice = 50,
      SellStartDate = DateTime.Now
    };

    entity = db.Products.Insert(entity);

    Console.WriteLine("*** Insert a Product, Retrieve Identity ***");
    // Display Result
    Console.WriteLine($"Product: {entity}");
    Console.WriteLine();
    Console.WriteLine($"SQL Submitted: {db.Products.SQL}");
    Console.WriteLine();
  }
}
