﻿#nullable disable

using AdoNetWrapper.Identity.Common;

namespace AdoNetWrapperSamples.Identity.SearchClasses;

public class ProductAndDescriptionSearch {
  [Search("=")]
  public string Culture { get; set; }
}
