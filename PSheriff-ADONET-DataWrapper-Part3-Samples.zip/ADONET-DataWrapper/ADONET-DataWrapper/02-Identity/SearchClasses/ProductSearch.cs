﻿#nullable disable

using AdoNetWrapper.Identity.Common;

namespace AdoNetWrapperSamples.Identity.SearchClasses;

public class ProductSearch {
  [Search("LIKE")]
  public string Name { get; set; }
  [Search(">=")]
  public decimal? ListPrice { get; set; }
}
