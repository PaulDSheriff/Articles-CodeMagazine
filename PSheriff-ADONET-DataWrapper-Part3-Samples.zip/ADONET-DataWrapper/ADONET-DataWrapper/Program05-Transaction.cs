﻿#nullable disable

using AdoNetWrapperSamples.Transaction.ViewModelClasses;

public partial class Program {
  /// <summary>
  /// Transaction
  /// </summary>
  public static void TransactionSample() {
    ProductCustomerViewModel vm = new(ConnectString);

    bool isSuccess = vm.InsertProductAndCustomer();

    Console.WriteLine("*** Perform a Transaction ***");
    // Display Result
    if (isSuccess) {
      Console.WriteLine($"Transaction Successful");
    }
    else {
      Console.WriteLine($"Transaction WAS NOT Successful");
    }
  }
}
