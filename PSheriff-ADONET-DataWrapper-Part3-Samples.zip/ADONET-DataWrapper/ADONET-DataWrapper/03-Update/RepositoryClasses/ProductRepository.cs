﻿#nullable disable

using AdoNetWrapper.Update.Common;
using AdoNetWrapperSamples.Update.EntityClasses;
using AdoNetWrapperSamples.Update.Models;
using AdoNetWrapperSamples.Update.SearchClasses;

namespace AdoNetWrapperSamples.Update.RepositoryClasses;

public class ProductRepository : RepositoryBase {
  public ProductRepository(AdvWorksDbContext context) : base(context) {
  }

  public virtual List<Product> Search() {
    return base.Search<Product>();
  }

  public virtual List<Product> Search(ProductSearch search) {
    return base.Search<Product, ProductSearch>(search);
  }

  public virtual Product Find(int id) {
    return base.Find<Product>(id);
  }

  public virtual bool Validate(Product entity) {
    bool ret = base.Validate<Product>(entity);

    // Perform any other validation here

    return ret;
  }

  public virtual Product Insert(Product entity) {
    entity = base.Insert<Product>(entity);

    // OPTIONAL: Re-read from database to get any other generated values
    //entity = Find(entity.Id);

    return entity;
  }

  public virtual Product Update(Product entity) {
    entity = base.Update<Product>(entity);

    // OPTIONAL: Re-read from database to get any other generated values
    //entity = Find(entity.Id);

    return entity;
  }

}
