﻿#nullable disable

using AdoNetWrapper.Update.Common;

namespace AdoNetWrapperSamples.Update.ParameterClasses;

public class ProductSearchParam {
  public string Name { get; set; }
  public string ProductNumber { get; set; }
  public decimal? BeginningCost { get; set; }
  public decimal? EndingCost { get; set; }
}
