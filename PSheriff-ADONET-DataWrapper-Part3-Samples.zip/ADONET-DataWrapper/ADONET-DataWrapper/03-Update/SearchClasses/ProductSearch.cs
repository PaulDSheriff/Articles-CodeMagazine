﻿#nullable disable

using AdoNetWrapper.Update.Common;

namespace AdoNetWrapperSamples.Update.SearchClasses;

public class ProductSearch {
  [Search("LIKE")]
  public string Name { get; set; }
  [Search(">=")]
  public decimal? ListPrice { get; set; }
}
