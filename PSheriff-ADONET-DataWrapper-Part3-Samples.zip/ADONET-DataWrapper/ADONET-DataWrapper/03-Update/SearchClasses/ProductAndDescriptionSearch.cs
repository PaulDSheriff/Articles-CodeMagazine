﻿#nullable disable

using AdoNetWrapper.Update.Common;

namespace AdoNetWrapperSamples.Update.SearchClasses;

public class ProductAndDescriptionSearch {
  [Search("=")]
  public string Culture { get; set; }
}
