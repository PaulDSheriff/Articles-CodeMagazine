﻿#nullable disable

using AdoNetWrapper.CustomValidation.Common;
using System.Data;

namespace AdoNetWrapperSamples.CustomValidation.ParameterClasses;

public class ProductGetAllParam {
  [OutputParam(ParameterDirection.Output, Size = 10)]
  public string Result { get; set; }
}