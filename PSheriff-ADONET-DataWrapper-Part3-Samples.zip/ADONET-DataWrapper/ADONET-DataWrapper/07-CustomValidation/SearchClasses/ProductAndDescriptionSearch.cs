﻿#nullable disable

using AdoNetWrapper.CustomValidation.Common;

namespace AdoNetWrapperSamples.CustomValidation.SearchClasses;

public class ProductAndDescriptionSearch {
  [Search("=")]
  public string Culture { get; set; }
}
