﻿#nullable disable

using AdoNetWrapper.CustomValidation.Common;

namespace AdoNetWrapperSamples.CustomValidation.SearchClasses;

public class ProductSearch {
  [Search("LIKE")]
  public string Name { get; set; }
  [Search(">=")]
  public decimal? ListPrice { get; set; }
}
