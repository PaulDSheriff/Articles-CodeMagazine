﻿#nullable disable

using AdoNetWrapper.CustomValidation.Common;
using AdoNetWrapperSamples.CustomValidation.EntityClasses;
using AdoNetWrapperSamples.CustomValidation.Models;

namespace AdoNetWrapperSamples.CustomValidation.RepositoryClasses;

public class CustomerRepository : RepositoryBase {
  public CustomerRepository(AdvWorksDbContext context) : base(context) {
  }

  public virtual List<Customer> Search() {
    return base.Search<Customer>();
  }

  public virtual Customer Find(int id) {
    return base.Find<Customer>(id);
  }

  public virtual bool Validate(Customer entity) {
    bool ret = base.Validate<Customer>(entity);

    // Perform any other validation here

    return ret;
  }

  public virtual Customer Insert(Customer entity) {
    entity = base.Insert<Customer>(entity);

    // OPTIONAL: Re-read from database to get any other generated values
    //entity = Find(entity.CustomerID);

    return entity;
  }

  public virtual Customer Update(Customer entity) {
    entity = base.Update<Customer>(entity);

    // OPTIONAL: Re-read from database to get any other generated values
    //entity = Find(entity.Id);

    return entity;
  }

  public virtual bool Delete(int id) {
    Customer Customer = base.Find<Customer>(id);

    return Delete(Customer);
  }

  public virtual bool Delete(Customer entity) {
    return base.Delete<Customer>(entity);
  }
}
