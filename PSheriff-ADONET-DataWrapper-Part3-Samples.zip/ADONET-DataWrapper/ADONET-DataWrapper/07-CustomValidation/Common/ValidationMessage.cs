﻿#nullable disable

namespace AdoNetWrapper.CustomValidation.Common;

public class ValidationMessage {
  public string PropertyName { get; set; }
  public string Message { get; set; }

  public override string ToString() {
    return $"{PropertyName} - {Message}";
  }
}