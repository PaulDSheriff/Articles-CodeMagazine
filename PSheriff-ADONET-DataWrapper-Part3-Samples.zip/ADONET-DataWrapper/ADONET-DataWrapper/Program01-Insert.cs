﻿#nullable disable

using AdoNetWrapperSamples.Insert.EntityClasses;
using AdoNetWrapperSamples.Insert.Models;

public partial class Program {
  /// <summary>
  /// Insert a Product
  /// </summary>
  public static void InsertSample() {
    using AdvWorksDbContext db = new(ConnectString);

    Product entity = new() {
      ProductName = "A New One",
      ProductNumber = "NEW-001",
      Color = "Red",
      StandardCost = 10,
      ListPrice = 20,
      SellStartDate = DateTime.Now
    };

    entity = db.Products.Insert(entity);

    Console.WriteLine("*** Insert a Product ***");
    // Display Result
    Console.WriteLine($"Product: {entity}");
    Console.WriteLine();
    Console.WriteLine($"SQL Submitted: {db.Products.SQL}");
    Console.WriteLine();
  }
}
