﻿#nullable disable

using AdoNetWrapperSamples.Validation.EntityClasses;
using AdoNetWrapperSamples.Validation.Models;

public partial class Program {
  /// <summary>
  /// Validation
  /// </summary>
  public static void ValidationSample() {
    using AdvWorksDbContext db = new(ConnectString);

    Product entity = new() {
      ProductName = "a",
      ProductNumber = "NEW-001-A-REALLY-LONG-PRODUCT-NUMBER-TO-TEST-VALIDATION",
      Color = "Red-A-REALLY-LONG-COLOR",
      StandardCost = -1,
      ListPrice = -2,
      SellStartDate = DateTime.Now
    };

    bool ret = db.Products.Validate(entity);

    Console.WriteLine("*** Validation Sample ***");
    // Display Result
    if (ret) {
      Console.WriteLine($"Product Validated");
    }
    else {
      Console.WriteLine($"Product NOT Validated");
      // Display Validation Messages
      foreach (var item in db.Products.ValidationMessages) {
        Console.WriteLine("   " + item);
      }
    }
    Console.WriteLine();
  }
}
