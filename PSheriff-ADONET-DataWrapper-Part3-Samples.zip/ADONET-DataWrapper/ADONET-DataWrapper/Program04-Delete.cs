﻿#nullable disable

using AdoNetWrapperSamples.Delete.EntityClasses;
using AdoNetWrapperSamples.Delete.Models;

public partial class Program {
  /// <summary>
  /// Delete a Product
  /// </summary>
  public static void DeleteSample() {
    using AdvWorksDbContext db = new(ConnectString);

    string sql = "SELECT Max(ProductID) FROM SalesLT.Product";
    int id = (int)db.Database.ExecuteScalar(sql);

    // Delete by Primary Key
    db.Products.Delete(id);

    Console.WriteLine("*** Delete a Product ***");
    // Display Result
    Console.WriteLine($"Product Deleted");
  }
}
