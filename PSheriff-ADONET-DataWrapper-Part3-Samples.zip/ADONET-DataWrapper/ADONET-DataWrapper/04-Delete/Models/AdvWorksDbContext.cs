﻿#nullable disable

using AdoNetWrapper.Delete.Common;
using AdoNetWrapperSamples.Delete.RepositoryClasses;

namespace AdoNetWrapperSamples.Delete.Models;

public partial class AdvWorksDbContext : SqlServerDatabaseContext {
  public AdvWorksDbContext(string connectString) : base(connectString) { }

  protected override void Init() {
    base.Init();

    Database = new(this);
    Products = new(this);
  }

  public SqlServerRepositoryBase Database { get; set; }
  public ProductRepository Products { get; set; }
}
