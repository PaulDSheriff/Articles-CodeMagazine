﻿#nullable disable

using AdoNetWrapper.Delete.Common;

namespace AdoNetWrapperSamples.Delete.SearchClasses;

public class ProductAndDescriptionSearch {
  [Search("=")]
  public string Culture { get; set; }
}
