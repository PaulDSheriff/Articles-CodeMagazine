﻿#nullable disable

using AdoNetWrapperSamples.Update.EntityClasses;
using AdoNetWrapperSamples.Update.Models;

public partial class Program {
  /// <summary>
  /// Update a Product
  /// </summary>
  public static void UpdateSample() {
    using AdvWorksDbContext db = new(ConnectString);

    string sql = "SELECT Max(ProductID) FROM SalesLT.Product";
    int id = (int)db.Database.ExecuteScalar(sql);

    Product entity = db.Products.Find(id);
    entity.Color += "CHANGED";
    entity.StandardCost = 99;
    entity.ListPrice = 299;

    entity = db.Products.Update(entity);

    Console.WriteLine("*** Update Product Data ***");
    Console.WriteLine($"Product: {entity}");
    Console.WriteLine();
    Console.WriteLine($"SQL Submitted: {db.Products.SQL}");
    Console.WriteLine();

  }
}
