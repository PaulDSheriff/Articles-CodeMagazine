﻿#nullable disable

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Reflection;
using System.Text;

namespace AdoNetWrapper.Exceptions.Common;

public class RepositoryBase {
  public RepositoryBase(DatabaseContext context) {
    DbContext = context;
    Init();
  }

  protected readonly DatabaseContext DbContext;

  public string SchemaName { get; set; }
  public string TableName { get; set; }
  public string SQL { get; set; }
  public List<ColumnMapper> Columns { get; set; }
  public List<ValidationMessage> ValidationMessages { get; set; }

  protected virtual void Init() {
    SchemaName = "dbo";
    TableName = string.Empty;
    SQL = string.Empty;
    Columns = new();
    ValidationMessages = new();
  }

  public virtual List<TEntity> Search<TEntity>() {
    // Build SQL from Entity class
    SQL = BuildSelectSql<TEntity>();
    // Create Command Object with SQL
    DbContext.CreateCommand(SQL);

    return Search<TEntity>(DbContext.CommandObject);
  }

  public virtual List<TEntity> Search<TEntity, TSearch>(TSearch search) {
    // Build SQL from Entity class
    SQL = BuildSelectSql<TEntity>();

    // Build collection of ColumnMapper objects
    // from properties in the TSearch object
    var searchColumns = BuildSearchColumnCollection<TEntity, TSearch>(search);

    if (searchColumns != null && searchColumns.Any()) {
      // Build the WHERE clause for Searching
      SQL += BuildSearchWhereClause(searchColumns);
    }

    // Create Command Object with SQL
    DbContext.CreateCommand(SQL);

    // Add any Parameters?
    if (searchColumns != null && searchColumns.Any()) {
      BuildWhereClauseParameters(DbContext.CommandObject, searchColumns);
    }

    return Search<TEntity>(DbContext.CommandObject);
  }

  public virtual List<TEntity> Search<TEntity>(IDbCommand cmd) {
    // Build Columns if needed
    if (Columns.Count == 0) {
      Columns = BuildColumnCollection<TEntity>();
    }

    // Set Command Object
    DbContext.CommandObject = cmd;

    return Search<TEntity>(cmd, DbContext.CreateDataReader());
  }

  public virtual List<TEntity> Search<TEntity>(IDbCommand cmd, IDataReader rdr) {
    List<TEntity> ret;

    // Build Columns if needed
    if (Columns.Count == 0) {
      Columns = BuildColumnCollection<TEntity>();
    }

    // Set Command Object
    DbContext.CommandObject = cmd;

    // Get the list of entity objects
    ret = BuildEntityList<TEntity>(rdr);

    return ret;
  }

  public virtual List<TEntity> SearchUsingStoredProcedure<TEntity, TParam>(TParam param, string sql) {
    List<ColumnMapper> searchColumns = new();
    List<TEntity> ret;

    // Store the SQL submitted
    SQL = sql;

    // Build columns collection for entity class
    Columns = BuildColumnCollection<TEntity>();

    // Create Command Object with SQL
    DbContext.CreateCommand(SQL);

    // Set CommandType to Stored Procedure
    DbContext.CommandObject.CommandType = CommandType.StoredProcedure;

    if (param != null) {
      // Build a collection of ColumnMapper objects based on properties in the TParam object
      searchColumns = BuildSearchColumnCollection<TEntity, TParam>(param);

      // Add any Parameters?
      if (searchColumns != null && searchColumns.Count > 0) {
        BuildWhereClauseParameters(DbContext.CommandObject, searchColumns);
      }

      // Add any Output Parameters?
      if (searchColumns.Where(c => c.Direction == ParameterDirection.Output || c.Direction == ParameterDirection.InputOutput).Any()) {
        BuildOutputParameters(DbContext.CommandObject, searchColumns);
      }
    }

    ret = BuildEntityList<TEntity>(DbContext.CreateDataReader());

    // Retrieve Any Output Parameters
    if (searchColumns.Where(c => c.Direction == ParameterDirection.Output || c.Direction == ParameterDirection.InputOutput).Any()) {
      // Must close DataReader for output parameters to be available
      DbContext.DataReaderObject.Close();

      GetOutputParameters(param, searchColumns);
    }

    return ret;
  }

  public virtual TEntity Find<TEntity>(params Object[] keyValues) where TEntity : class {
    // To assign null, use 'where TEntity : class'
    TEntity ret = null;

    if (keyValues != null) {
      List<ColumnMapper> searchColumns;

      // Build SQL from Entity class
      SQL = BuildSelectSql<TEntity>();

      // Build a collection of ColumnMapper objects based on [Key] attribute
      searchColumns = Columns.Where(col => col.IsKeyField).ToList();

      // Number of [Key] attributes on entity class
      // must match the number of key values passed in
      if (searchColumns.Count != keyValues.Length) {
        throw new ApplicationException("Not enough parameters passed to Find() method, or not enough [Key] attributes on the entity class.");
      }

      // Set the values into the searchColumns
      for (int i = 0; i < searchColumns.Count; i++) {
        searchColumns[i].ParameterValue = keyValues[i];
        searchColumns[i].SearchOperator = "=";
      }

      // Build the WHERE clause for Searching
      SQL += BuildSearchWhereClause(searchColumns);

      // Create command object with SQL
      DbContext.CreateCommand(SQL);

      // Add any Parameters?
      if (searchColumns != null && searchColumns.Any()) {
        BuildWhereClauseParameters(DbContext.CommandObject, searchColumns);
      }

      // Get the entity
      ret = Find<TEntity>(DbContext.CommandObject);
    }

    return ret;
  }

  public virtual TEntity Find<TEntity>(IDbCommand cmd) where TEntity : class {
    // To assign null, use 'where TEntity : class'
    TEntity ret = null;

    // Build Columns if needed
    if (Columns.Count == 0) {
      Columns = BuildColumnCollection<TEntity>();
    }

    // Get the entity
    var list = Search<TEntity>(cmd);

    // Check for a single record
    if (list != null && list.Any()) {
      // Assign the object to the return value
      ret = list[0];
    }

    return ret;
  }

  public virtual object ExecuteScalar(IDbCommand cmd) {
    object ret = null;

    try {
      // Open the Connection
      DbContext.CommandObject.Connection.Open();

      // Call the ExecuteScalar() method
      ret = DbContext.CommandObject.ExecuteScalar();
    }
    catch (Exception ex) {
      DbContext.HandleException(ex);
    }

    return ret;
  }

  public virtual object ExecuteScalar(string sql) {
    // Store the SQL submitted
    SQL = sql;

    // Create Command object with SQL
    DbContext.CreateCommand(SQL);

    // Return the value
    return ExecuteScalar(DbContext.CommandObject);
  }

  protected virtual List<ColumnMapper> BuildSearchColumnCollection<TEntity, TSearch>(TSearch search) {
    List<ColumnMapper> ret = new();
    ColumnMapper colMap;
    object value;

    // Get all the properties in <TSearch>
    PropertyInfo[] props =
      typeof(TSearch).GetProperties();

    // Loop through all properties
    foreach (PropertyInfo prop in props) {
      value = prop.GetValue(search, null);

      // Is the search property filled in or are we calling a stored procedure?
      if (value != null || (DbContext.CommandObject != null && DbContext.CommandObject.CommandType == CommandType.StoredProcedure)) {
        // Create a column mapping object
        colMap = new() {
          ColumnName = prop.Name,
          PropertyInfo = prop,
          SearchOperator = "=",
          ParameterValue = value
        };

        // Does Property have a [Search] attribute
        SearchAttribute sa = prop.GetCustomAttribute<SearchAttribute>();
        if (sa != null) {
          // Set column name from [Search] attribute
          colMap.ColumnName =
            string.IsNullOrWhiteSpace(sa.ColumnName)
              ? colMap.ColumnName : sa.ColumnName;
          colMap.SearchOperator =
            sa.SearchOperator ?? "=";
        }

        // Does the Property have a [OutputParam] attribute
        OutputParamAttribute oa = prop.GetCustomAttribute<OutputParamAttribute>();
        if (oa != null) {
          colMap.Direction = oa.Direction;
          colMap.DbType = oa.DbType;
          colMap.Size = oa.Size;
        }

        // Create collection of columns
        ret.Add(colMap);
      }
    }

    return ret;
  }

  protected virtual string BuildSearchWhereClause(List<ColumnMapper> columns) {
    StringBuilder sb = new(1024);
    string and = string.Empty;

    // Create WHERE clause
    sb.Append(" WHERE");
    foreach (var item in columns.Where(c => c.Direction == ParameterDirection.Input || c.Direction == ParameterDirection.InputOutput)) {
      sb.Append($"{and} {item.ColumnName} {item.SearchOperator} {DbContext.ParameterPrefix}{ item.ColumnName}");
      and = " AND";
    }

    return sb.ToString();
  }

  protected virtual void BuildWhereClauseParameters(IDbCommand cmd, List<ColumnMapper> whereColumns) {

    // Add parameters for each value passed in
    foreach (ColumnMapper item in whereColumns.Where(c => c.Direction == ParameterDirection.Input || c.Direction == ParameterDirection.InputOutput)) {
      var param = DbContext.CreateParameter(item.ColumnName, item.SearchOperator == "LIKE" ? item.ParameterValue + "%" : item.ParameterValue);
      // Add parameter value or DBNull value
      param.Value ??= DBNull.Value;

      cmd.Parameters.Add(param);

      if (cmd.CommandType != CommandType.StoredProcedure) {
        // Store parameter info
        Columns.Find(c => c.ColumnName == item.ColumnName).ParameterValue = item.ParameterValue;
      }
    }
  }

  protected virtual void BuildOutputParameters(IDbCommand cmd, List<ColumnMapper> columns) {
    // Add output parameters
    foreach (ColumnMapper item in columns.Where(c => c.Direction == ParameterDirection.Output || c.Direction == ParameterDirection.InputOutput)) {
      var param = DbContext.CreateParameter(item.ColumnName, null);
      param.Direction = item.Direction;
      param.DbType = item.DbType;
      cmd.Parameters.Add(param);
    }
  }

  protected virtual void GetOutputParameters<TParam>(TParam param, List<ColumnMapper> columns) {
    // Get output parameters
    foreach (ColumnMapper item in columns.Where(c => c.Direction == ParameterDirection.Output || c.Direction == ParameterDirection.InputOutput)) {
      // Get the output parameter
      var outParam = DbContext.GetParameter(item.ColumnName);
      // Set the value on the parameter object
      typeof(TParam).GetProperty(item.ColumnName).SetValue(param, outParam.Value, null);
    }
  }

  protected virtual string BuildSelectSql<TEntity>() {
    Type typ = typeof(TEntity);
    StringBuilder sb = new(2048);
    string comma = string.Empty;

    // Build Column Mapping Collection
    Columns = BuildColumnCollection<TEntity>();

    // Set Table and Schema properties
    SetTableAndSchemaName(typ);

    // Build the SELECT statement
    sb.Append("SELECT");
    foreach (ColumnMapper item in Columns) {
      // Add column
      sb.Append($"{comma} [{item.ColumnName}]");
      comma = ",";
    }
    // Add 'FROM schema.table'
    sb.Append($" FROM {SchemaName}.{TableName}");

    return sb.ToString();
  }

  protected virtual void SetTableAndSchemaName(Type typ) {
    // Is there is a [Table] attribute?
    TableAttribute table = typ.GetCustomAttribute<TableAttribute>();
    // Assume table name is the class name
    TableName = typ.Name;
    if (table != null) {
      // Set properties from [Table] attribute
      TableName = table.Name;
      SchemaName = table.Schema ?? SchemaName;
    }
  }

  protected virtual List<ColumnMapper> BuildColumnCollection<TEntity>() {
    List<ColumnMapper> ret = new();
    ColumnMapper colMap;

    // Get all the properties in <TEntity>
    PropertyInfo[] props = typeof(TEntity).GetProperties();

    // Loop through all properties
    foreach (PropertyInfo prop in props) {
      // Is there a [NotMapped] attribute?
      NotMappedAttribute nm = prop.GetCustomAttribute<NotMappedAttribute>();
      // Only add properties that map to a column
      if (nm == null) {
        // Create a column mapping object
        colMap = new() {
          // Set column properties
          PropertyInfo = prop,
          ColumnName = prop.Name
        };

        // Is column name in [Column] attribute?
        ColumnAttribute ca = prop.GetCustomAttribute<ColumnAttribute>();
        if (ca != null && !string.IsNullOrEmpty(ca.Name)) {
          // Set column name from [Column] attr
          colMap.ColumnName = ca.Name;
        }

        // Is the column a primary [Key]?
        KeyAttribute key = prop.GetCustomAttribute<KeyAttribute>();
        colMap.IsKeyField = key != null;
        // Check for [DatabaseGenerated] attribute
        // Is the column an auto-incrementing column?
        DatabaseGeneratedAttribute dg = prop.GetCustomAttribute<DatabaseGeneratedAttribute>();
        if (dg != null) {
          colMap.IsAutoIncrementing = dg.DatabaseGeneratedOption == DatabaseGeneratedOption.Identity || dg.DatabaseGeneratedOption == DatabaseGeneratedOption.Computed;
        }

        // Create collection of columns
        ret.Add(colMap);
      }
    }

    return ret;
  }

  protected virtual List<TEntity> BuildEntityList<TEntity>(IDataReader rdr) {
    List<TEntity> ret = new();

    // Loop through all rows in the data reader
    while (rdr.Read()) {
      // Create new instance of Entity
      TEntity entity = Activator.CreateInstance<TEntity>();

      // Loop through columns collection
      for (int index = 0; index < Columns.Count; index++) {
        // Get the value from the reader
        var value = rdr[Columns[index].ColumnName];

        // Assign value to the property if not null
        if (!value.Equals(DBNull.Value)) {
          Columns[index].PropertyInfo.SetValue(entity, value, null);
        }
      }

      // Add new entity to the list
      ret.Add(entity);
    }

    return ret;
  }

  public virtual int ExecuteNonQuery(IDbCommand cmd) {
    int ret = 0;

    try {
      // Open the Connection
      if (DbContext.CommandObject.Connection.State != ConnectionState.Open) {
        DbContext.CommandObject.Connection.Open();
      }

      // Call the ExecuteNonQuery() method
      ret = DbContext.CommandObject.ExecuteNonQuery();
    }
    catch (Exception ex) {
      DbContext.HandleException(ex);
    }

    return ret;
  }

  public virtual int ExecuteNonQuery(string sql) {
    // Store the SQL submitted
    SQL = sql;

    // Create Command object with SQL
    DbContext.CreateCommand(SQL);

    // Execute the Query
    return ExecuteNonQuery(DbContext.CommandObject);
  }

  protected virtual string BuildInsertStatement<TEntity>(TEntity entity) {
    StringBuilder sbCol = new(1024);
    StringBuilder sbParam = new(1024);
    string comma = string.Empty;
    Type typ = typeof(TEntity);

    // Build Column Mapping Collection
    Columns = BuildColumnCollection<TEntity>();

    // Set Table and Schema properties
    SetTableAndSchemaName(typ);

    // Build the INSERT statement
    sbCol.Append($"INSERT INTO {SchemaName}.{TableName} (");
    foreach (ColumnMapper item in Columns.Where(c => !c.IsAutoIncrementing)) {
      // Add column
      sbCol.Append($"{comma}[{item.ColumnName}]");
      // Add Parameter
      sbParam.Append($"{comma}{DbContext.ParameterPrefix}{item.ColumnName}");
      comma = ", ";
    }
    sbCol.Append(") VALUES (");
    sbCol.Append(sbParam);
    sbCol.Append(')');

    return sbCol.ToString();
  }

  protected virtual void BuildParametersForModification(IDbCommand cmd,
    List<ColumnMapper> columns) {
    // Add parameters for each value passed in
    foreach (ColumnMapper item in columns) {
      var param = DbContext.CreateParameter(item.ColumnName, item.ParameterValue ?? DBNull.Value);
      cmd.Parameters.Add(param);
    }
  }

  protected virtual void SetColumnValues<TEntity>(TEntity entity) {
    // Loop through all properties
    foreach (ColumnMapper colMap in Columns) {

      // Set property value
      colMap.ParameterValue = colMap.PropertyInfo.GetValue(entity);
    }
  }

  public virtual bool Validate<TEntity>(TEntity entity) {
    string propName;
    ValidationMessages.Clear();

    if (entity != null) {
      ValidationContext context = new(entity);
      List<ValidationResult> results = new();

      if (!Validator.TryValidateObject(entity, context, results, true)) {
        foreach (ValidationResult item in results) {
          propName = string.Empty;
          if (item.MemberNames.Any()) {
            propName = item.MemberNames.ToList()[0];
          }
          ValidationMessages.Add(new() { Message = item.ErrorMessage, PropertyName = propName });
        }
      }
    }

    return ValidationMessages.Count == 0;
  }

  public virtual TEntity Insert<TEntity>(TEntity entity) {
    if (Validate<TEntity>(entity)) {
      // Build INSERT Statement
      SQL = BuildInsertStatement<TEntity>(entity);

      // Create Command Object with SQL
      DbContext.CreateCommand(SQL);

      // Set Values into ColumnMapper Objects
      SetColumnValues<TEntity>(entity);

      // Build Parameters
      BuildParametersForModification(
        DbContext.CommandObject, Columns);

      // Submit the Query
      ExecuteNonQuery(DbContext.CommandObject);

      // Get IDENTITY if needed
      GetLastAutoIncrement<TEntity>(DbContext.CommandObject, entity);
    }

    return entity;
  }

  protected virtual void GetLastAutoIncrement<TEntity>(IDbCommand cmd, TEntity entity) {
    if (Columns.Where(c => c.IsAutoIncrementing).Any()) {
      ColumnMapper colMap = Columns.Find(c => c.IsAutoIncrementing);
      DbContext.GetLastAutoIncrement(cmd, entity, colMap.PropertyInfo);
    }
  }

  protected virtual string BuildUpdateStatement<TEntity>(TEntity entity) {
    StringBuilder sb = new(2048);
    string comma = string.Empty;
    string and = string.Empty;
    Type typ = typeof(TEntity);

    // Build Column Mapping Collection
    Columns = BuildColumnCollection<TEntity>();

    // Set Table and Schema properties
    SetTableAndSchemaName(typ);

    // Build the UPDATE statement
    sb.Append($"UPDATE {SchemaName}.{TableName} SET");
    foreach (ColumnMapper item in Columns.Where(c => !c.IsAutoIncrementing)) {
      // Add column
      sb.Append($"{comma}[{item.ColumnName}] = {DbContext.ParameterPrefix}{item.ColumnName}");
      comma = ", ";
    }
    sb.Append(" WHERE ");
    foreach (ColumnMapper item in Columns.Where(c => c.IsKeyField)) {
      // Add WHERE Clause
      sb.Append($"{and}{item.ColumnName} = {DbContext.ParameterPrefix}{item.ColumnName}");
      and = " AND ";
    }

    return sb.ToString();
  }

  public virtual TEntity Update<TEntity>(TEntity entity) {
    if (Validate<TEntity>(entity)) {
      // Build UPDATE Statement
      SQL = BuildUpdateStatement<TEntity>(entity);

      // Create Command Object with SQL
      DbContext.CreateCommand(SQL);

      // Set Values into ColumnMapper Objects
      SetColumnValues<TEntity>(entity);

      // Build Parameters
      BuildParametersForModification(DbContext.CommandObject, Columns);

      // Submit the Query
      ExecuteNonQuery(DbContext.CommandObject);
    }

    return entity;
  }

  protected virtual string BuildDeleteStatement<TEntity>(TEntity entity) {
    StringBuilder sb = new(2048);
    string and = string.Empty;
    Type typ = typeof(TEntity);

    // Build Column Mapping Collection
    Columns = BuildColumnCollection<TEntity>();

    // Set Table and Schema properties
    SetTableAndSchemaName(typ);

    // Build the DELETE statement
    sb.Append($"DELETE FROM {SchemaName}.{TableName}");
    sb.Append(" WHERE ");
    foreach (ColumnMapper item in Columns.Where(c => c.IsKeyField)) {
      // Add WHERE Clause
      sb.Append($"{and}{item.ColumnName} = {DbContext.ParameterPrefix}{item.ColumnName}");
      and = " AND ";
    }

    return sb.ToString();
  }

  public virtual bool Delete<TEntity>(TEntity entity) {
    bool ret = true;

    // Build DELETE Statement
    SQL = BuildDeleteStatement<TEntity>(entity);

    // Create Command Object with SQL
    DbContext.CreateCommand(SQL);

    // Set Values into ColumnMapper Objects
    SetColumnValues<TEntity>(entity);

    // Build Parameters
    BuildWhereClauseParameters(DbContext.CommandObject, Columns.Where(c => c.IsKeyField).ToList());

    // Submit the Query
    ExecuteNonQuery(DbContext.CommandObject);

    return ret;
  }

}
