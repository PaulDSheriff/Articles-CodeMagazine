﻿#nullable disable

using AdoNetWrapper.Exceptions.Common;

namespace AdoNetWrapperSamples.Exceptions.SearchClasses;

public class ProductAndDescriptionSearch {
  [Search("=")]
  public string Culture { get; set; }
}
