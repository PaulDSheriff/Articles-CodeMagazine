﻿#nullable disable

using AdoNetWrapper.Exceptions.Common;

namespace AdoNetWrapperSamples.Exceptions.SearchClasses;

public class ProductSearch {
  [Search("LIKE")]
  public string Name { get; set; }
  [Search(">=")]
  public decimal? ListPrice { get; set; }
}
