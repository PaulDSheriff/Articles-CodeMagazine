﻿#nullable disable

using AdoNetWrapper.Exceptions.Common;
using System.Data;

namespace AdoNetWrapperSamples.Exceptions.ParameterClasses;

public class ProductGetAllParam {
  [OutputParam(ParameterDirection.Output, Size = 10)]
  public string Result { get; set; }
}