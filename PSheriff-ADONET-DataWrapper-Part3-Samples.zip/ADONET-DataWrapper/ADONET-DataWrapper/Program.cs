﻿#nullable disable

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

public partial class Program {

  private static string ConnectString;
  //private static string Sql = "SELECT * FROM SalesLT.Product";

  public static void Main() {
    // Setup Host
    using IHost host = Host.CreateDefaultBuilder().Build();

    // Ask the service provider for the configuration abstraction.
    IConfiguration config = host.Services.GetRequiredService<IConfiguration>();

    // Get values from the config given their key and their target type.
    ConnectString = config.GetValue<string>("ConnectionStrings:DefaultConnection");
        
    // *******************************************
    // Sample 01: Insert a Product
    // *******************************************
    //Program.InsertSample();

    // **************************************************
    // Sample 02: Insert and Retrieve Identity
    // **************************************************
    //Program.IdentitySample();

    // **************************************************
    // Sample 03: Update
    // **************************************************
    //Program.UpdateSample();

    // **************************************************
    // Sample 04: Delete
    // **************************************************
    //Program.DeleteSample();

    // **************************************************
    // Sample 05: Transaction
    // **************************************************
    //Program.TransactionSample();

    // **************************************************
    // Sample 06: Validation
    // **************************************************
    //Program.ValidationSample();

    // **************************************************
    // Sample 07: Custom Validation
    // **************************************************
    //Program.CustomValidationSample();

    // **************************************************
    // Sample 08: Exception Handling
    // **************************************************
    Program.ExceptionsSample();
  }
}
