﻿#nullable disable

using AdoNetWrapper.Validation.Common;
using AdoNetWrapperSamples.Validation.RepositoryClasses;

namespace AdoNetWrapperSamples.Validation.Models;

public partial class AdvWorksDbContext : SqlServerDatabaseContext {
  public AdvWorksDbContext(string connectString) : base(connectString) { }

  protected override void Init() {
    base.Init();

    Database = new(this);
    Products = new(this);
    Customers = new(this);
  }

  public SqlServerRepositoryBase Database { get; set; }
  public ProductRepository Products { get; set; }
  public CustomerRepository Customers { get; set; }
}
