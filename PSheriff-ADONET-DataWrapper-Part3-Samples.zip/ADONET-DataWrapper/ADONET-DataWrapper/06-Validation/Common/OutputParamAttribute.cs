﻿#nullable disable

using System.Data;

namespace AdoNetWrapper.Validation.Common;

[AttributeUsage(AttributeTargets.Property)]
public class OutputParamAttribute : Attribute {
  public ParameterDirection Direction { get; set; }
  public DbType DbType { get; set; }
  public int Size { get; set; }

  public OutputParamAttribute(ParameterDirection direction) {
    Direction = direction;
  }
}
