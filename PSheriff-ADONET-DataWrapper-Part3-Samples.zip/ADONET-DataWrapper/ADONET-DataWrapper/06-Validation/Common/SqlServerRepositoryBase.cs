﻿#nullable disable

using System.Data;
using System.Data.SqlClient;

namespace AdoNetWrapper.Validation.Common;

public class SqlServerRepositoryBase : RepositoryBase {
  public SqlServerRepositoryBase(SqlServerDatabaseContext context) : base(context) { }

  protected override void BuildOutputParameters(IDbCommand cmd, List<ColumnMapper> columns) {
    // Add output parameters
    foreach (ColumnMapper item in columns.Where(c => c.Direction == ParameterDirection.Output)) {
      var param = (SqlParameter)DbContext.CreateParameter(item.ColumnName, null);
      param.Direction = item.Direction;
      param.DbType = item.DbType;
      // Need to set the Size for SQL Server
      param.Size = item.Size;
      cmd.Parameters.Add(param);
    }
  }
}
