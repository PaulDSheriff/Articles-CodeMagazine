﻿#nullable disable

using AdoNetWrapper.Validation.Common;

namespace AdoNetWrapperSamples.Validation.SearchClasses;

public class ProductSearch {
  [Search("LIKE")]
  public string Name { get; set; }
  [Search(">=")]
  public decimal? ListPrice { get; set; }
}
