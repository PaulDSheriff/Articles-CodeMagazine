﻿#nullable disable

using AdoNetWrapper.Validation.Common;

namespace AdoNetWrapperSamples.Validation.SearchClasses;

public class ProductAndDescriptionSearch {
  [Search("=")]
  public string Culture { get; set; }
}
