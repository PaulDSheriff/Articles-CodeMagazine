﻿#nullable disable

using AdoNetWrapper.Validation.Common;
using System.Data;

namespace AdoNetWrapperSamples.Validation.ParameterClasses;

public class ProductGetAllParam {
  [OutputParam(ParameterDirection.Output, Size = 10)]
  public string Result { get; set; }
}