﻿#nullable disable

using AdoNetWrapper.Exceptions.Common;
using AdoNetWrapperSamples.Exceptions.EntityClasses;
using AdoNetWrapperSamples.Exceptions.Models;
using System.Data;

public partial class Program {
  /// <summary>
  /// Handle Exceptions
  /// </summary>
  public static void ExceptionsSample() {
    using AdvWorksDbContext db = new(ConnectString);

    IDbCommand cmd = db.CreateCommand("SELECT ID, ProdName FROM SalesLT.Product");
    
    try {
      List<Product> list = db.Database.Search<Product>(cmd);

      Console.WriteLine("*** Exception Handling Sample ***");
      // Display Data
      foreach (var item in list) {
        Console.WriteLine(item.ToString());
      }
      Console.WriteLine();
      Console.WriteLine($"Total Items: {list.Count}");
      Console.WriteLine();
      Console.WriteLine($"SQL Submitted: {db.Products.SQL}");
      Console.WriteLine();
    }
    catch (DatabaseException ex) {
      string msg = ex.ToString();
      // Check the 'msg' variable here
      //System.Diagnostics.Debugger.Break();
      Console.WriteLine(msg);
      System.Diagnostics.Debug.WriteLine(msg);
    }
    catch (Exception ex) {
      Console.WriteLine(ex.ToString());
    }
  }
}
