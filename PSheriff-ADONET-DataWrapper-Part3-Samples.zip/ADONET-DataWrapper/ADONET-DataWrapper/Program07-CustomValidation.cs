﻿#nullable disable

using AdoNetWrapperSamples.CustomValidation.EntityClasses;
using AdoNetWrapperSamples.CustomValidation.Models;

public partial class Program {
  /// <summary>
  /// Custom Validation
  /// </summary>
  public static void CustomValidationSample() {
    using AdvWorksDbContext db = new(ConnectString);

    Product entity = new() {
      ProductName = "a",
      ProductNumber = "NEW-001-A-REALLY-LONG-PRODUCT-NUMBER-TO-TEST-VALIDATION",
      Color = "Red-A-REALLY-LONG-COLOR",
      StandardCost = 10,
      ListPrice = 5,
      SellStartDate = DateTime.Now,
      SellEndDate = DateTime.Now.AddDays(-5)
    };

    bool ret = db.Products.Validate(entity);

    Console.WriteLine("*** Validation Sample ***");
    // Display Result
    if (ret) {
      Console.WriteLine($"Product Validated");
    }
    else {
      Console.WriteLine($"Product NOT Validated");
      // Display Validation Messages
      foreach (var item in db.Products.ValidationMessages) {
        Console.WriteLine("   " + item);
      }
    }
    Console.WriteLine();
  }
}
