﻿To run this sample you need to create a database and run the \SQLScripts\Product.sql file in that database.
You also need to modify the Web.config and change the connection string to point to your database.
