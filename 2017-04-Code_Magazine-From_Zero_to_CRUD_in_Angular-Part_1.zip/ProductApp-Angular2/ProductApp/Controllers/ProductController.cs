﻿using ProductApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace ProductApp.Controllers
{
  public class ProductController : ApiController
  {
    // GET api/<controller>
    public IHttpActionResult Get() {
      IHttpActionResult ret;
      ProductDB db = new ProductDB();

      if (db.Products.Count() > 0) {
        ret = Ok(db.Products);
      }
      else {
        ret = NotFound();
      }

      return ret;
    }
  }
}