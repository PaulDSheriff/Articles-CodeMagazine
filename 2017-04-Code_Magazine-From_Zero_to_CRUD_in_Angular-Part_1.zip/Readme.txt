In this ZIP file are two folders. One is for Angular 2 and the other is for Angular 4

When I wrote this article, the current version was Angular 2. Since then, Angular 4 has been released. I included both the Angular 2 and 4 versions of this application in the download for the last article. I will continue this article using the Angular 4 version. There are not too many changes that must be made to upgrade from Angular 2 to Angular 4. Below are the changes I made.

- Installed TypeScript 2.2
- Created the project from scratch and downloaded the Angular Quick Start from http://bit.ly/29y5J9i. 
- Followed the instructions for using Angular in Visual Studio located at http://bit.ly/26143AE.
- All files are now located under the \src folder from the root of the Visual Studio project.
- Eliminated the moduleId: module.id from all components.

That is all the changes that had to be made. Everything else works just as I explained in the last article.
