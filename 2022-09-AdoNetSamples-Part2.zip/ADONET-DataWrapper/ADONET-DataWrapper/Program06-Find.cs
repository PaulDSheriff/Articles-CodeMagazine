﻿#nullable disable

using AdoNetWrapperSamples.Find.EntityClasses;
using AdoNetWrapperSamples.Find.Models;
using AdoNetWrapperSamples.Find.SearchClasses;

public partial class Program {
  /// <summary>
  /// Find a Single Record
  /// </summary>
  public static void FindSample() {
    using AdvWorksDbContext db = new(ConnectString);

    Product entity = db.Products.Find(706);

    Console.WriteLine("*** Get Product Data ***");
    if (entity == null) {
      Console.WriteLine("Can't Find Product ID=706");
    }
    else {
      // Display Data
      Console.WriteLine(entity.ToString());
      Console.WriteLine();
      Console.WriteLine($"SQL Submitted: {db.Products.SQL}");
    }
    Console.WriteLine();
  }
}
