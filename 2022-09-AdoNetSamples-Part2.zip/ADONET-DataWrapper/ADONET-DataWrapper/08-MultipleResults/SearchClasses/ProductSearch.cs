﻿#nullable disable

using AdoNetWrapper.MultipleResults.Common;

namespace AdoNetWrapperSamples.MultipleResults.SearchClasses;

public class ProductSearch {
  [Search("LIKE")]
  public string Name { get; set; }
  [Search(">=")]
  public decimal? ListPrice { get; set; }
}
