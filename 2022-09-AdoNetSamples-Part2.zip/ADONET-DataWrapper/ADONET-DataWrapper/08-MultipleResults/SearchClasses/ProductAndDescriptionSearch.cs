﻿#nullable disable

using AdoNetWrapper.MultipleResults.Common;

namespace AdoNetWrapperSamples.MultipleResults.SearchClasses;

public class ProductAndDescriptionSearch {
  [Search("=")]
  public string Culture { get; set; }
}
