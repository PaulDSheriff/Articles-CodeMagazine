﻿#nullable disable

using AdoNetWrapper.MultipleResults.Common;
using AdoNetWrapperSamples.MultipleResults.EntityClasses;
using AdoNetWrapperSamples.MultipleResults.Models;
using AdoNetWrapperSamples.MultipleResults.SearchClasses;

namespace AdoNetWrapperSamples.MultipleResults.RepositoryClasses;

public class ProductRepository : RepositoryBase {
  public ProductRepository(AdvWorksDbContext context) : base(context) {
  }

  public virtual List<Product> Search() {
    return base.Search<Product>();
  }

  public virtual List<Product> Search(ProductSearch search) {
    return base.Search<Product, ProductSearch>(search);
  }

  public virtual Product Find(int id) {
    return base.Find<Product>(id);
  }
}
