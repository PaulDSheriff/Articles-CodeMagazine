﻿#nullable disable

using AdoNetWrapperSamples.MultipleResults.EntityClasses;
using AdoNetWrapperSamples.MultipleResults.Models;

namespace AdoNetWrapperSamples.MultipleResults.ViewModelClasses;

public class ProductCustomerViewModel {
  public ProductCustomerViewModel(string connectString) {
    ConnectString = connectString;
  }

  public string ConnectString { get; set; }
  public List<Product> Products { get; set; }
  public List<Customer> Customers { get; set; }

  public void LoadProductsAndCustomers() {
    string sql = "SELECT * FROM SalesLT.Product;";
    sql += "SELECT * FROM SalesLT.Customer";

    using AdvWorksDbContext db = new(ConnectString);

    // Create Command object
    var cmd = db.CreateCommand(sql);

    // Get the Product Data
    Products = db.Database.Search<Product>(cmd);

    // Advance to next result set
    db.DataReaderObject.NextResult();

    // Clear columns to get ready for next result set
    db.Database.Columns = new();

    // Get the Customer Data
    Customers = db.Database.Search<Customer>(cmd, db.DataReaderObject);
  }
}
