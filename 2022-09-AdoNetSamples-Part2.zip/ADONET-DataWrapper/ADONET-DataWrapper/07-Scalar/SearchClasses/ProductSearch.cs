﻿#nullable disable

using AdoNetWrapper.Scalar.Common;

namespace AdoNetWrapperSamples.Scalar.SearchClasses;

public class ProductSearch {
  [Search("LIKE")]
  public string Name { get; set; }
  [Search(">=")]
  public decimal? ListPrice { get; set; }
}
