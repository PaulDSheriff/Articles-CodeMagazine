﻿#nullable disable

using AdoNetWrapper.Scalar.Common;

namespace AdoNetWrapperSamples.Scalar.SearchClasses;

public class ProductAndDescriptionSearch {
  [Search("=")]
  public string Culture { get; set; }
}
