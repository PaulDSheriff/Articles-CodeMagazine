﻿#nullable disable

using AdoNetWrapper.Scalar.Common;
using AdoNetWrapperSamples.Scalar.EntityClasses;
using AdoNetWrapperSamples.Scalar.Models;
using AdoNetWrapperSamples.Scalar.SearchClasses;

namespace AdoNetWrapperSamples.Scalar.RepositoryClasses;

public class ProductRepository : RepositoryBase {
  public ProductRepository(AdvWorksDbContext context) : base(context) {
  }

  public virtual List<Product> Search() {
    return base.Search<Product>();
  }

  public virtual List<Product> Search(ProductSearch search) {
    return base.Search<Product, ProductSearch>(search);
  }

  public virtual Product Find(int id) {
    return base.Find<Product>(id);
  }
}
