﻿#nullable disable

using AdoNetWrapperSamples.SubmitSql.EntityClasses;
using AdoNetWrapperSamples.SubmitSql.Models;

public partial class Program {
  /// <summary>
  /// Submit custom SQL
  /// </summary>
  public static void SubmitSqlSample() {
    using AdvWorksDbContext db = new(ConnectString);

    string sql = "SELECT * FROM SalesLT.Product ";
    sql += "WHERE Name LIKE @Name + '%'";
    sql += " AND ListPrice >= @ListPrice";

    // Create Command object
    var cmd = db.CreateCommand(sql);
    // Add Parameters
    cmd.Parameters.Add(
      db.CreateParameter("Name", "C"));
    cmd.Parameters.Add(
      db.CreateParameter("ListPrice", 50));

    // Call the SELECT statement
    List<Product> list =
      db.Database.Search<Product>(cmd);

    Console.WriteLine("*** Get Product Data ***");
    // Display Data
    foreach (var item in list) {
      Console.WriteLine(item.ToString());
    }
    Console.WriteLine();
    Console.WriteLine($"Total Items: {list.Count}");
    Console.WriteLine();
  }
}
