﻿#nullable disable

using AdoNetWrapper.ViewSearch.Common;
using AdoNetWrapperSamples.ViewSearch.EntityClasses;
using AdoNetWrapperSamples.ViewSearch.Models;
using AdoNetWrapperSamples.ViewSearch.SearchClasses;

namespace AdoNetWrapperSamples.ViewSearch.RepositoryClasses;

public class ProductRepository : RepositoryBase {
  public ProductRepository(AdvWorksDbContext context) : base(context) {
  }

  public virtual List<Product> Search() {
    return base.Search<Product>();
  }

  public virtual List<Product> Search(ProductSearch search) {
    return base.Search<Product, ProductSearch>(search);
  }
}
