﻿#nullable disable

using AdoNetWrapper.ViewSearch.Common;

namespace AdoNetWrapperSamples.ViewSearch.SearchClasses;

public class ProductSearch {
  [Search("LIKE")]
  public string Name { get; set; }
  [Search(">=")]
  public decimal? ListPrice { get; set; }
}
