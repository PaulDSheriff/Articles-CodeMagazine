﻿#nullable disable

using AdoNetWrapper.ViewSearch.Common;

namespace AdoNetWrapperSamples.ViewSearch.SearchClasses;

public class ProductAndDescriptionSearch {
  [Search("=")]
  public string Culture { get; set; }
}
