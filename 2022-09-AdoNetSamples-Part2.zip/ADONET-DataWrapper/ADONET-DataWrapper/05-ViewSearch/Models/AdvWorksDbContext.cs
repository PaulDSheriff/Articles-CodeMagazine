﻿#nullable disable

using AdoNetWrapper.ViewSearch.Common;
using AdoNetWrapperSamples.ViewSearch.RepositoryClasses;

namespace AdoNetWrapperSamples.ViewSearch.Models;

public partial class AdvWorksDbContext : SqlServerDatabaseContext {
  public AdvWorksDbContext(string connectString) : base(connectString) { }

  protected override void Init() {
    base.Init();

    Database = new(this);
    Products = new(this);
  }

  public RepositoryBase Database { get; set; }
  public ProductRepository Products { get; set; }
}
