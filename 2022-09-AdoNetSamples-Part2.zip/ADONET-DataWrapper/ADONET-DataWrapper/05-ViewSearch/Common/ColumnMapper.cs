﻿#nullable disable

using System.Reflection;

namespace AdoNetWrapper.ViewSearch.Common;

public class ColumnMapper {
  public string ColumnName { get; set; }
  public PropertyInfo PropertyInfo { get; set; }
  public object ParameterValue { get; set; }
  public string SearchOperator { get; set; }
}
