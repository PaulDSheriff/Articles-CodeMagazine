﻿#nullable disable

using AdoNetWrapperSamples.Refactored.EntityClasses;
using AdoNetWrapperSamples.Refactored.Models;

public partial class Program {
  /// <summary>
  /// Use a Repository and RepositoryBase class to wrap up functionality
  /// </summary>
  public static void RepositorySample() {
    using AdvWorksDbContext db = new(ConnectString);

    List<Product> list = db.Products.Search();

    Console.WriteLine("*** Product Repository Sample ***");
    // Display Data
    foreach (var item in list) {
      Console.WriteLine(item.ToString());
    }
    Console.WriteLine();
    Console.WriteLine($"Total Items: {list.Count}");
    Console.WriteLine();
    Console.WriteLine($"SQL Submitted: {db.Products.SQL}");
    Console.WriteLine();
  }
}
