﻿#nullable disable

using AdoNetWrapperSamples.MultipleResults.ViewModelClasses;

public partial class Program {
  /// <summary>
  /// Multiple Result Sets Sample
  /// </summary>
  public static void MultipleResultsSample() {
    ProductCustomerViewModel vm = new(ConnectString);

    vm.LoadProductsAndCustomers();

    // Display Products
    foreach (var item in vm.Products) {
      Console.WriteLine(item);
    }

    // Display Customers
    foreach (var item in vm.Customers) {
      Console.WriteLine(item);
    }
  }
}
