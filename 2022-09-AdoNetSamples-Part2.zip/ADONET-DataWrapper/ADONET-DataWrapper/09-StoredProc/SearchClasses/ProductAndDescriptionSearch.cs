﻿#nullable disable

using AdoNetWrapper.StoredProc.Common;

namespace AdoNetWrapperSamples.StoredProc.SearchClasses;

public class ProductAndDescriptionSearch {
  [Search("=")]
  public string Culture { get; set; }
}
