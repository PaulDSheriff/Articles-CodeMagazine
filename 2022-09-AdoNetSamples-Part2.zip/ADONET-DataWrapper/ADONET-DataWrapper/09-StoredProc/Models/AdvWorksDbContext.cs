﻿#nullable disable

using AdoNetWrapper.StoredProc.Common;
using AdoNetWrapperSamples.StoredProc.RepositoryClasses;

namespace AdoNetWrapperSamples.StoredProc.Models;

public partial class AdvWorksDbContext : SqlServerDatabaseContext {
  public AdvWorksDbContext(string connectString) : base(connectString) { }

  protected override void Init() {
    base.Init();

    Database = new(this);
    Products = new(this);
  }

  public RepositoryBase Database { get; set; }
  public ProductRepository Products { get; set; }
}
