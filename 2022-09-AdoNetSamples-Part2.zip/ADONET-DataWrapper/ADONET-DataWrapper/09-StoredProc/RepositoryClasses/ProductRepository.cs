﻿#nullable disable

using AdoNetWrapper.StoredProc.Common;
using AdoNetWrapperSamples.StoredProc.EntityClasses;
using AdoNetWrapperSamples.StoredProc.Models;
using AdoNetWrapperSamples.StoredProc.SearchClasses;

namespace AdoNetWrapperSamples.StoredProc.RepositoryClasses;

public class ProductRepository : RepositoryBase {
  public ProductRepository(AdvWorksDbContext context) : base(context) {
  }

  public virtual List<Product> Search() {
    return base.Search<Product>();
  }

  public virtual List<Product> Search(ProductSearch search) {
    return base.Search<Product, ProductSearch>(search);
  }

  public virtual Product Find(int id) {
    return base.Find<Product>(id);
  }
}
