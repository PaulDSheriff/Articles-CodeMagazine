﻿#nullable disable

using AdoNetWrapper.StoredProc.Common;

namespace AdoNetWrapperSamples.StoredProc.ParameterClasses;

public class ProductSearchParam {
  public string Name { get; set; }
  public string ProductNumber { get; set; }
  public decimal? BeginningCost { get; set; }
  public decimal? EndingCost { get; set; }
}
