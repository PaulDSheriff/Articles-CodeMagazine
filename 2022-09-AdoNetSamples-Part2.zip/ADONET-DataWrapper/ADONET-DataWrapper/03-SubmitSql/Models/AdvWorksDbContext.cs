﻿#nullable disable

using AdoNetWrapper.SubmitSql.Common;
using AdoNetWrapperSamples.SubmitSql.RepositoryClasses;

namespace AdoNetWrapperSamples.SubmitSql.Models;

public partial class AdvWorksDbContext : SqlServerDatabaseContext {
  public AdvWorksDbContext(string connectString) : base(connectString) { }

  protected override void Init() {
    base.Init();

    Database = new(this);
    Products = new(this);
  }

  public RepositoryBase Database { get; set; }
  public ProductRepository Products { get; set; }
}
