﻿#nullable disable

using AdoNetWrapper.SubmitSql.Common;
using AdoNetWrapperSamples.SubmitSql.EntityClasses;
using AdoNetWrapperSamples.SubmitSql.Models;
using AdoNetWrapperSamples.SubmitSql.SearchClasses;

namespace AdoNetWrapperSamples.SubmitSql.RepositoryClasses;

public class ProductRepository : RepositoryBase {
  public ProductRepository(AdvWorksDbContext context) : base(context) {
  }

  public virtual List<Product> Search() {
    return base.Search<Product>();
  }

  public virtual List<Product> Search(ProductSearch search) {
    return base.Search<Product, ProductSearch>(search);
  }
}
