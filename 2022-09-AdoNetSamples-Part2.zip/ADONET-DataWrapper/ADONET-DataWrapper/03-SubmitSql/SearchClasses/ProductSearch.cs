﻿#nullable disable

using AdoNetWrapper.SubmitSql.Common;

namespace AdoNetWrapperSamples.SubmitSql.SearchClasses;

public class ProductSearch {
  [Search("LIKE")]
  public string Name { get; set; }
  [Search(">=")]
  public decimal? ListPrice { get; set; }
}
