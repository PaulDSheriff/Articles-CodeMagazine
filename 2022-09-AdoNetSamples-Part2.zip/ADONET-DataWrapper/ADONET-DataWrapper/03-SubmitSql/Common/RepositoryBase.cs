﻿#nullable disable

using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Reflection;
using System.Text;

namespace AdoNetWrapper.SubmitSql.Common;

public class RepositoryBase {
  public RepositoryBase(DatabaseContext context) {
    DbContext = context;
    Init();
  }

  protected readonly DatabaseContext DbContext;

  public string SchemaName { get; set; }
  public string TableName { get; set; }
  public string SQL { get; set; }
  public List<ColumnMapper> Columns { get; set; }

  protected virtual void Init() {
    SchemaName = "dbo";
    TableName = string.Empty;
    SQL = string.Empty;
    Columns = new();
  }

  public virtual List<TEntity> Search<TEntity>() {
    // Build SQL from Entity class
    SQL = BuildSelectSql<TEntity>();
    // Create Command Object with SQL
    DbContext.CreateCommand(SQL);

    return Search<TEntity>(DbContext.CommandObject);
  }

  public virtual List<TEntity> Search<TEntity, TSearch>(TSearch search) {
    // Build SQL from Entity class
    SQL = BuildSelectSql<TEntity>();

    // Build collection of ColumnMapper objects
    // from properties in the TSearch object
    var searchColumns = BuildSearchColumnCollection<TEntity, TSearch>(search);

    if (searchColumns != null && searchColumns.Any()) {
      // Build the WHERE clause for Searching
      SQL += BuildSearchWhereClause(searchColumns);
    }

    // Create Command Object with SQL
    DbContext.CreateCommand(SQL);

    // Add any Parameters?
    if (searchColumns != null && searchColumns.Any()) {
      BuildWhereClauseParameters(DbContext.CommandObject, searchColumns);
    }

    return Search<TEntity>(DbContext.CommandObject);
  }

  public virtual List<TEntity> Search<TEntity>(IDbCommand cmd) {
    List<TEntity> ret;

    // Build Columns if needed
    if (Columns.Count == 0) {
      Columns = BuildColumnCollection<TEntity>();
    }

    // Set Command Object
    DbContext.CommandObject = cmd;

    // Get the list of entity objects
    ret = BuildEntityList<TEntity>
      (DbContext.CreateDataReader());

    return ret;
  }


  protected virtual List<ColumnMapper> BuildSearchColumnCollection<TEntity, TSearch>(TSearch search) {
    List<ColumnMapper> ret = new();
    ColumnMapper colMap;
    object value;

    // Get all the properties in <TSearch>
    PropertyInfo[] props =
      typeof(TSearch).GetProperties();

    // Loop through all properties
    foreach (PropertyInfo prop in props) {
      value = prop.GetValue(search, null);

      // Is the search property filled in?
      if (value != null) {
        // Create a column mapping object
        colMap = new() {
          ColumnName = prop.Name,
          PropertyInfo = prop,
          SearchOperator = "=",
          ParameterValue = value
        };

        // Does Property have a [Search] attribute
        SearchAttribute sa =
          prop.GetCustomAttribute<SearchAttribute>();
        if (sa != null) {
          // Set column name from [Search] attribute
          colMap.ColumnName =
            string.IsNullOrWhiteSpace(sa.ColumnName)
              ? colMap.ColumnName : sa.ColumnName;
          colMap.SearchOperator =
            sa.SearchOperator ?? "=";
        }

        // Create collection of columns
        ret.Add(colMap);
      }
    }

    return ret;
  }

  protected virtual string BuildSearchWhereClause(List<ColumnMapper> columns) {
    StringBuilder sb = new(1024);
    string and = string.Empty;

    // Create WHERE clause
    sb.Append(" WHERE");
    foreach (var item in columns) {
      sb.Append($"{and} {item.ColumnName} {item.SearchOperator} {DbContext.ParameterPrefix}{ item.ColumnName}");
      and = " AND";
    }

    return sb.ToString();
  }

  protected virtual void BuildWhereClauseParameters(IDbCommand cmd, List<ColumnMapper> whereColumns) {

    // Add parameters for each value passed in
    foreach (ColumnMapper item in whereColumns) {
      var param = DbContext.CreateParameter(item.ColumnName, item.SearchOperator == "LIKE" ? item.ParameterValue + "%" : item.ParameterValue);
      cmd.Parameters.Add(param);

      // Store parameter info
      Columns.Find(c => c.ColumnName == item.ColumnName).ParameterValue = item.ParameterValue;
    }
  }

  protected virtual string BuildSelectSql<TEntity>() {
    Type typ = typeof(TEntity);
    StringBuilder sb = new(2048);
    string comma = string.Empty;

    // Build Column Mapping Collection
    Columns = BuildColumnCollection<TEntity>();

    // Set Table and Schema properties
    SetTableAndSchemaName(typ);

    // Build the SELECT statement
    sb.Append("SELECT");
    foreach (ColumnMapper item in Columns) {
      // Add column
      sb.Append($"{comma} [{item.ColumnName}]");
      comma = ",";
    }
    // Add 'FROM schema.table'
    sb.Append($" FROM {SchemaName}.{TableName}");

    return sb.ToString();
  }

  protected virtual void SetTableAndSchemaName(Type typ) {
    // Is there is a [Table] attribute?
    TableAttribute table = typ.GetCustomAttribute<TableAttribute>();
    // Assume table name is the class name
    TableName = typ.Name;
    if (table != null) {
      // Set properties from [Table] attribute
      TableName = table.Name;
      SchemaName = table.Schema ?? SchemaName;
    }
  }

  protected virtual List<ColumnMapper> BuildColumnCollection<TEntity>() {
    List<ColumnMapper> ret = new();
    ColumnMapper colMap;

    // Get all the properties in <TEntity>
    PropertyInfo[] props = typeof(TEntity).GetProperties();

    // Loop through all properties
    foreach (PropertyInfo prop in props) {
      // Is there a [NotMapped] attribute?
      NotMappedAttribute nm = prop.GetCustomAttribute<NotMappedAttribute>();
      // Only add properties that map to a column
      if (nm == null) {
        // Create a column mapping object
        colMap = new() {
          // Set column properties
          PropertyInfo = prop,
          ColumnName = prop.Name
        };

        // Is column name in [Column] attribute?
        ColumnAttribute ca = prop.GetCustomAttribute<ColumnAttribute>();
        if (ca != null && !string.IsNullOrEmpty(ca.Name)) {
          // Set column name from [Column] attr
          colMap.ColumnName = ca.Name;
        }

        // Create collection of columns
        ret.Add(colMap);
      }
    }

    return ret;
  }

  protected virtual List<TEntity> BuildEntityList<TEntity>(IDataReader rdr) {
    List<TEntity> ret = new();

    // Loop through all rows in the data reader
    while (rdr.Read()) {
      // Create new instance of Entity
      TEntity entity = Activator.CreateInstance<TEntity>();

      // Loop through columns collection
      for (int index = 0; index < Columns.Count; index++) {
        // Get the value from the reader
        var value = rdr[Columns[index].ColumnName];

        // Assign value to the property if not null
        if (!value.Equals(DBNull.Value)) {
          Columns[index].PropertyInfo.SetValue(entity, value, null);
        }
      }

      // Add new entity to the list
      ret.Add(entity);
    }

    return ret;
  }
}
