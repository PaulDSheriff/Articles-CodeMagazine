﻿#nullable disable

using AdoNetWrapperSamples.ViewSearch.EntityClasses;
using AdoNetWrapperSamples.ViewSearch.Models;
using AdoNetWrapperSamples.ViewSearch.SearchClasses;

public partial class Program {
  /// <summary>
  /// Call View with a Search
  /// </summary>
  public static void ViewSearchSample() {
    using AdvWorksDbContext db = new(ConnectString);

    ProductAndDescriptionSearch search = new() {
      Culture = "en",
    };

    // Perform a search for specific culture
    List<ProductAndDescription> list =
      db.Database.Search<ProductAndDescription,
        ProductAndDescriptionSearch>(search);

    Console.WriteLine("*** Get Product Data ***");
    // Display Data
    foreach (var item in list) {
      Console.WriteLine(item.ToString());
    }
    Console.WriteLine();
    Console.WriteLine($"Total Items: {list.Count}");
    Console.WriteLine();
    Console.WriteLine($"SQL Submitted: {db.Database.SQL}");
  }
}
