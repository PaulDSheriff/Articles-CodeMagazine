﻿#nullable disable

using System.Reflection;

namespace AdoNetWrapper.Refactored.Common;

public class ColumnMapper {
  public string ColumnName { get; set; }
  public PropertyInfo PropertyInfo { get; set; }
}
