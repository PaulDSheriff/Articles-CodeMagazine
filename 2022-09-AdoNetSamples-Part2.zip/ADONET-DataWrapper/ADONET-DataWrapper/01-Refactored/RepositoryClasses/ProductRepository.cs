﻿#nullable disable

using AdoNetWrapper.Refactored.Common;
using AdoNetWrapperSamples.Refactored.Models;
using AdoNetWrapperSamples.Refactored.EntityClasses;

namespace AdoNetWrapperSamples.Refactored.RepositoryClasses;

public class ProductRepository : RepositoryBase {
  public ProductRepository(AdvWorksDbContext context) : base(context) {
  }

  public virtual List<Product> Search() {
    return base.Search<Product>();
  }
}
