﻿#nullable disable

using AdoNetWrapper.Refactored.Common;
using AdoNetWrapperSamples.Refactored.RepositoryClasses;

namespace AdoNetWrapperSamples.Refactored.Models;

public partial class AdvWorksDbContext : SqlServerDatabaseContext {
  public AdvWorksDbContext(string connectString) : base(connectString) { }

  protected override void Init() {
    base.Init();

    Products = new(this);
  }

  public ProductRepository Products { get; set; }
}
