﻿#nullable disable

using AdoNetWrapperSamples.Scalar.Models;

public partial class Program {
  /// <summary>
  /// Get a Scalar Value
  /// </summary>
  public static void ScalarSample() {
    using AdvWorksDbContext db = new(ConnectString);

    string sql = "SELECT COUNT(*) FROM SalesLT.Product";
    int rows = (int)db.Database.ExecuteScalar(sql);

    Console.WriteLine("*** ExecuteScalar(sql) Sample ***");
    // Display Result
    Console.WriteLine(rows);
    Console.WriteLine();
    Console.WriteLine($"SQL Submitted: {db.Database.SQL}");
    Console.WriteLine();
  }
}
