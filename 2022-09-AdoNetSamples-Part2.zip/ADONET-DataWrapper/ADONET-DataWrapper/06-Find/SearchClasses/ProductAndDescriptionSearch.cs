﻿#nullable disable

using AdoNetWrapper.Find.Common;

namespace AdoNetWrapperSamples.Find.SearchClasses;

public class ProductAndDescriptionSearch {
  [Search("=")]
  public string Culture { get; set; }
}
