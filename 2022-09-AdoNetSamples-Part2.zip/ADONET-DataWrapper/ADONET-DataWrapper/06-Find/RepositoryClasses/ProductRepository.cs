﻿#nullable disable

using AdoNetWrapper.Find.Common;
using AdoNetWrapperSamples.Find.EntityClasses;
using AdoNetWrapperSamples.Find.Models;
using AdoNetWrapperSamples.Find.SearchClasses;

namespace AdoNetWrapperSamples.Find.RepositoryClasses;

public class ProductRepository : RepositoryBase {
  public ProductRepository(AdvWorksDbContext context) : base(context) {
  }

  public virtual List<Product> Search() {
    return base.Search<Product>();
  }

  public virtual List<Product> Search(ProductSearch search) {
    return base.Search<Product, ProductSearch>(search);
  }

  public virtual Product Find(int id) {
    return base.Find<Product>(id);
  }
}
