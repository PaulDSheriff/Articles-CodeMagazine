﻿#nullable disable

using AdoNetWrapper.View.Common;
using AdoNetWrapperSamples.View.RepositoryClasses;

namespace AdoNetWrapperSamples.View.Models;

public partial class AdvWorksDbContext : SqlServerDatabaseContext {
  public AdvWorksDbContext(string connectString) : base(connectString) { }

  protected override void Init() {
    base.Init();

    Database = new(this);
    Products = new(this);
  }

  public RepositoryBase Database { get; set; }
  public ProductRepository Products { get; set; }
}
