﻿#nullable disable

using AdoNetWrapper.View.Common;
using AdoNetWrapperSamples.View.EntityClasses;
using AdoNetWrapperSamples.View.Models;
using AdoNetWrapperSamples.View.SearchClasses;

namespace AdoNetWrapperSamples.View.RepositoryClasses;

public class ProductRepository : RepositoryBase {
  public ProductRepository(AdvWorksDbContext context) : base(context) {
  }

  public virtual List<Product> Search() {
    return base.Search<Product>();
  }

  public virtual List<Product> Search(ProductSearch search) {
    return base.Search<Product, ProductSearch>(search);
  }
}
