﻿#nullable disable

using AdoNetWrapperSamples.StoredProcOutput.EntityClasses;
using AdoNetWrapperSamples.StoredProcOutput.Models;
using AdoNetWrapperSamples.StoredProcOutput.ParameterClasses;

public partial class Program {
  /// <summary>
  /// Get OUTPUT Parameter from Stored Procedure
  /// </summary>
  public static void StoredProcOutputSample() {
    using AdvWorksDbContext db = new(ConnectString);

    string sql = "SalesLT.Product_GetAllWithOutput";
    ProductGetAllParam param = new() {
      Result = ""
    };

    List<Product> list = db.Database.SearchUsingStoredProcedure<Product, ProductGetAllParam>(param, sql);

    // Display Products
    foreach (var item in list) {
      Console.WriteLine(item);
    }

    Console.WriteLine();
    Console.WriteLine($"Output Param: '{param.Result}'");
    Console.WriteLine();
    Console.WriteLine($"Total Items: {list.Count}");
    Console.WriteLine();
    Console.WriteLine($"SQL Submitted: {db.Database.SQL}");
  }
}
