﻿#nullable disable

using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

public partial class Program {

  private static string ConnectString;
  //private static string Sql = "SELECT * FROM SalesLT.Product";

  public static void Main() {
    // Setup Host
    using IHost host = Host.CreateDefaultBuilder().Build();

    // Ask the service provider for the configuration abstraction.
    IConfiguration config = host.Services.GetRequiredService<IConfiguration>();

    // Get values from the config given their key and their target type.
    ConnectString = config.GetValue<string>("ConnectionStrings:DefaultConnection");
        
    // *******************************************
    // Sample 01: Use RepositoryBase Class
    // *******************************************
    //Program.RepositorySample();

    // **************************************************
    // Sample 02: Search for Product Data
    // **************************************************
    //Program.SearchSample();

    // **************************************************
    // Sample 03: Submit SQL
    // **************************************************
    //Program.SubmitSqlSample();

    // **************************************************
    // Sample 04: Call a View
    // **************************************************
    Program.ViewSample();

    // **************************************************
    // Sample 05: Add WHERE clause to View
    // **************************************************
    //Program.ViewSearchSample();

    // **************************************************
    // Sample 06: Find by Primary Key
    // Check for [Key] attribute
    // **************************************************
    //Program.FindSample();

    // **************************************************
    // Sample 07: Execute Scalar
    // **************************************************
    //Program.ScalarSample();

    // **************************************************
    // Sample 08: Multiple Result Sets
    // **************************************************
    //Program.MultipleResultsSample();

    // **************************************************
    // Sample 09: Call a Stored Procedure
    // **************************************************
    //Program.StoredProcSample();

    // **************************************************
    // Sample 10: Get Output From Stored Procedure
    // **************************************************
    //Program.StoredProcOutputSample();
  }
}
