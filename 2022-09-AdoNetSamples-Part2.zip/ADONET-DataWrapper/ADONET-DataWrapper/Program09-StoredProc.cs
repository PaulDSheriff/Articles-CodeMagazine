﻿#nullable disable

using AdoNetWrapperSamples.StoredProc.EntityClasses;
using AdoNetWrapperSamples.StoredProc.Models;
using AdoNetWrapperSamples.StoredProc.ParameterClasses;

public partial class Program {
  /// <summary>
  /// Get Results from Stored Procedure
  /// </summary>
  public static void StoredProcSample() {
    using AdvWorksDbContext db = new(ConnectString);

    string sql = "SalesLT.Product_Search";
    //string sql = "SalesLT.Product_GetAll";
    ProductSearchParam param = new() {
      Name = "C"
    };

    List<Product> list = db.Database.SearchUsingStoredProcedure<Product, ProductSearchParam>(param, sql);
    //List<Product> list = db.Database.SearchUsingStoredProcedure<Product, Product>(null, sql);

    // Display Products
    foreach (var item in list) {
      Console.WriteLine(item);
    }

    Console.WriteLine();
    Console.WriteLine($"Total Items: {list.Count}");
    Console.WriteLine();
    Console.WriteLine($"SQL Submitted: {db.Database.SQL}");
  }
}
