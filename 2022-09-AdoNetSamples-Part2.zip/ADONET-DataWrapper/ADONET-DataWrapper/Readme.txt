﻿Simplifying ADO.NET - Part 2
============================================
01-Refactored          -> Use a RepositoryBase class to build a SQL SELECT statement using the properties of the class, check for [NotMapped] attribute to skip a property
02-Search              -> Add ProductSearch class with [Search] attributes. Added Search<TEntity, TSearch>(TSearch search) method. Added BuildSearchColumnCollection(), BuildSearchWhereClause(), and BuildWhereClauseParameters() methods
03-SubmitSql           -> Add Database property to be able submit custom SQL
04-View                -> Get data from a SQL Server view
05-View / Search       -> Add WHERE clause to view
06-Find                -> Find a single row of data by passing the values of the primary keys to find. Check for [Key] attribute in Product. Modified BuildColumnCollection to check for [Key] attribute. Added IsKeyField and ParameterValue properties to ColumnMapper class
07-Scalar              -> Get a Scalar Value
08-MultipleResultSets  -> Get multiple result sets
09-StoredProc          -> Call a Stored Procedure with and without parameters
10-StoredProcOutput    -> Call a Stored Procedure with output parameter