﻿#nullable disable

using AdoNetWrapperSamples.View.EntityClasses;
using AdoNetWrapperSamples.View.Models;

public partial class Program {
  /// <summary>
  /// Call a View
  /// </summary>
  public static void ViewSample() {
    using AdvWorksDbContext db = new(ConnectString);

    // Get all rows from view
    List<ProductAndDescription> list = db.Database.Search<ProductAndDescription>();

    Console.WriteLine("*** Get Product Data ***");
    // Display Data
    foreach (var item in list) {
      Console.WriteLine(item.ToString());
    }
    Console.WriteLine();
    Console.WriteLine($"Total Items: {list.Count}");
    Console.WriteLine();
    Console.WriteLine($"SQL Submitted: {db.Database.SQL}");
  }
}
