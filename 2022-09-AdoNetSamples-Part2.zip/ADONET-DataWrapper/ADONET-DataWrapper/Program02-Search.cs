﻿#nullable disable

using AdoNetWrapperSamples.Search.EntityClasses;
using AdoNetWrapperSamples.Search.Models;
using AdoNetWrapperSamples.Search.SearchClasses;

public partial class Program {
  /// <summary>
  /// Use a Search class to filter data
  /// </summary>
  public static void SearchSample() {
    using AdvWorksDbContext db = new(ConnectString);

    ProductSearch search = new() {
      Name = "C",
      ListPrice = 50
    };

    List<Product> list = db.Products.Search(search);

    Console.WriteLine("*** Search Sample ***");
    // Display Data
    foreach (var item in list) {
      Console.WriteLine(item.ToString());
    }
    Console.WriteLine();
    Console.WriteLine($"Total Items: {list.Count}");
    Console.WriteLine();
    Console.WriteLine($"SQL Submitted: {db.Products.SQL}");
    Console.WriteLine();
  }
}
