﻿#nullable disable

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AdoNetWrapperSamples.StoredProcOutput.EntityClasses;

[Table("Customer", Schema = "SalesLT")]
public partial class Customer {
  [Key]
  public int CustomerID { get; set; }
  public string Title { get; set; }
  public string FirstName { get; set; }
  public string MiddleName { get; set; }
  public string LastName { get; set; }
  public string CompanyName { get; set; }

  public override string ToString() {
    return $"{LastName}, {FirstName} ({CustomerID})";
  }
}
