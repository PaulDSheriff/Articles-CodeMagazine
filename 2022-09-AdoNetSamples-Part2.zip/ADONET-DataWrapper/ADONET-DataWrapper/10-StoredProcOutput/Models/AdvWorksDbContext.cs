﻿#nullable disable

using AdoNetWrapper.StoredProcOutput.Common;
using AdoNetWrapperSamples.StoredProcOutput.RepositoryClasses;

namespace AdoNetWrapperSamples.StoredProcOutput.Models;

public partial class AdvWorksDbContext : SqlServerDatabaseContext {
  public AdvWorksDbContext(string connectString) : base(connectString) { }

  protected override void Init() {
    base.Init();

    Database = new(this);
    Products = new(this);
  }

  public SqlServerRepositoryBase Database { get; set; }
  public ProductRepository Products { get; set; }
}
