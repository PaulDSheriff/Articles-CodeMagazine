﻿#nullable disable

using AdoNetWrapper.StoredProcOutput.Common;
using AdoNetWrapperSamples.StoredProcOutput.EntityClasses;
using AdoNetWrapperSamples.StoredProcOutput.Models;
using AdoNetWrapperSamples.StoredProcOutput.SearchClasses;

namespace AdoNetWrapperSamples.StoredProcOutput.RepositoryClasses;

public class ProductRepository : RepositoryBase {
  public ProductRepository(AdvWorksDbContext context) : base(context) {
  }

  public virtual List<Product> Search() {
    return base.Search<Product>();
  }

  public virtual List<Product> Search(ProductSearch search) {
    return base.Search<Product, ProductSearch>(search);
  }

  public virtual Product Find(int id) {
    return base.Find<Product>(id);
  }
}
