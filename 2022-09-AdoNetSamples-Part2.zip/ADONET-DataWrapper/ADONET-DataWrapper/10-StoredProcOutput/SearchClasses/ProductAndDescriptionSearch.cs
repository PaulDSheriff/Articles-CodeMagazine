﻿#nullable disable

using AdoNetWrapper.StoredProcOutput.Common;

namespace AdoNetWrapperSamples.StoredProcOutput.SearchClasses;

public class ProductAndDescriptionSearch {
  [Search("=")]
  public string Culture { get; set; }
}
