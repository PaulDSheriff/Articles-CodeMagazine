﻿#nullable disable

using AdoNetWrapper.Search.Common;
using AdoNetWrapperSamples.Search.EntityClasses;
using AdoNetWrapperSamples.Search.Models;
using AdoNetWrapperSamples.Search.SearchClasses;

namespace AdoNetWrapperSamples.Search.RepositoryClasses;

public class ProductRepository : RepositoryBase {
  public ProductRepository(AdvWorksDbContext context) : base(context) {
  }

  public virtual List<Product> Search() {
    return base.Search<Product>();
  }

  public virtual List<Product> Search(ProductSearch search) {
    return base.Search<Product, ProductSearch>(search);
  }
}
