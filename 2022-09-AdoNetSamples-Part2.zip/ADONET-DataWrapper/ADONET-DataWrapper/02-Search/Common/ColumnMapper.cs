﻿#nullable disable

using System.Reflection;

namespace AdoNetWrapper.Search.Common;

public class ColumnMapper {
  public string ColumnName { get; set; }
  public PropertyInfo PropertyInfo { get; set; }
  public object ParameterValue { get; set; }
  public string SearchOperator { get; set; }
}
