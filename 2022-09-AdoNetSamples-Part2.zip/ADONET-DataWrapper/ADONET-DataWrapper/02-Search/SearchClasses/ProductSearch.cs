﻿#nullable disable

using AdoNetWrapper.Search.Common;

namespace AdoNetWrapperSamples.Search.SearchClasses;

public class ProductSearch {
  [Search("LIKE")]
  public string Name { get; set; }
  [Search(">=")]
  public decimal? ListPrice { get; set; }
}
