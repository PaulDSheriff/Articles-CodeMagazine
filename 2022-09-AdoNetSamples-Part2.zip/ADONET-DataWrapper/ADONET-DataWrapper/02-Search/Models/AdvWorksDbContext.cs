﻿#nullable disable

using AdoNetWrapper.Search.Common;
using AdoNetWrapperSamples.Search.RepositoryClasses;

namespace AdoNetWrapperSamples.Search.Models;

public partial class AdvWorksDbContext : SqlServerDatabaseContext {
  public AdvWorksDbContext(string connectString) : base(connectString) { }

  protected override void Init() {
    base.Init();

    Products = new(this);
  }

  public ProductRepository Products { get; set; }
}
