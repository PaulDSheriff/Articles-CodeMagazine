﻿#nullable disable

using AdoNetWrapperSamples.EntityClasses;
using AdoNetWrapperSamples.Models;
using AdoNetWrapperSamples.ParameterClasses;
using AdoNetWrapperSamples.SearchClasses;
using AdoNetWrapperSamples.ViewModelClasses;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

// Setup Host
using IHost host = Host.CreateDefaultBuilder().Build();

// Ask service provider for configuration
IConfiguration config = host.Services.GetRequiredService<IConfiguration>();

// Get connection string
string ConnectString = config.GetValue<string>("ConnectionStrings:DefaultConnection");

using AdvWorksDbContext db = new(ConnectString);

string sql = "SalesLT.Product_GetAllWithOutput";
ProductGetAllParam param = new() {
  Result = ""
};

List<Product> list = db.Database.SearchUsingStoredProcedure<Product, ProductGetAllParam>(param, sql);

// Display Products
foreach (var item in list) {
  Console.WriteLine(item);
}

Console.WriteLine();
Console.WriteLine($"Output Param: '{param.Result}'");
Console.WriteLine();
Console.WriteLine($"Total Items: {list.Count}");
Console.WriteLine();
Console.WriteLine($"SQL Submitted: {db.Database.SQL}");