﻿using PaulsAutoParts.Common;

namespace PaulsAutoParts.EntityLayer
{
  public class AppSearchBase : SearchBase
  {
  }
}
