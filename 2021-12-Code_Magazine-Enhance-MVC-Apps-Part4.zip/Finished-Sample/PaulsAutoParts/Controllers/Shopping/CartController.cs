﻿using System;
using Microsoft.AspNetCore.Mvc;
using PaulsAutoParts.Common;
using PaulsAutoParts.EntityLayer;
using PaulsAutoParts.AppClasses;
using PaulsAutoParts.ViewModelLayer;

namespace PaulsAutoParts.Controllers
{
  public class CartController : AppController
  {
    #region Constructor
    public CartController(AppSession session,
             IRepository<Product, ProductSearch> repo,
             IRepository<VehicleType, VehicleTypeSearch> vrepo,
             IRepository<PromoCode, PromoCodeSearch> prepo) : base(session)
    {
      _repo = repo;
      _vehicleRepo = vrepo;
      _promoRepo = prepo;
    }
    #endregion

    #region Private Fields      
    private readonly IRepository<Product, ProductSearch> _repo;
    private readonly IRepository<VehicleType, VehicleTypeSearch> _vehicleRepo;
    private readonly IRepository<PromoCode, PromoCodeSearch> _promoRepo;
    #endregion

    [HttpGet]
    public IActionResult Index()
    {
      // Set Cart from Session
      ShoppingViewModel vm = new(_repo, _vehicleRepo, UserSession.Cart);

      // Set "Common" View Model Properties from Session
      base.SetViewModelFromSession(vm, UserSession);

      // Set Cart into View Model
      vm.Cart = UserSession.Cart;

      // See if the cart has expired
      if (vm.Cart.DateExpires < DateTime.Now) {
        // Expire the cart
        vm.ExpireCart(vm.Cart);

        // Set cart into session
        UserSession.Cart = vm.Cart;
      }

      return View(vm);
    }
  }
}
