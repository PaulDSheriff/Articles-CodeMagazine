﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PaulsAutoParts.AppClasses;
using PaulsAutoParts.Common;
using PaulsAutoParts.EntityLayer;
using PaulsAutoParts.ViewModelLayer;

namespace PaulsAutoParts.Controllers
{
  [ApiController]
  [Route("api/[controller]/[action]")]
  public class CartApiController : AppController
  {
    #region Constructor
    public CartApiController(AppSession session,
      IRepository<PromoCode, PromoCodeSearch> repo) : base(session)
    {
      _repo = repo;
    }
    #endregion

    #region Private Fields      
    private readonly IRepository<PromoCode, PromoCodeSearch> _repo;
    #endregion

    [HttpPost(Name = "UpdateItemQuantity")]
    public IActionResult UpdateItemQuantity([FromBody] ShoppingCartItem item)
    {
      // Set Cart from Session
      ShoppingViewModel vm = new(null, null, UserSession.Cart);

      // Set "Common" View Model Properties from Session
      base.SetViewModelFromSession(vm, UserSession);

      // Update item
      vm.UpdateQuantity(item);

      // Set updated cart back into session
      UserSession.Cart = vm.Cart;

      return StatusCode(StatusCodes.Status200OK, true);
    }

    [HttpGet("{code}", Name = "GetPromoCode")]
    public ActionResult GetPromoCode(string code)
    {
      ShoppingViewModel vm = new();
      vm.PromoCodeRepository = _repo;

      // Set promo code to apply from code passed in
      vm.PromoCodeToApply = code;

      // Set "Common" View Model Properties from Session
      base.SetViewModelFromSession(vm, UserSession);

      // Set Cart from Session
      vm.Cart = UserSession.Cart;

      // Apply Promo Code if it exists, 
      // and make sure another one has 
      // not already been applied
      vm.ApplyPromoCode();

      // Set cart into session
      UserSession.Cart = vm.Cart;

      // Return the promotional code object
      return StatusCode(StatusCodes.Status200OK,
       vm.Cart.PromotionCode);
    }
  }
}
