﻿using Microsoft.AspNetCore.Mvc;
using PaulsAutoParts.AppClasses;
using PaulsAutoParts.Common;
using PaulsAutoParts.EntityLayer;
using PaulsAutoParts.ViewModelLayer;

namespace PaulsAutoParts.ControllersApi
{
  [ApiController]
  [Route("api/[controller]/[action]")]
  public class PromoCodeApiController : AppController
  {
    #region Constructor
    public PromoCodeApiController(AppSession session,
             IRepository<PromoCode, PromoCodeSearch> repo) : base(session)
    {
      _repo = repo;
    }
    #endregion

    #region Private Fields      
    private readonly IRepository<PromoCode, PromoCodeSearch> _repo;
    #endregion

    #region DoesCodeExist Method
    [HttpGet("{code}", Name = "DoesCodeExist")]
    public JsonResult DoesCodeExist(string code)
    {
      JsonResult ret;

      PromoCodeViewModel vm = new(_repo);

      if (string.IsNullOrEmpty(code))
      {
        // Return a false value
        ret = new JsonResult(false);
      }
      else
      {
        // See if Code exists
        ret = new JsonResult(!vm.DoesCodeExist(code));
      }

      return ret;
    }
    #endregion
  }
}
