﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PaulsAutoParts.AppClasses;
using PaulsAutoParts.Common;
using PaulsAutoParts.DataLayer;
using PaulsAutoParts.EntityLayer;
using PaulsAutoParts.ViewModelLayer;

namespace PaulsAutoParts.ControllersApi
{
  [ApiController]
  [Route("api/[controller]/[action]")]
  public class VehicleTypeApiController : AppController
  {
    #region Constructor
    public VehicleTypeApiController(AppSession session,
           IRepository<VehicleType, VehicleTypeSearch> repo) : base(session)
    {
      _repo = repo;
    }
    #endregion

    #region Private Fields      
    private readonly IRepository<VehicleType, VehicleTypeSearch> _repo;
    #endregion

    #region SearchMakes Method
    [HttpGet("{make}", Name = "SearchMakes")]
    public IActionResult SearchMakes(string make)
    {
      IActionResult ret;

      VehicleTypeViewModel vm = new(_repo);

      // Return all makes found
      ret = StatusCode(StatusCodes.Status200OK,
        vm.SearchMakes(make));

      return ret;
    }
    #endregion

    #region SearchModels Method
    [HttpGet("{year}/{make}/{model}", Name = "SearchModels")]
    public IActionResult SearchModels(int year, string make, string model)
    {
      IActionResult ret;

      VehicleTypeViewModel vm = new(_repo);

      // Return all models found
      ret = StatusCode(StatusCodes.Status200OK, vm.SearchModels(year, make, model));

      return ret;
    }
    #endregion
  }
}