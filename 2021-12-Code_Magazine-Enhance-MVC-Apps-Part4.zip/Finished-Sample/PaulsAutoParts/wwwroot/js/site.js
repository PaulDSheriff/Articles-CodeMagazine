﻿'use strict';

// ************************************
// Create a Closure
// ************************************
var mainController = (function () {
  // ************************************
  // Private Variables
  // ************************************
  let searchValues = null;

  // ************************************
  // Private Functions
  // ************************************
  function disableAllClicks() {
    $("a").css("cursor", "arrow").click(false);
    $("input[type='button']").attr("disabled", "disabled");
    $("button").attr("disabled", "disabled");
  }

  function pleaseWait(ctl) {
    // Was a control passed in?
    if (ctl) {
      // Look for a data-waitmsg="message"
      // on the control clicked on
      let msg = $(ctl).data("waitmsg");
      if (msg) {
        $("#theWaitMessage").html(msg);
      }
    }

    $("#pleaseWait").removeClass("d-none");
    $("header").addClass("pleaseWaitArea");
    $("main").addClass("pleaseWaitArea");
    $("footer").addClass("pleaseWaitArea");

    disableAllClicks();
  }

  function setSearchValues(value) {
    searchValues = value;
  }

  function isSearchFilledIn() {
    return searchValues;
  }

  function setSearchArea() {
    $("#searchBody").collapse(
      isSearchFilledIn() ? "show" : "hide");
  }

  function formSubmit() {
    $("form").submit(function () {
      if ($("form").valid()) {
        pleaseWait(this);
      }
    });
  }

  function modifyItemsInCartText(isAdding) {
    // Get text from <a> tag
    let value = $("#itemsInCart").text();
    let count = 0;
    let pos = 0;

    // Find the first space in the text
    pos = value.indexOf(" ");
    // Get the total # of items
    count = parseInt(value.substring(0, pos));
    // Increment or Decrement the total # of items
    if (isAdding) {
      count++;
    }
    else {
      count--;
    }

    // Create the text with the new count
    value = count.toString() + " " + value.substring(pos);
    // Put text back into the cart
    $("#itemsInCart").text(value);
  }

  function toUSCurrency(value) {
    value = parseFloat(value);

    return value.toLocaleString('en-US', {
      style: 'currency',
      currency: 'USD',
    });
  }

  function fromUSCurrency(value) {
    return value.replace(/[^0-9\.-]+/g, "");
  }

  // ************************************
  // Public Functions
  // ************************************
  return {
    "pleaseWait": pleaseWait,
    "disableAllClicks": disableAllClicks,
    "setSearchValues": setSearchValues,
    "isSearchFilledIn": isSearchFilledIn,
    "setSearchArea": setSearchArea,
    "formSubmit": formSubmit,
    "modifyItemsInCartText": modifyItemsInCartText,
    "toUSCurrency": toUSCurrency,
    "fromUSCurrency": fromUSCurrency
  }
})();
