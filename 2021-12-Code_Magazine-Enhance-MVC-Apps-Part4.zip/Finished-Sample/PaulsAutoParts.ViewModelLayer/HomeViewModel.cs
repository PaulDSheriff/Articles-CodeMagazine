namespace PaulsAutoParts.ViewModelLayer
{
  public class HomeViewModel : AppViewModelBase
  {    
  }
}
