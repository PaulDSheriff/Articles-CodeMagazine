function getFromInput() {
  return {
    "productID": getValue("productID"),
    "name": getValue("name"),
    "productNumber": getValue("productNumber"),
    "color": getValue("color"),
    "standardCost": getValue("standardCost"),
    "listPrice": getValue("listPrice"),
    "sellStartDate": new Date(getValue("sellStartDate"))
  };
}

function setInput(product) {
  setValue("productID", product.productID);
  setValue("name", product.name);
  setValue("productNumber", product.productNumber);
  setValue("color", product.color);
  setValue("standardCost", product.standardCost);
  setValue("listPrice", product.listPrice);
  setValue("sellStartDate", product.sellStartDate);
}

function clearInput() {
  setValue("productID", "0");
  setValue("name", "");
  setValue("productNumber", "");
  setValue("color", "");
  setValue("standardCost", "0");
  setValue("listPrice", "0");
  setValue("sellStartDate", new Date().toLocaleDateString());
}

function displayList() {
  document.getElementById("list").style.display = "block";
  document.getElementById("detail").style.display = "none";
}

function displayDetail() {
  document.getElementById("list").style.display = "none";
  document.getElementById("detail").style.display = "block";
}

function buildList(vm) {
  // Get template from script
  let template = document.getElementById("dataTmpl").innerHTML;

  // Call Mustache passing in the template and the
  // object with collection of data to display
  let html = Mustache.render(template, vm);

  // Insert the rendered HTML into the DOM        
  document.getElementById("products")
    .getElementsByTagName("tbody")[0]
    .innerHTML = html;

  // Display List
  displayList();
}
