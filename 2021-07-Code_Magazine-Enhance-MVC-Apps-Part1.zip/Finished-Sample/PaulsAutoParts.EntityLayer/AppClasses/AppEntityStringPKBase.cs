using PaulsAutoParts.Common;

namespace PaulsAutoParts.EntityLayer
{
  public class AppEntityStringPKBase : EntityStringPKBase
  {
  }
}