using System.Collections.Generic;
using MVVMEntityLayer;

namespace MVVMDataLayer {
  public interface IProductRepository {
    List<Product> Get();
    Product Get(int id);
    List<Product> Search(ProductSearch entity);
    Product CreateEmpty();
    Product Add(Product entity);
    Product Update(Product entity);
    bool Delete(int id);
  }
}