﻿using System;
using System.Web.UI.WebControls;

namespace GridViewLayoutPageFilter
{
  public partial class FinalGrid : System.Web.UI.Page
  {
    protected void btnReset_Click(object sender, EventArgs e)
    {
      txtCompany.Text = string.Empty;
    }

    protected void sortFields_SelectedIndexChanged(object sender, EventArgs e)
    {
      grdCust.Sort(sortFields.SelectedValue.ToString(), SortDirection.Ascending);
    }
  }
}