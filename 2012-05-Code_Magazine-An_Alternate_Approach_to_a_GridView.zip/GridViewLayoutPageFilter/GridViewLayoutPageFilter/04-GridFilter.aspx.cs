﻿using System;
using System.Web.UI.WebControls;

namespace GridViewLayoutPageFilter
{
  public partial class GridFilter : System.Web.UI.Page
  {
    protected void btnReset_Click(object sender, EventArgs e)
    {
      txtCompany.Text = string.Empty;
    }
  }
}