﻿using System;
using System.Windows;

// Needed for Observable Collection
using System.Collections.ObjectModel;

// Needed to work with Isolated Storage
using System.IO.IsolatedStorage;

// These are needed for working with LINQ to XML
using System.Linq;
using System.Xml.Linq;

// This library contains the extension methods
using Common.Library;

namespace ProductLibrary
{
  public class ProductViewModel : CommonBase
  {
    #region Constructor
    public ProductViewModel()
    {
      LoadProducts();
    }
    #endregion

    #region Products Property
    private ObservableCollection<Product> _Products = new ObservableCollection<Product>();

    public ObservableCollection<Product> Products
    {
      get { return _Products; }
      set
      {
        _Products = value;
        RaisePropertyChanged("Products");
      }
    }
    #endregion

    #region CurrentProduct Property
    private Product _CurrentProduct = new Product();

    public Product CurrentProduct
    {
      get { return _CurrentProduct; }
      set
      {
        _CurrentProduct = value;
        RaisePropertyChanged("CurrentProduct");
      }
    }
    #endregion

    #region Message Property
    private string _Message = string.Empty;

    public string Message
    {
      get { return _Message; }
      set
      {
        _Message = value;
        RaisePropertyChanged("Message");
      }
    }
    #endregion

    #region Private Properties
    private XElement _ProductXml = null;
    private bool _IsAddMode = false;
    #endregion

    #region GetProductXml Method
    private void GetProductXml()
    {
      if (IsInDesignMode())
        // Get Data from Xml Folder
        _ProductXml = XElement.Load(Product.XmlFile);
      else
      {
        if (_ProductXml == null)
        {
          if (IsolatedStorageSettings.ApplicationSettings.Contains(Product.KeyName))
            _ProductXml = XElement.Parse(IsolatedStorageSettings.ApplicationSettings[Product.KeyName].ToString());
          else
          {
            _ProductXml = XElement.Load(Product.XmlFile);

            // Store XML into Isolated Storage
            IsolatedStorageSettings.ApplicationSettings[Product.KeyName] = _ProductXml.ToString();
          }
        }
      }
    }
    #endregion

    #region SaveProductXml Method
    private void SaveProductXml()
    {
      // Create/Modify data in Isolated Storage
      IsolatedStorageSettings.ApplicationSettings[Product.KeyName] = _ProductXml.ToString();
    }
    #endregion

    #region LoadProducts Method
    public void LoadProducts()
    {
      GetProductXml();

      if (_ProductXml != null)
      {
        // Get all Products
        var products = from elem in _ProductXml.Descendants("Product")
                       orderby elem.Attribute("ProductName").Value
                       select new Product
                       {
                         ProductId = elem.Attribute("ProductId").GetAsInteger(),
                         ProductName = elem.Attribute("ProductName").GetAsString(),
                         IntroductionDate = elem.Attribute("IntroductionDate").GetAsDateTime(),
                         Price = elem.Attribute("Price").GetAsDecimal()
                       };

        Products = new ObservableCollection<Product>(products);
      }
    }
    #endregion

    #region NewProduct Method
    public void NewProduct()
    {
      CurrentProduct = new Product();

      CurrentProduct.IntroductionDate = DateTime.Now;
      CurrentProduct.Price = 0;

      _IsAddMode = true;
    }
    #endregion

    #region Save Method
    public void Save()
    {
      if (_IsAddMode)
        Insert();
      else
        Update();
    }
    #endregion

    #region Insert Method
    private void Insert()
    {
      // Create new Product ID
      CurrentProduct.ProductId = GetNextId();

      // Create new Product element
      var newElem = new XElement(Product.TopElement,
        new XAttribute("ProductId", CurrentProduct.ProductId),
        new XAttribute("ProductName", CurrentProduct.ProductName),
        new XAttribute("IntroductionDate", CurrentProduct.IntroductionDate),
        new XAttribute("Price", CurrentProduct.Price));

      // Add to element collection
      _ProductXml.Add(newElem);

      // Save the XML to Isolated Storage
      SaveProductXml();

      // Add to Products Collection
      Products.Add(CurrentProduct);

      // Reset IsAddMode Flag
      _IsAddMode = false;
    }
    #endregion

    #region Update Method
    private void Update()
    {
      if (CurrentProduct != null)
      {
        // Find the product element
        var old = (from elem in _ProductXml.Descendants(Product.TopElement)
                   where elem.Attribute("ProductId").Value == CurrentProduct.ProductId.ToString()
                   select elem).SingleOrDefault();

        if (old != null)
        {
          // Update the data
          old.Attribute("ProductName").Value = CurrentProduct.ProductName;
          old.Attribute("IntroductionDate").Value = CurrentProduct.IntroductionDate.ToString();
          old.Attribute("Price").Value = CurrentProduct.Price.ToString();

          // Save the XML to Isolated Storage
          SaveProductXml();
        }
      }
    }
    #endregion

    #region Delete Method
    public void Delete()
    {
      if (CurrentProduct != null)
      {
        // Find the product element
        var old = (from elem in _ProductXml.Descendants(Product.TopElement)
                   where elem.Attribute("ProductId").Value == CurrentProduct.ProductId.ToString()
                   select elem).SingleOrDefault();

        if (old != null)
        {
          // Delete the element
          old.Remove();

          // Save the XML to Isolated Storage
          SaveProductXml();

          // Delete from Products Collection
          Products.Remove(CurrentProduct);
        }
      }
    }
    #endregion

    #region GetNextId Method
    public int GetNextId()
    {
      GetProductXml();

      // Get The last id
      var maxId = (from elem in _ProductXml.Descendants(Product.TopElement)
                   select Convert.ToInt32(elem.Attribute("ProductId").Value)).Max();

      return maxId + 1;
    }
    #endregion

    #region IsInDesignMode Method
    private bool IsInDesignMode()
    {
      return (Application.Current.Host.Source == null);
    }
    #endregion
  }
}
