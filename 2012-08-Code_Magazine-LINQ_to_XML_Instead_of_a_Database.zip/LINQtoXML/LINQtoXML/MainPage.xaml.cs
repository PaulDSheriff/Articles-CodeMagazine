﻿using System.Windows;
using System.Windows.Controls;

namespace LINQtoXML
{
  public partial class MainPage : UserControl
  {
    public MainPage()
    {
      InitializeComponent();
    }

    private void btnRead_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new ucRead());
    }

    private void btnReadGetValue_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new ucReadGetValue());
    }

    private void btnWhere_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new ucReadWhere());
    }

    private void btnGetFromServer_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new ucGetXmlFromServer());
    }

    private void btnAED_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new ucAddEditDelete());
    }

    private void btnProducts_Click(object sender, RoutedEventArgs e)
    {
      contentArea.Children.Clear();
      contentArea.Children.Add(new ucProduct());
    }
  }
}
