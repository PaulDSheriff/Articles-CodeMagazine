﻿using System;
using System.Windows;
using System.Windows.Controls;

// Needed to work with Isolated Storage
using System.IO.IsolatedStorage;

// These are needed for working with LINQ to XML
using System.Linq;
using System.Xml.Linq;

// This library contains the Product class
using ProductLibrary;

// This library contains the extension methods
using Common.Library;

// Service Reference
using LINQtoXML.ProductServiceRefrence;

namespace LINQtoXML
{
  public partial class ucGetXmlFromServer : UserControl
  {
    public ucGetXmlFromServer()
    {
      InitializeComponent();
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      if (IsolatedStorageSettings.ApplicationSettings.Contains(Product.KeyName))
      {
        btnReadXml.IsEnabled = true;
      }
    }

    #region Get XML From Server Methods
    private void btnGetXml_Click(object sender, RoutedEventArgs e)
    {
      GetXmlFromServer();
    }

    ProductServiceClient _Client = null;

    private void GetXmlFromServer()
    {
      _Client = new ProductServiceClient();

      _Client.GetProductXmlCompleted += new EventHandler<GetProductXmlCompletedEventArgs>(_Client_GetProductXmlCompleted);
      _Client.GetProductXmlAsync();
    }

    void _Client_GetProductXmlCompleted(object sender, GetProductXmlCompletedEventArgs e)
    {
      // Store the XML data into Isolated Storage
      IsolatedStorageSettings.ApplicationSettings[Product.KeyName] = e.Result;
      btnReadXml.IsEnabled = true;

      _Client.CloseAsync();
    }
    #endregion

    #region Read XML From Isoloated Storage Methods
    private void btnReadXml_Click(object sender, RoutedEventArgs e)
    {
      ReadProductXml();
    }

    private void ReadProductXml()
    {
      XElement xElem = null;

      if (IsolatedStorageSettings.ApplicationSettings.Contains(Product.KeyName))
      {
        xElem = XElement.Parse(IsolatedStorageSettings.ApplicationSettings[Product.KeyName].ToString());

        // The following query uses extension methods to ensure a good value is returned
        var products = from elem in xElem.Descendants("Product")
                       orderby elem.Attribute("ProductName").Value
                       select new Product
                       {
                         ProductId = elem.Attribute("ProductId").GetAsInteger(),
                         ProductName = elem.Attribute("ProductName").GetAsString(),
                         IntroductionDate = elem.Attribute("IntroductionDate").GetAsDateTime(),
                         Price = elem.Attribute("Price").GetAsDecimal()
                       };

        lstData.DataContext = products;
      }
    }
    #endregion
  }
}
