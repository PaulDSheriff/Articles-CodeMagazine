﻿using System;
using System.Windows;
using System.Windows.Controls;

// Needed to work with Isolated Storage
using System.IO.IsolatedStorage;

// These are needed for working with LINQ to XML
using System.Linq;
using System.Xml.Linq;

// This library contains the Product class
using ProductLibrary;

namespace LINQtoXML
{
  public partial class ucAddEditDelete : UserControl
  {
    public ucAddEditDelete()
    {
      InitializeComponent();
    }

    #region GetProductXml Method
    private XElement GetProductXml()
    {
      XElement xElem = null;

      if (IsolatedStorageSettings.ApplicationSettings.Contains(Product.KeyName))
        xElem = XElement.Parse(IsolatedStorageSettings.ApplicationSettings[Product.KeyName].ToString());
      else
      {
        xElem = XElement.Load(Product.XmlFile);

        // Store XML into Isolated Storage
        IsolatedStorageSettings.ApplicationSettings[Product.KeyName] = xElem.ToString();
      }

      return xElem;
    }
    #endregion

    #region SaveProductXml Method
    private void SaveProductXml(XElement xElem)
    {
      // Create/Modify data in Isolated Storage
      IsolatedStorageSettings.ApplicationSettings[Product.KeyName] = xElem.ToString();
    }
    #endregion

    #region Insert Methods
    private void btnInsert_Click(object sender, RoutedEventArgs e)
    {
      Product entity = new Product();

      entity.ProductId = 50;
      entity.ProductName = "My new Product";
      entity.IntroductionDate = DateTime.Now;
      entity.Price = 30;

      Insert(entity);
    }

    public void Insert(Product entity)
    {
      XElement xElem = GetProductXml();

      // Create new Product element
      var newElem = new XElement(Product.TopElement,
        new XAttribute("ProductId", entity.ProductId),
        new XAttribute("ProductName", entity.ProductName),
        new XAttribute("IntroductionDate", entity.IntroductionDate),
        new XAttribute("Price", entity.Price));

      // Add to element collection
      xElem.Add(newElem);

      // Save XML File
      SaveProductXml(xElem);

      tbMessage.Text = "Product Inserted";
    }
    #endregion

    #region Update Methods
    private void btnUpdate_Click(object sender, RoutedEventArgs e)
    {
      Product entity = new Product();

      entity.ProductId = 50;
      entity.ProductName = "Changed My New Product";
      entity.IntroductionDate = DateTime.Now;
      entity.Price = 35;

      Update(entity);
    }

    private void Update(Product entity)
    {
      XElement xElem = GetProductXml();
      XElement old = null;

      // Find the product element
      old = (from elem in xElem.Descendants(Product.TopElement)
             where elem.Attribute("ProductId").Value == entity.ProductId.ToString()
             select elem).SingleOrDefault();

      if (old != null)
      {
        // Update the data
        old.Attribute("ProductName").Value = entity.ProductName;
        old.Attribute("IntroductionDate").Value = entity.IntroductionDate.ToString();
        old.Attribute("Price").Value = entity.Price.ToString();

        // Save XML File
        SaveProductXml(xElem);

        tbMessage.Text = "Product Updated";
      }
      else
      {
        tbMessage.Text = "Product 50 NOT Found";
      }
    }
    #endregion

    #region Delete Methods
    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      Product entity = new Product();

      entity.ProductId = 50;

      Delete(entity);
    }

    private void Delete(Product entity)
    {
      XElement xElem = GetProductXml();
      XElement old = null;

      // Find the product element
      old = (from elem in xElem.Descendants(Product.TopElement)
             where elem.Attribute("ProductId").Value == entity.ProductId.ToString()
             select elem).SingleOrDefault();

      if (old != null)
      {
        // Delete the element
        old.Remove();

        // Save XML File
        SaveProductXml(xElem);

        tbMessage.Text = "Product Deleted";
      }
      else
      {
        tbMessage.Text = "Product 50 NOT Found";
      }
    }
    #endregion
  }
}
