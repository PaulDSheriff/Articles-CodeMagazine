﻿using System.Windows;
using System.Windows.Controls;

// This library contains the Product class
using ProductLibrary;

namespace LINQtoXML
{
  public partial class ucProduct : UserControl
  {
    private ProductViewModel _ViewModel;

    public ucProduct()
    {
      InitializeComponent();

      _ViewModel = (ProductViewModel)this.Resources["viewModel"];
    }

    private void btnNew_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.NewProduct();
    }

    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.Save();
    }

    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      _ViewModel.Delete();
    }
  }
}
