﻿using System;
using System.Windows;
using System.Windows.Controls;

// These are needed for working with LINQ to XML
using System.Linq;
using System.Xml.Linq;

// This library contains the Product class
using ProductLibrary;

namespace LINQtoXML
{
  public partial class ucRead : UserControl
  {
    public ucRead()
    {
      InitializeComponent();
    }

    private void UserControl_Loaded(object sender, RoutedEventArgs e)
    {
      LoadProducts();
    }

    private void LoadProducts()
    {
      XElement xElem = null;

      try
      {
        xElem = XElement.Load(Product.XmlFile);

        // The following will NOT work if you have missing attributes
        var products = from elem in xElem.Descendants("Product")
                       orderby elem.Attribute("ProductName").Value
                       select new Product
                       {
                         ProductId = Convert.ToInt32(elem.Attribute("ProductId").Value),
                         ProductName = Convert.ToString(elem.Attribute("ProductName").Value),
                         IntroductionDate = Convert.ToDateTime(elem.Attribute("IntroductionDate").Value),
                         Price = Convert.ToDecimal(elem.Attribute("Price").Value)
                       };

        lstData.DataContext = products;
      }
      catch (Exception ex)
      {
        MessageBox.Show(ex.Message);
      }
    }
  }
}
