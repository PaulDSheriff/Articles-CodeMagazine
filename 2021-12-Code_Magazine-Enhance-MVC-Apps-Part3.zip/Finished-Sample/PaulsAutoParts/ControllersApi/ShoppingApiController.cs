﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PaulsAutoParts.AppClasses;
using PaulsAutoParts.Common;
using PaulsAutoParts.EntityLayer;
using PaulsAutoParts.ViewModelLayer;

namespace PaulsAutoParts.ControllersApi
{
  [ApiController]
  [Route("api/[controller]/[action]")]
  public class ShoppingApiController : AppController
  {
    #region Constructor
    public ShoppingApiController(AppSession session,
             IRepository<Product, ProductSearch> repo,
             IRepository<VehicleType, VehicleTypeSearch> vrepo) : base(session)
    {
      _repo = repo;
      _vehicleRepo = vrepo;
    }
    #endregion

    #region Private Fields
    private readonly IRepository<Product, ProductSearch> _repo;
    private readonly IRepository<VehicleType, VehicleTypeSearch> _vehicleRepo;
    #endregion

    #region AddToCart Method
    [HttpPost(Name = "AddToCart")]
    public IActionResult AddToCart([FromBody] int id)
    {
      // Set Cart from Session
      ShoppingViewModel vm = new(_repo, _vehicleRepo, UserSession.Cart);

      // Set "Common" View Model Properties from Session
      base.SetViewModelFromSession(vm, UserSession);

      // Add item to cart
      vm.AddToCart(id, UserSession.CustomerId.Value);

      // Set cart into session
      UserSession.Cart = vm.Cart;

      return StatusCode(StatusCodes.Status200OK, true);
    }
    #endregion

    #region RemoveFromCart Method
    [HttpDelete("{id}", Name = "RemoveFromCart")]
    public IActionResult RemoveFromCart(int id)
    {
      // Set Cart from Session
      ShoppingViewModel vm = new(_repo, _vehicleRepo, UserSession.Cart);

      // Set "Common" View Model Properties from Session
      base.SetViewModelFromSession(vm, UserSession);

      // Remove item to cart
      vm.RemoveFromCart(vm.Cart, id, UserSession.CustomerId.Value);

      // Set cart into session
      UserSession.Cart = vm.Cart;

      return StatusCode(StatusCodes.Status200OK, true);
    }
    #endregion

    #region GetMakes Method
    [HttpGet("{year}", Name = "GetMakes")]
    public IActionResult GetMakes(int year)
    {
      IActionResult ret;

      // Create view model
      ShoppingViewModel vm = new(_repo,
        _vehicleRepo, UserSession.Cart);

      // Get vehicle makes for the year
      vm.GetMakes(year);

      // Return all Makes
      ret = StatusCode(StatusCodes.Status200OK,
        vm.Makes);

      return ret;
    }
    #endregion

    #region GetModels Method
    [HttpGet("{year}/{make}", Name = "GetModels")]
    public IActionResult GetModels(int year, string make)
    {
      IActionResult ret;

      // Create view model
      ShoppingViewModel vm = new(_repo,
        _vehicleRepo, UserSession.Cart);

      // Get vehicle models for the year/make
      vm.GetModels(year, make);

      // Return all Models
      ret = StatusCode(StatusCodes.Status200OK,
        vm.Models);

      return ret;
    }
    #endregion

    #region SearchCategories Method
    [HttpGet("{searchValue}", Name = "SearchCategories")]
    public IActionResult SearchCategories(string searchValue)
    {
      IActionResult ret;

      ShoppingViewModel vm = new(_repo,
        _vehicleRepo, UserSession.Cart);

      if (string.IsNullOrEmpty(searchValue)) {
        // Get all product categories
        vm.GetCategories();

        // Return all categories
        ret = StatusCode(StatusCodes.Status200OK,
          vm.Categories);
      }
      else {
        // Search for categories
        ret = StatusCode(StatusCodes.Status200OK,
          vm.SearchCategories(searchValue));
      }

      return ret;
    }
    #endregion
  }
}
