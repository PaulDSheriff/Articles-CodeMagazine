﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

using Common.Library;

namespace AEDViewModel
{
  [Serializable()]
  public class ShirtViewModel
  {
    #region Constructor
    public ShirtViewModel()
    {
      NormalMode();
      Init();
    }
    #endregion

    #region Public Properties
    public bool IsAddMode { get; set; }
    public bool IsAddVisible { get; set; }
    public bool IsSaveVisible { get; set; }
    public bool IsCancelVisible { get; set; }
    public bool IsEditVisible { get; set; }
    public bool IsExceptionVisible { get; set; }
    public bool IsValidationVisible { get; set; }

    public string MessageToDisplay { get; set; }
    public List<ValidationMessage> ValidationMessages = new List<ValidationMessage>();

    public int ShirtId { get; set; }
    public string ShirtName { get; set; }
    public int ColorId { get; set; }
    public int SizeId { get; set; }

    public DataTable Shirts { get; set; }
    public DataTable Colors { get; set; }
    public DataTable Sizes { get; set; }
    #endregion

    #region Init Method
    public void Init()
    {
      IsExceptionVisible = false;
      IsValidationVisible = false;

      MessageToDisplay = string.Empty;
      ValidationMessages.Clear();

      ShirtId = -1;
      ShirtName = string.Empty;
      ColorId = -1;
      SizeId = -1;
    }
    #endregion

    #region LoadAll Method
    public void LoadAll()
    {
      LoadShirts();
      LoadColors();
      LoadSizes();
    }
    #endregion

    #region LoadShirts Method
    public void LoadShirts()
    {
      DataTable dt = null;

      try
      {
        dt = DataLayer.GetDataTable("SELECT * FROM vwShirts",
          AppSettings.ConnectString);

        Shirts = dt;

        NormalMode();
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }
    }
    #endregion

    #region DisplayAShirt Method
    public void DisplayAShirt(int id)
    {
      string sql;
      SqlCommand cmd;
      DataTable dt = null;

      ShirtId = id;
      sql = "SELECT * FROM Shirts WHERE ShirtId = @ShirtId";
      try
      {
        cmd = new SqlCommand(sql);
        cmd.Parameters.Add(new SqlParameter("@ShirtId", id));
        cmd.Connection = new SqlConnection(AppSettings.ConnectString);

        dt = DataLayer.GetDataTable(cmd);
        if (dt.Rows.Count > 0)
        {
          ShirtName = dt.Rows[0]["ShirtName"].ToString();
          ColorId = Convert.ToInt32(dt.Rows[0]["ColorId"]);
          SizeId = Convert.ToInt32(dt.Rows[0]["SizeId"]);
        }

        IsAddMode = false;
        EditMode();
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }
    }
    #endregion

    #region LoadColors Method
    public void LoadColors()
    {
      DataTable dt = null;

      try
      {
        dt = DataLayer.GetDataTable("SELECT * FROM ShirtColors",
          AppSettings.ConnectString);

        Colors = dt;
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }
    }
    #endregion

    #region LoadSizes Method
    public void LoadSizes()
    {
      DataTable dt = null;

      try
      {
        dt = DataLayer.GetDataTable("SELECT * FROM ShirtSizes",
          AppSettings.ConnectString);

        Sizes = dt;
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }
    }
    #endregion

    #region DeleteAShirt Method
    public bool DeleteAShirt(int id)
    {
      bool ret = false;
      string sql;
      SqlCommand cmd;
      int rows = 0;

      sql = "DELETE FROM Shirts WHERE ShirtId = @ShirtId";
      try
      {
        cmd = new SqlCommand(sql);
        cmd.Parameters.Add(new SqlParameter("@ShirtId", id));
        cmd.Connection = new SqlConnection(AppSettings.ConnectString);

        rows = DataLayer.ExecuteSQL(cmd);

        if (rows == 1)
          ret = true;

        if(ret)
          // Redisplay all Shirts
          LoadShirts();
        else
          DisplayMessages("Can't find Shirt to Delete");
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }

      return ret;
    }
    #endregion

    #region SetAddMode Method
    public void SetAddMode()
    {
      IsAddMode = true;
      ShirtName = string.Empty;
    
      EditMode();
    }
    #endregion

    #region Save Method
    public void Save()
    {
      bool ret = false;

      if (DataValidate())
      {
        if (IsAddMode)
        {
          ret = InsertData();
        }
        else
        {
          ret = UpdateData();
        }
      }

      if (ret)
        NormalMode();
    }
    #endregion

    #region Cancel Method
    public void Cancel()
    {
      NormalMode();
    }
    #endregion

    #region DataValidate Method
    private bool DataValidate()
    {
      bool ret = false;

      ValidationMessages.Clear();

      if (string.IsNullOrEmpty(ShirtName))
        ValidationMessages.Add(new ValidationMessage("Shirt Name must be filled in."));
      if (ColorId == -1)
        ValidationMessages.Add(new ValidationMessage("Shirt Color must be selected."));
      if (SizeId == -1)
        ValidationMessages.Add(new ValidationMessage("Shirt Size must be selected."));

      ret = (ValidationMessages.Count == 0);

      if (!ret)
      {
        IsValidationVisible = true;
      }

      return ret;
    }
    #endregion

    #region InsertData Method
    private bool InsertData()
    {
      bool ret = false;
      string sql;
      SqlCommand cmd;
      int rows = 0;

      sql = "INSERT INTO Shirts(ShirtName, SizeId, ColorId) ";
      sql += " VALUES(@ShirtName, @SizeId, @ColorId) ";

      try
      {
        cmd = new SqlCommand(sql);
        cmd.Connection = new SqlConnection(AppSettings.ConnectString);
        cmd.Parameters.Add(new SqlParameter("@ShirtName", ShirtName));
        cmd.Parameters.Add(new SqlParameter("@SizeId", Convert.ToInt32(SizeId)));
        cmd.Parameters.Add(new SqlParameter("@ColorId", Convert.ToInt32(ColorId)));

        rows = DataLayer.ExecuteSQL(cmd);

        ret = (rows == 1);

        // Reload All Shirts
        if (ret)
          LoadShirts();
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }

      return ret;
    }
    #endregion

    #region UpdateData Method
    private bool UpdateData()
    {
      bool ret = false;
      string sql;
      SqlCommand cmd;
      int rows = 0;

      sql = "UPDATE Shirts SET ";
      sql += " ShirtName = @ShirtName, ";
      sql += " SizeId = @SizeId, ";
      sql += " ColorId = @ColorId ";
      sql += " WHERE ShirtId = @ShirtId ";

      try
      {
        cmd = new SqlCommand(sql);
        cmd.Connection = new SqlConnection(AppSettings.ConnectString);
        cmd.Parameters.Add(new SqlParameter("@ShirtName", ShirtName));
        cmd.Parameters.Add(new SqlParameter("@SizeId", SizeId));
        cmd.Parameters.Add(new SqlParameter("@ColorId", ColorId));
        cmd.Parameters.Add(new SqlParameter("@ShirtId", ShirtId));

        rows = DataLayer.ExecuteSQL(cmd);

        ret = (rows == 1);

        // Reload All Shirts
        if (ret)
          LoadShirts();
        else
          DisplayMessages("Can't Find Shirt Id: " + ShirtId.ToString() + " to update it."); 
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }

      return ret;
    }
    #endregion

    #region UI State Modes
    private void EditMode()
    {
      IsEditVisible = true;
      IsAddVisible = false;
      IsSaveVisible = true;
      IsCancelVisible = true;
    }

    private void NormalMode()
    {
      IsEditVisible = false;
      IsAddVisible = true;
      IsSaveVisible = false;
      IsCancelVisible = false;
      IsValidationVisible = false;
      ValidationMessages.Clear();
    }
    #endregion

    #region DisplayMessages
    private void DisplayMessages(string msg)
    {
      IsExceptionVisible = true;
      MessageToDisplay = msg;
    }
    #endregion
  }
}