﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AEDViewModel
{
  public partial class Default : System.Web.UI.Page
  {
    #region ViewModel Property & GetViewModel Method
    private ShirtViewModel _ViewModel = null;

    private ShirtViewModel GetViewModel()
    {
      if (ViewState["ShirtViewModel"] == null)
      {
        _ViewModel = new ShirtViewModel();
        ViewState["ShirtViewModel"] = _ViewModel;
      }

      _ViewModel = (ShirtViewModel)ViewState["ShirtViewModel"];

      return _ViewModel;
    }
    #endregion

    #region Page_Load Event Procedure
    protected void Page_Load(object sender, EventArgs e)
    {
      // Always create/restore the view model 
      // so it is available in all methods of this class
      _ViewModel = GetViewModel();

      if (!Page.IsPostBack)
      {
        // Load all shirts, colors and sizes
        _ViewModel.LoadAll();
        // Do the Binding for shirts, colors and sizes
        LoadShirts();
        LoadColors();
        LoadSizes();
      }

      // Update the UI
      SetUIState();
    }
    #endregion

    #region SetUIState Method
    // This method will set the state of this form using the View Model properties
    private void SetUIState()
    {
      pnlExceptions.Visible = _ViewModel.IsExceptionVisible;
      lblExceptions.Text = _ViewModel.MessageToDisplay;
      pnlValidation.Visible = _ViewModel.IsValidationVisible;
      lstValidation.DataSource = _ViewModel.ValidationMessages;
      lstValidation.DataBind();

      btnAdd.Visible = _ViewModel.IsAddVisible;
      btnCancel.Visible = _ViewModel.IsCancelVisible;
      btnSave.Visible = _ViewModel.IsSaveVisible;
      pnlEdit.Visible = _ViewModel.IsEditVisible;
    }
    #endregion

    #region LoadShirts Method
    private void LoadShirts()
    {
      grdShirts.DataSource = _ViewModel.Shirts;
      grdShirts.DataBind();
    }
    #endregion

    #region DisplayAShirt Method
    private void DisplayAShirt(int id)
    {
      _ViewModel.DisplayAShirt(id);

      txtShirtName.Text = _ViewModel.ShirtName;
      ddlColors.SelectedValue = _ViewModel.ColorId.ToString();
      ddlSizes.SelectedValue = _ViewModel.SizeId.ToString();

      SetUIState();
    }
    #endregion

    #region LoadColors Method
    private void LoadColors()
    {
      ddlColors.DataTextField = "ColorName";
      ddlColors.DataValueField = "ColorId";
      ddlColors.DataSource = _ViewModel.Colors;
      ddlColors.DataBind();
    }
    #endregion

    #region LoadSizes Method
    private void LoadSizes()
    {
      ddlSizes.DataTextField = "SizeName";
      ddlSizes.DataValueField = "SizeId";
      ddlSizes.DataSource = _ViewModel.Sizes;
      ddlSizes.DataBind();
    }
    #endregion

    #region Delete Method
    private void Delete(int id)
    {
      _ViewModel.DeleteAShirt(id);

      LoadShirts();

      SetUIState();
    }
    #endregion

    #region grdShirts_RowCommand Event Procedure
    protected void grdShirts_RowCommand(object sender, GridViewCommandEventArgs e)
    {
      int id = Convert.ToInt32(e.CommandArgument);

      switch (e.CommandName.ToLower())
      {
        case "select":   // Edit
          DisplayAShirt(id);
          break;

        case "delete":
          Delete(id);
          break;
      }
    }
    #endregion

    #region btnAdd_Click Event Procedure
    protected void btnAdd_Click(object sender, EventArgs e)
    {
      _ViewModel.SetAddMode();

      // Reset any UI elements
      txtShirtName.Text = _ViewModel.ShirtName;

      SetUIState();
    }
    #endregion

    #region btnSave_Click Event Procedure
    protected void btnSave_Click(object sender, EventArgs e)
    {
      _ViewModel.ShirtName = txtShirtName.Text;
      _ViewModel.ColorId = Convert.ToInt32(ddlColors.SelectedValue);
      _ViewModel.SizeId = Convert.ToInt32(ddlSizes.SelectedValue);

      _ViewModel.Save();

      if (!_ViewModel.IsValidationVisible)
        // Rebind grid if necessary
        LoadShirts();

      SetUIState();
    }
    #endregion

    #region btnCancel_Click Event Procedure
    protected void btnCancel_Click(object sender, EventArgs e)
    {
      _ViewModel.Cancel();

      SetUIState();
    }
    #endregion

    #region Unused Events
    protected void grdShirts_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
    }

    protected void grdShirts_RowEditing(object sender, GridViewEditEventArgs e)
    {
    }
    #endregion
  }
}