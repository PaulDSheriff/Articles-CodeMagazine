﻿using System.Windows;

namespace WPFViewModel
{
  public partial class App : Application
  {
  }
}
