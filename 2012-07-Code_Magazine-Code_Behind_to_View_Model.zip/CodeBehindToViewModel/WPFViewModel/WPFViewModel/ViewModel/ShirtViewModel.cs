﻿using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;

using Common.Library;

namespace WPFViewModel
{
  public class ShirtViewModel : CommonBase
  {
    #region Constructor
    public ShirtViewModel()
    {
      NormalMode();
      Init();
    }
    #endregion

    #region Private Variables
    private bool _IsAddMode = false;
    private bool _IsAddVisible = true;
    private bool _IsDeleteVisible = true;
    private bool _IsSaveVisible = false;
    private bool _IsCancelVisible = false;
    private bool _IsValidationVisible = false;
    private bool _IsListEnabled = true;

    private ObservableCollection<ValidationMessage> _Messages = new ObservableCollection<ValidationMessage>();

    private int _SelectedIndex = -1;
    private int _ShirtId = 0;
    private int _ColorId = 0;
    private int _SizeId = 0;
    private string _ShirtName = string.Empty;

    private DataTable _Shirts;
    private DataTable _Colors;
    private DataTable _Sizes;
    #endregion

    #region Public Properties
    public bool IsAddMode
    {
      get { return _IsAddMode; }
      set
      {
        if (_IsAddMode != value)
        {
          _IsAddMode = value;
          RaisePropertyChanged("IsAddMode");
        }
      }
    }

    public bool IsAddVisible
    {
      get { return _IsAddVisible; }
      set
      {
        if (_IsAddVisible != value)
        {
          _IsAddVisible = value;
          RaisePropertyChanged("IsAddVisible");
        }
      }
    }

    public bool IsDeleteVisible
    {
      get { return _IsDeleteVisible; }
      set
      {
        if (_IsDeleteVisible != value)
        {
          _IsDeleteVisible = value;
          RaisePropertyChanged("IsDeleteVisible");
        }
      }
    }

    public bool IsSaveVisible
    {
      get { return _IsSaveVisible; }
      set
      {
        if (_IsSaveVisible != value)
        {
          _IsSaveVisible = value;
          RaisePropertyChanged("IsSaveVisible");
        }
      }
    }

    public bool IsCancelVisible
    {
      get { return _IsCancelVisible; }
      set
      {
        if (_IsCancelVisible != value)
        {
          _IsCancelVisible = value;
          RaisePropertyChanged("IsCancelVisible");
        }
      }
    }

    public bool IsValidationVisible
    {
      get { return _IsValidationVisible; }
      set
      {
        if (_IsValidationVisible != value)
        {
          _IsValidationVisible = value;
          RaisePropertyChanged("IsValidationVisible");
        }
      }
    }

    public bool IsListEnabled
    {
      get { return _IsListEnabled; }
      set
      {
        if (_IsListEnabled != value)
        {
          _IsListEnabled = value;
          RaisePropertyChanged("IsListEnabled");
        }
      }
    }

    public ObservableCollection<ValidationMessage> Messages
    {
      get { return _Messages; }
      set
      {
        if (_Messages != value)
        {
          _Messages = value;
          RaisePropertyChanged("Messages");
        }
      }
    }

    public string ShirtName
    {
      get { return _ShirtName; }
      set
      {
        if (_ShirtName != value)
        {
          _ShirtName = value;
          RaisePropertyChanged("ShirtName");
        }
      }
    }

public int SelectedIndex
{
  get { return _SelectedIndex; }
  set
  {
    if (_SelectedIndex != value)
    {
      _SelectedIndex = value;
      DisplayAShirt();
      RaisePropertyChanged("SelectedIndex");
    }
  }
}

    public int ShirtId
    {
      get { return _ShirtId; }
      set
      {
        if (_ShirtId != value)
        {
          _ShirtId = value;
          RaisePropertyChanged("ShirtId");
        }
      }
    }

    public int ColorId
    {
      get { return _ColorId; }
      set
      {
        if (_ColorId != value)
        {
          _ColorId = value;
          RaisePropertyChanged("ColorId");
        }
      }
    }

    public int SizeId
    {
      get { return _SizeId; }
      set
      {
        if (_SizeId != value)
        {
          _SizeId = value;
          RaisePropertyChanged("SizeId");
        }
      }
    }

    public DataTable Shirts
    {
      get { return _Shirts; }
      set
      {
        if (_Shirts != value)
        {
          _Shirts = value;
          SelectedIndex = 0;
          RaisePropertyChanged("Shirts");
        }
      }
    }

    public DataTable Colors
    {
      get { return _Colors; }
      set
      {
        if (_Colors != value)
        {
          _Colors = value;
          RaisePropertyChanged("Colors");
        }
      }
    }

    public DataTable Sizes
    {
      get { return _Sizes; }
      set
      {
        if (_Sizes != value)
        {
          _Sizes = value;
          RaisePropertyChanged("Sizes");
        }
      }
    }
    #endregion

    #region Init Method
    public void Init()
    {
      IsValidationVisible = false;
      IsListEnabled = true;

      Messages.Clear();

      ShirtId = -1;
      ShirtName = string.Empty;
      ColorId = -1;
      SizeId = -1;
    }
    #endregion

    #region LoadAll
    public void LoadAll()
    {
      LoadShirts();
      LoadColors();
      LoadSizes();
    }
    #endregion

    #region LoadShirts Method
    public void LoadShirts()
    {
      DataTable dt = null;

      try
      {
        dt = DataLayer.GetDataTable("SELECT * FROM vwShirts",
          AppSettings.ConnectString);

        Shirts = dt;

        NormalMode();
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }
    }
    #endregion

    #region DisplayAShirt Method
    /// <summary>
    /// This method is called from the SelectedIndex property set.
    /// </summary>
    public void DisplayAShirt()
    {
      string sql;
      SqlCommand cmd;
      DataTable dt = null;

      if (SelectedIndex != -1)
      {
        // Get Index from Shirts Collection
        ShirtId = Convert.ToInt32(Shirts.Rows[SelectedIndex]["ShirtId"]);

        sql = "SELECT * FROM Shirts WHERE ShirtId = @ShirtId";
        try
        {
          cmd = new SqlCommand(sql);
          cmd.Parameters.Add(new SqlParameter("@ShirtId", ShirtId));
          cmd.Connection = new SqlConnection(AppSettings.ConnectString);

          dt = DataLayer.GetDataTable(cmd);
          if (dt.Rows.Count > 0)
          {
            ShirtName = dt.Rows[0]["ShirtName"].ToString();
            ColorId = Convert.ToInt32(dt.Rows[0]["ColorId"]);
            SizeId = Convert.ToInt32(dt.Rows[0]["SizeId"]);
          }
        }
        catch (Exception ex)
        {
          DisplayMessages(ex.Message);
        }
      }
    }
    #endregion

    #region LoadColors Method
    public void LoadColors()
    {
      DataTable dt = null;

      try
      {
        dt = DataLayer.GetDataTable("SELECT * FROM ShirtColors",
          AppSettings.ConnectString);

        Colors = dt;
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }
    }
    #endregion

    #region LoadSizes Method
    public void LoadSizes()
    {
      DataTable dt = null;

      try
      {
        dt = DataLayer.GetDataTable("SELECT * FROM ShirtSizes",
          AppSettings.ConnectString);

        Sizes = dt;
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }
    }
    #endregion

    #region DeleteAShirt Method
    public bool DeleteAShirt()
    {
      bool ret = false;
      string sql;
      SqlCommand cmd;
      int rows = 0;

      sql = "DELETE FROM Shirts WHERE ShirtId = @ShirtId";
      try
      {
        cmd = new SqlCommand(sql);
        cmd.Parameters.Add(new SqlParameter("@ShirtId", ShirtId));
        cmd.Connection = new SqlConnection(AppSettings.ConnectString);

        rows = DataLayer.ExecuteSQL(cmd);

        if (rows == 1)
          ret = true;

        if (ret)
          // Redisplay all Shirts
          LoadShirts();
        else
          DisplayMessages("Can't find Shirt to Delete");
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }

      return ret;
    }
    #endregion

    #region SetAddMode Method
    public void SetAddMode()
    {
      IsAddMode = true;
      ShirtName = string.Empty;

      EditMode();
    }
    #endregion

    #region Save Method
    public void Save()
    {
      bool success = false;

      if (IsAddMode)
      {
        success = InsertData();
      }
      else
      {
        success = UpdateData();
      }

      if (success)
        NormalMode();
    }
    #endregion

    #region Cancel Method
    public void Cancel()
    {
      DisplayAShirt();

      NormalMode();
    }
    #endregion

    #region DataValidate Method
    private bool DataValidate()
    {
      bool ret = false;

      Messages.Clear();

      if (string.IsNullOrEmpty(ShirtName))
        Messages.Add(new ValidationMessage("Shirt Name must be filled in."));
      if (ColorId == -1)
        Messages.Add(new ValidationMessage("Shirt Color must be selected."));
      if (SizeId == -1)
        Messages.Add(new ValidationMessage("Shirt Size must be selected."));

      ret = (Messages.Count == 0);

      if (!ret)
      {
        IsValidationVisible = true;
      }

      return ret;
    }
    #endregion

    #region InsertData Method
    private bool InsertData()
    {
      bool ret = false;
      string sql;
      SqlCommand cmd;
      int rows = 0;

      sql = "INSERT INTO Shirts(ShirtName, SizeId, ColorId) ";
      sql += " VALUES(@ShirtName, @SizeId, @ColorId) ";

      try
      {
        cmd = new SqlCommand(sql);
        cmd.Connection = new SqlConnection(AppSettings.ConnectString);
        cmd.Parameters.Add(new SqlParameter("@ShirtName", ShirtName));
        cmd.Parameters.Add(new SqlParameter("@SizeId", Convert.ToInt32(SizeId)));
        cmd.Parameters.Add(new SqlParameter("@ColorId", Convert.ToInt32(ColorId)));

        rows = DataLayer.ExecuteSQL(cmd);

        ret = (rows == 1);

        // Reload All Shirts
        if (ret)
        {
          IsAddMode = false;
          LoadShirts();
        }
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }

      return ret;
    }
    #endregion

    #region UpdateData Method
    private bool UpdateData()
    {
      bool ret = false;
      string sql;
      SqlCommand cmd;
      int rows = 0;

      sql = "UPDATE Shirts SET ";
      sql += " ShirtName = @ShirtName, ";
      sql += " SizeId = @SizeId, ";
      sql += " ColorId = @ColorId ";
      sql += " WHERE ShirtId = @ShirtId ";

      try
      {
        cmd = new SqlCommand(sql);
        cmd.Connection = new SqlConnection(AppSettings.ConnectString);
        cmd.Parameters.Add(new SqlParameter("@ShirtName", ShirtName));
        cmd.Parameters.Add(new SqlParameter("@SizeId", SizeId));
        cmd.Parameters.Add(new SqlParameter("@ColorId", ColorId));
        cmd.Parameters.Add(new SqlParameter("@ShirtId", ShirtId));

        rows = DataLayer.ExecuteSQL(cmd);

        ret = (rows == 1);

        // Reload All Shirts
        if (ret)
          LoadShirts();
        else
          DisplayMessages("Can't Find Shirt Id: " + ShirtId.ToString() + " to update it.");
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }

      return ret;
    }
    #endregion

    #region UI State Modes
    public void EditMode()
    {
      IsAddVisible = false;
      IsDeleteVisible = false;
      IsSaveVisible = true;
      IsCancelVisible = true;
      IsListEnabled = false;
    }

    private void NormalMode()
    {
      IsAddVisible = true;
      IsDeleteVisible = true;
      IsSaveVisible = false;
      IsCancelVisible = false;
      IsValidationVisible = false;
      IsListEnabled = true;
      Messages.Clear();
    }
    #endregion

    #region DisplayMessages
    private void DisplayMessages(string msg)
    {
      IsValidationVisible = true;
      Messages.Add(new ValidationMessage(msg));
    }
    #endregion
  }
}