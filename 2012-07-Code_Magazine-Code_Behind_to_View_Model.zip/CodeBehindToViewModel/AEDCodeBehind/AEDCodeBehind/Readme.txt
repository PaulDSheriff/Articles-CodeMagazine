﻿To run this sample you will need to create a database
You will then need to run the ShirtsColorsSizes.sql in this database
Open the Web.Config file and modify the connection string to point to your server and database
