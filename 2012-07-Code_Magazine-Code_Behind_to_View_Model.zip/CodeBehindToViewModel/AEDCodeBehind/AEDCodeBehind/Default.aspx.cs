﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

using Common.Library;

namespace AEDCodeBehind
{
  public partial class Default : System.Web.UI.Page
  {
    #region IsAddMode Property
    private bool IsAddMode
    {
      get { return Convert.ToBoolean(ViewState["IsAddMode"]); }
      set { ViewState["IsAddMode"] = value; }
    }
    #endregion

    #region ShirtId Property
    private int ShirtId
    {
      get { return Convert.ToInt32(ViewState["ShirtId"]); }
      set { ViewState["ShirtId"] = value; }
    }
    #endregion

    #region Page_Load Event Procedure
    protected void Page_Load(object sender, EventArgs e)
    {
      if (!Page.IsPostBack)
      {
        LoadShirts();
        LoadColors();
        LoadSizes();
      }
      else
      {
        pnlExceptions.Visible = false;
      }
    }
    #endregion

    #region LoadShirts Method
    private void LoadShirts()
    {
      DataTable dt = null;

      try
      {
        dt = DataLayer.GetDataTable("SELECT * FROM vwShirts",
          AppSettings.ConnectString);

        grdShirts.DataSource = dt;
        grdShirts.DataBind();
        
        NormalMode();
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }
    }
    #endregion

    #region DisplayAShirt Method
    private void DisplayAShirt(int id)
    {
      string sql;
      SqlCommand cmd;
      DataTable dt = null;

      // Store Primary Key for Later
      ShirtId = id;
      sql = "SELECT * FROM Shirts WHERE ShirtId = @ShirtId";
      try
      {
        cmd = new SqlCommand(sql);
        cmd.Parameters.Add(new SqlParameter("@ShirtId", id));
        cmd.Connection = new SqlConnection(AppSettings.ConnectString);

        dt = DataLayer.GetDataTable(cmd);
        if (dt.Rows.Count > 0)
        {
          txtShirtName.Text = dt.Rows[0]["ShirtName"].ToString();
          ddlColors.SelectedValue = dt.Rows[0]["ColorId"].ToString();
          ddlSizes.SelectedValue = dt.Rows[0]["SizeId"].ToString();
        }

        IsAddMode = false;
        EditMode();
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }
    }
    #endregion

    #region LoadColors Method
    private void LoadColors()
    {
      DataTable dt = null;

      try
      {
        dt = DataLayer.GetDataTable("SELECT * FROM ShirtColors",
          AppSettings.ConnectString);

        ddlColors.DataTextField = "ColorName";
        ddlColors.DataValueField = "ColorId";
        ddlColors.DataSource = dt;
        ddlColors.DataBind();
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }
    }
    #endregion

    #region LoadSizes Method
    private void LoadSizes()
    {
      DataTable dt = null;

      try
      {
        dt = DataLayer.GetDataTable("SELECT * FROM ShirtSizes",
          AppSettings.ConnectString);

        ddlSizes.DataTextField = "SizeName";
        ddlSizes.DataValueField = "SizeId";
        ddlSizes.DataSource = dt;
        ddlSizes.DataBind();
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }
    }
    #endregion

    #region DeleteAShirt Method
    private bool DeleteAShirt(int id)
    {
      bool ret = false;
      string sql;
      SqlCommand cmd;
      int rows = 0;

      sql = "DELETE FROM Shirts WHERE ShirtId = @ShirtId";
      try
      {
        cmd = new SqlCommand(sql);
        cmd.Parameters.Add(new SqlParameter("@ShirtId", id));
        cmd.Connection = new SqlConnection(AppSettings.ConnectString);

        rows = DataLayer.ExecuteSQL(cmd);
        if (rows == 1)
          ret = true;

        if (ret)
          // Redisplay all Shirts
          LoadShirts();
        else
          DisplayMessages("Can't find Shirt to Delete");
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }

      return ret;
    }
    #endregion

    #region grdShirts_RowCommand Event Procedure
    protected void grdShirts_RowCommand(object sender, GridViewCommandEventArgs e)
    {
      switch (e.CommandName.ToLower())
      {
        case "select":   // Edit
          DisplayAShirt(Convert.ToInt32(e.CommandArgument));
          break;

        case "delete":
          DeleteAShirt(Convert.ToInt32(e.CommandArgument));
          break;
      }
    }
    #endregion

    #region btnAdd_Click Event Procedure
    protected void btnAdd_Click(object sender, EventArgs e)
    {
      IsAddMode = true;

      txtShirtName.Text = string.Empty;

      EditMode();
    }
    #endregion

    #region btnSave_Click Event Procedure
    protected void btnSave_Click(object sender, EventArgs e)
    {
      bool ret = false;

      if (DataValidate())
      {
        if (IsAddMode)
        {
          ret = InsertData();
        }
        else
        {
          ret = UpdateData();
        }
      }

      if (ret)
        NormalMode();
    }
    #endregion

    #region btnCancel_Click Event Procedure
    protected void btnCancel_Click(object sender, EventArgs e)
    {
      NormalMode();
    }
    #endregion

    #region DataValidate Method
    private bool DataValidate()
    {
      bool ret = false;
      List<ValidationMessage> msgs = new List<ValidationMessage>();

      lstValidation.DataSource = msgs;

      if (string.IsNullOrEmpty(txtShirtName.Text))
        msgs.Add(new ValidationMessage("Shirt Name must be filled in."));
      if(ddlColors.SelectedIndex == -1)
        msgs.Add(new ValidationMessage("Shirt Color must be selected."));
      if (ddlSizes.SelectedIndex == -1)
        msgs.Add(new ValidationMessage("Shirt Size must be selected."));
      
      ret = (msgs.Count == 0);

      if (!ret)
      {
        pnlValidation.Visible = true;       
        lstValidation.DataSource = msgs;
      }
      lstValidation.DataBind();

      return ret;
    }
    #endregion

    #region InsertData Method
    private bool InsertData()
    {
      bool ret = false;
      string sql;
      SqlCommand cmd;
      int rows = 0;

      sql = "INSERT INTO Shirts(ShirtName, SizeId, ColorId) ";
      sql += " VALUES(@ShirtName, @SizeId, @ColorId) ";

      try
      {
        cmd = new SqlCommand(sql);
        cmd.Connection = new SqlConnection(AppSettings.ConnectString);
        cmd.Parameters.Add(new SqlParameter("@ShirtName", txtShirtName.Text));
        cmd.Parameters.Add(new SqlParameter("@SizeId", Convert.ToInt32(ddlSizes.SelectedValue)));
        cmd.Parameters.Add(new SqlParameter("@ColorId", Convert.ToInt32(ddlColors.SelectedValue)));

        rows = DataLayer.ExecuteSQL(cmd);

        ret = (rows == 1);

        // Reload All Shirts
        if (ret)
          LoadShirts();
      }
      catch (Exception ex) 
      {
        DisplayMessages(ex.Message);
      }

      return ret;
    }
    #endregion

    #region UpdateData Method
    private bool UpdateData()
    {
       bool ret = false;
      string sql;
      SqlCommand cmd;
      int rows = 0;

      sql = "UPDATE Shirts SET ";
      sql += " ShirtName = @ShirtName, ";
      sql += " SizeId = @SizeId, ";
      sql += " ColorId = @ColorId ";
      sql += " WHERE ShirtId = @ShirtId ";

      try
      {
        cmd = new SqlCommand(sql);
        cmd.Connection = new SqlConnection(AppSettings.ConnectString);
        cmd.Parameters.Add(new SqlParameter("@ShirtName", txtShirtName.Text));
        cmd.Parameters.Add(new SqlParameter("@SizeId", Convert.ToInt32(ddlSizes.SelectedValue)));
        cmd.Parameters.Add(new SqlParameter("@ColorId", Convert.ToInt32(ddlColors.SelectedValue)));
        cmd.Parameters.Add(new SqlParameter("@ShirtId", ShirtId));

        rows = DataLayer.ExecuteSQL(cmd);

        ret = (rows == 1);

        // Reload All Shirts
        if (ret)
          LoadShirts();
        else
          DisplayMessages("Can't Find Shirt Id: " + ShirtId.ToString() + " to update it."); 
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }

      return ret;
    }
    #endregion

    #region UI State Modes
    private void EditMode()
    {
      pnlEdit.Visible = true;
      btnAdd.Visible = false;
      btnSave.Visible = true;
      btnCancel.Visible = true;
    }

    private void NormalMode()
    {
      pnlEdit.Visible = false;
      btnAdd.Visible = true;
      btnSave.Visible = false;
      btnCancel.Visible = false;
      pnlValidation.Visible = false;
    }
    #endregion

    #region DisplayMessages
    private void DisplayMessages(string msg)
    {
      pnlExceptions.Visible = true;
      lblExceptions.Text = msg;
    }
    #endregion

    #region Unused Events
    protected void grdShirts_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
    }

    protected void grdShirts_RowEditing(object sender, GridViewEditEventArgs e)
    {
    }
    #endregion
  }
}