﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;

using Common.Library;

namespace WPFCodeBehind
{
  public partial class MainWindow : Window
  {
    #region Constructor
    public MainWindow()
    {
      InitializeComponent();
    }
    #endregion

    #region Private Properties
    private bool IsAddMode;
    private int ShirtId;
    #endregion

    #region Window_Loaded Event Procedure
    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      LoadShirts();
      LoadColors();
      LoadSizes();
    }
    #endregion

    #region lstData_SelectionChanged Event Procedure
    private void lstData_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      ListView vw = (ListView)sender;

      DisplayAShirt(Convert.ToInt32(((DataRowView)vw.Items[vw.SelectedIndex])["ShirtId"]));
    }
    #endregion

    #region LoadShirts Method
    private void LoadShirts()
    {
      DataTable dt = null;

      try
      {
        dt = DataLayer.GetDataTable("SELECT * FROM vwShirts",
          AppSettings.ConnectString);

        lstData.View = WPFCommon.CreateGridViewColumns(dt);
        lstData.DataContext = dt;

        NormalMode();
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }
    }
    #endregion

    #region DisplayAShirt Method
    private void DisplayAShirt(int id)
    {
      string sql;
      SqlCommand cmd;
      DataTable dt = null;

      // Store Primary Key for Later
      ShirtId = id;
      sql = "SELECT * FROM Shirts WHERE ShirtId = @ShirtId";
      try
      {
        cmd = new SqlCommand(sql);
        cmd.Parameters.Add(new SqlParameter("@ShirtId", id));
        cmd.Connection = new SqlConnection(AppSettings.ConnectString);

        dt = DataLayer.GetDataTable(cmd);
        if (dt.Rows.Count > 0)
        {
          txtShirtName.Text = dt.Rows[0]["ShirtName"].ToString();
          cboColors.SelectedValue = dt.Rows[0]["ColorId"].ToString();
          cboSizes.SelectedValue = dt.Rows[0]["SizeId"].ToString();
        }
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }
    }
    #endregion

    #region LoadColors Method
    private void LoadColors()
    {
      DataTable dt = null;

      try
      {
        dt = DataLayer.GetDataTable("SELECT * FROM ShirtColors",
          AppSettings.ConnectString);

        cboColors.DataContext = dt;
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }
    }
    #endregion

    #region LoadSizes Method
    private void LoadSizes()
    {
      DataTable dt = null;

      try
      {
        dt = DataLayer.GetDataTable("SELECT * FROM ShirtSizes",
          AppSettings.ConnectString);

        cboSizes.DataContext = dt;
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }
    }
    #endregion

    #region DeleteAShirt Method
    private bool DeleteAShirt(int id)
    {
      bool ret = false;
      string sql;
      SqlCommand cmd;
      int rows = 0;

      sql = "DELETE FROM Shirts WHERE ShirtId = @ShirtId";
      try
      {
        cmd = new SqlCommand(sql);
        cmd.Parameters.Add(new SqlParameter("@ShirtId", id));
        cmd.Connection = new SqlConnection(AppSettings.ConnectString);

        rows = DataLayer.ExecuteSQL(cmd);
        if (rows == 1)
          ret = true;

        if (ret)
          // Redisplay all Shirts
          LoadShirts();
        else
          DisplayMessages("Can't find Shirt to Delete");
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }

      return ret;
    }
    #endregion

    #region DataValidate Method
    private bool DataValidate()
    {
      bool ret = false;
      List<ValidationMessage> msgs = new List<ValidationMessage>();

      lstMessages.Visibility = Visibility.Collapsed;
      lstMessages.DataContext = new List<ValidationMessage>();

      if (string.IsNullOrEmpty(txtShirtName.Text))
        msgs.Add(new ValidationMessage("Shirt Name must be filled in."));
      if (cboColors.SelectedIndex == -1)
        msgs.Add(new ValidationMessage("Shirt Color must be selected."));
      if (cboSizes.SelectedIndex == -1)
        msgs.Add(new ValidationMessage("Shirt Size must be selected."));

      ret = (msgs.Count == 0);

      if (!ret)
      {
        lstMessages.Visibility = Visibility.Visible;
        lstMessages.DataContext = msgs;
      }

      return ret;
    }
    #endregion

    #region InsertData Method
    private bool InsertData()
    {
      bool ret = false;
      string sql;
      SqlCommand cmd;
      int rows = 0;

      sql = "INSERT INTO Shirts(ShirtName, SizeId, ColorId) ";
      sql += " VALUES(@ShirtName, @SizeId, @ColorId) ";

      try
      {
        cmd = new SqlCommand(sql);
        cmd.Connection = new SqlConnection(AppSettings.ConnectString);
        cmd.Parameters.Add(new SqlParameter("@ShirtName", txtShirtName.Text));
        cmd.Parameters.Add(new SqlParameter("@SizeId", Convert.ToInt32(cboSizes.SelectedValue)));
        cmd.Parameters.Add(new SqlParameter("@ColorId", Convert.ToInt32(cboColors.SelectedValue)));

        rows = DataLayer.ExecuteSQL(cmd);

        ret = (rows == 1);

        // Reload All Shirts
        if (ret)
          LoadShirts();
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }

      return ret;
    }
    #endregion

    #region UpdateData Method
    private bool UpdateData()
    {
      bool ret = false;
      string sql;
      SqlCommand cmd;
      int rows = 0;

      sql = "UPDATE Shirts SET ";
      sql += " ShirtName = @ShirtName, ";
      sql += " SizeId = @SizeId, ";
      sql += " ColorId = @ColorId ";
      sql += " WHERE ShirtId = @ShirtId ";

      try
      {
        cmd = new SqlCommand(sql);
        cmd.Connection = new SqlConnection(AppSettings.ConnectString);
        cmd.Parameters.Add(new SqlParameter("@ShirtName", txtShirtName.Text));
        cmd.Parameters.Add(new SqlParameter("@SizeId", Convert.ToInt32(cboSizes.SelectedValue)));
        cmd.Parameters.Add(new SqlParameter("@ColorId", Convert.ToInt32(cboColors.SelectedValue)));
        cmd.Parameters.Add(new SqlParameter("@ShirtId", ShirtId));

        rows = DataLayer.ExecuteSQL(cmd);

        ret = (rows == 1);

        // Reload All Shirts
        if (ret)
          LoadShirts();
        else
          DisplayMessages("Can't Find Shirt Id: " + ShirtId.ToString() + " to update it.");
      }
      catch (Exception ex)
      {
        DisplayMessages(ex.Message);
      }

      return ret;
    }
    #endregion

    #region UI State Modes
    private void EditMode()
    {
      btnAdd.Visibility = Visibility.Collapsed;
      btnDelete.Visibility = Visibility.Collapsed;
      btnSave.Visibility = Visibility.Visible;
      btnCancel.Visibility = Visibility.Visible;
      lstData.IsEnabled = false;
    }

    private void NormalMode()
    {
      btnAdd.Visibility = Visibility.Visible;
      btnDelete.Visibility = Visibility.Visible;
      btnSave.Visibility = Visibility.Collapsed;
      btnCancel.Visibility = Visibility.Collapsed;
      lstData.IsEnabled = true;

      lstMessages.Visibility = Visibility.Collapsed;
      lstMessages.DataContext = new List<ValidationMessage>();
    }
    #endregion

    #region DisplayMessages
    private void DisplayMessages(string msg)
    {
      lstMessages.Visibility = Visibility.Visible;
      lstMessages.DataContext = new ValidationMessage(msg);
    }
    #endregion

    #region btnAdd_Click Event Procedure
    private void btnAdd_Click(object sender, RoutedEventArgs e)
    {
      IsAddMode = true;

      txtShirtName.Text = string.Empty;

      EditMode();
    }
    #endregion

    #region btnSave_Click Event Procedure
    private void btnSave_Click(object sender, RoutedEventArgs e)
    {
      bool success = false;

      if (DataValidate())
      {
        if (IsAddMode)
        {
          success = InsertData();
        }
        else
        {
          success = UpdateData();
        }
      }

      if (success)
        NormalMode();
    }
    #endregion

    #region btnCancel_Click Event Procedure
    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      IsAddMode = false;

      DisplayAShirt(ShirtId);

      NormalMode();
    }
    #endregion

    #region btnDelete_Click Event Procedure
    private void btnDelete_Click(object sender, RoutedEventArgs e)
    {
      if (MessageBox.Show("Delete this Shirt?", "Delete?", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
        DeleteAShirt(ShirtId);
    }
    #endregion

    #region TextChanged Event Procedure
    private void TextChanged(object sender, TextChangedEventArgs e)
    {
      // Only Change Mode if Element has Keyboard Focus
      if (((UIElement)sender).IsKeyboardFocused)
        EditMode();
    }
    #endregion

    #region SelectionChanged Event Procedure
    private void SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
      if (((UIElement)sender).IsKeyboardFocused || ((UIElement)sender).IsMouseDirectlyOver)
        EditMode();
    }
    #endregion
  }
}
