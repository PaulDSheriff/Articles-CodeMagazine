﻿using System;

using System.Web.Mvc;

namespace AlternativeTable.Controllers
{
  public class ProductController : AppBaseController
  {
    public ActionResult Index()
    {
      ProductViewModel vm = new ProductViewModel();

      vm.LoadProducts();

      return View(vm);
    }

    public ActionResult IndexTwoColumn()
    {
      ProductViewModel vm = new ProductViewModel();

      vm.LoadProducts();

      return View(vm);
    }

    public ActionResult IndexBootstrap()
    {
      ProductViewModel vm = new ProductViewModel();

      vm.LoadProducts();

      return View(vm);
    }

    public ActionResult IndexSwitching()
    {
      ProductViewModel vm = new ProductViewModel();

      vm.IsMobileDevice = IsMobileDevice();
      vm.LoadProducts();

      return View(vm);
    }
  }
}