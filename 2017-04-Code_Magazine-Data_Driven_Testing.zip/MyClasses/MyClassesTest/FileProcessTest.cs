﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using MyClasses;
using System;

namespace MyClassesTest
{
  [TestClass]
  public class FileProcessTest
  {
    /// <summary>
    /// Get/Set the TestContext. 
    /// This property is set automatically from the unit testing framework.
    /// </summary>
    private TestContext _TestInstance;
    public TestContext TestContext
    {
      get { return _TestInstance; }
      set { _TestInstance = value; }
    }

    /// <summary>
    /// This method tests the FileExists() method using a table called tests.FileProcessTest
    /// </summary>
    [TestMethod()]
    [DataSource("Sandbox")]
    public void FileExistsTestFromDB() {
      FileProcess fp = new FileProcess();
      string fileName;
      bool returnValue;
      bool causesException;
      bool fromCall;

      // Get values from data row
      fileName = TestContext.DataRow["FileName"].ToString();
      returnValue = Convert.ToBoolean(TestContext.DataRow["ReturnValue"]);
      causesException = Convert.ToBoolean(TestContext.DataRow["CausesException"]);

      // Check assertion
      try {
        fromCall = fp.FileExists(fileName);
        Assert.AreEqual(returnValue, fromCall,
          "File Name: " + fileName +
          " has failed it's existence test in test: FileExistsTestFromDB()");
      }
      catch (AssertFailedException ex) {
        // Rethrow assertion
        throw ex;
      }
      catch (Exception) {
        // See if method was expected to throw an exception
        Assert.IsTrue(causesException);
      }
    }

    [TestMethod]
    public void FileExistsTestTrue() {
      FileProcess fp = new FileProcess();
      bool fromCall;

      fromCall = fp.FileExists(@"C:\Windows\Regedit.exe");
      Assert.AreEqual(true, fromCall);
    }

    [TestMethod]
    public void FileExistsTestFalse() {
      FileProcess fp = new FileProcess();
      bool fromCall;

      fromCall = fp.FileExists(@"D:\NotExists.txt");
      Assert.AreEqual(false, fromCall);
    }

    [TestMethod]
    public void FileExistsTestNull() {
      FileProcess fp = new FileProcess();
      bool fromCall;

      try {
        fromCall = fp.FileExists("");
      }
      catch (ArgumentNullException) {
        Assert.Fail();
      }
    }

    [TestMethod]
    [ExpectedException(typeof(ArgumentNullException))]
    public void FileExistsTestNullWithAttribute() {
      FileProcess fp = new FileProcess();
      bool fromCall;

      fromCall = fp.FileExists("");
    }
  }
}
