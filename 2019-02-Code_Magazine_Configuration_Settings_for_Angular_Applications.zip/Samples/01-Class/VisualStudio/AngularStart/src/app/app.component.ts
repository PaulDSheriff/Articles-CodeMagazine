import { Component } from '@angular/core';

@Component({
  selector: "product-app",
  templateUrl: "app/app.component.html"
})
export class AppComponent {
  pageTitle: string = "Settings Sample";
}
