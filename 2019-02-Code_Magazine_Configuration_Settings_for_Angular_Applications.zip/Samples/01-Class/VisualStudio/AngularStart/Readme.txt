﻿Modify the product.service.ts to use Observable
  getProducts(): Observable<Product[]> {
    return Observable.of<Product[]>(PRODUCTS_MOCK);
  }

Modify product-list.components.ts
	 getProducts(): void {
    this.productService.getProducts()
      .subscribe(products => this.products = products);
  }