﻿This project retrieves settings from a Web API call
The settings are then stored into local storage
From then on, the settings are read from local storage
The user can revert back to the defaults by deleting the key in local storage
  This causes the app to re-read the settings from the Web API call


Changes from last sample
------------------------
Modified constant STORAGE_LOCATION 
Modified handleError() method