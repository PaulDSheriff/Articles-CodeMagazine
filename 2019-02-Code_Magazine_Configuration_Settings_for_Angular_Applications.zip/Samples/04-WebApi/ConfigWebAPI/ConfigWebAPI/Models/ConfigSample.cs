namespace ConfigWebApi.Models
{
  using System;
  using System.Data.Entity;
  using System.ComponentModel.DataAnnotations.Schema;
  using System.Linq;

  public partial class ConfigSample : DbContext
  {
    public ConfigSample()
        : base("name=ConfigSample")
    {
    }

    public virtual DbSet<AppSetting> AppSettings { get; set; }

    protected override void OnModelCreating(DbModelBuilder modelBuilder)
    {
      modelBuilder.Entity<AppSetting>()
          .Property(e => e.DefaultPrice)
          .HasPrecision(19, 4);
    }
  }
}
