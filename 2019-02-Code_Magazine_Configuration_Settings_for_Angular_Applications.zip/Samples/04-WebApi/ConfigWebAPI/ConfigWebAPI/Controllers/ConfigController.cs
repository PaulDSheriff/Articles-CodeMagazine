﻿using System;
using System.Linq;
using System.Web.Http;
using ConfigWebApi.Models;

namespace ConfigWebApi.Controllers
{
  public class ConfigController : ApiController
  {
    [HttpGet]
    public IHttpActionResult Get()
    {
      IHttpActionResult ret;
      ConfigSample db = null;
      AppSetting settings = new AppSetting();

      // Retrieve settings from SQL table
      try {
        db = new ConfigSample();

        settings = db.AppSettings.FirstOrDefault();
        if (settings == null) {
          ret = NotFound();
        }
        else {
          ret = Ok(settings);
        }
      }
      catch (Exception) {
        ret = InternalServerError(
            new ApplicationException(
              "Error retrieving settings from AppSettings table."));
      }

      return ret;
    }
  }
}