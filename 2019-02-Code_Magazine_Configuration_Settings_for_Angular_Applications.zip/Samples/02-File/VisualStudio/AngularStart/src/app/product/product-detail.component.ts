﻿import { Component, OnInit } from "@angular/core";

import { Product } from "./product";
import { AppSettingsService, AppSettings } from '../shared/appsettings.service';

@Component({
  selector: "product-detail",
  templateUrl: "./product-detail.component.html"
})
export class ProductDetailComponent implements OnInit {
  constructor(private appSettingsService: AppSettingsService) {
  }

  product: Product;
  settings: AppSettings;

  ngOnInit(): void {
    this.appSettingsService.getSettings()
      .subscribe(settings => this.settings = settings,
      () => null,
      () => {
        this.product = new Product();
        this.product.price = this.settings.defaultPrice;
        this.product.url = this.settings.defaultUrl;
      });
  }

  saveProduct(): void {
    if (this.product) {
      var ret = "Product Name: " +
        this.product.productName +
        " (" + this.product.productId + ")";

      alert(ret);
    }
  }
}