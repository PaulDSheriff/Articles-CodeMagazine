import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Http } from '@angular/http';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { AppSettings } from "./appsettings";

const SETTINGS_LOCATION = "assets/appsettings.json";

@Injectable()
export class AppSettingsService {
  constructor(private http: Http) {
  }

  getSettings(): Observable<AppSettings> {   
    return this.http.get(SETTINGS_LOCATION)
      .map(response => response.json() || {})
      .catch(this.handleErrors);
  }

  private handleErrors(error: any): Observable<AppSettings> {
    // Log the error to the console
    switch (error.status) {
      case 404:
        console.error("Can't find file: " + SETTINGS_LOCATION);
        break;
      default:
        console.error(error);
        break;
    }

    // Return default configuration values
    return Observable.of<AppSettings>(new AppSettings());
  }
}
