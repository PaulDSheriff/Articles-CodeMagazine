﻿The scenario is the \assets\appsettings.json is the original defaults
These settings are then stored into Local Storage
The user can then change the defaults in local storage
The user can always revert back to the defaults by deleting the key in local storage


Changes from last sample
------------------------
Add constant SETTINGS_KEY for local storage key name
Modified getSettings() method to store retrieved values into local storage
Add deleteSettings() method
Add saveSettings() method

Add two buttons on product-detail.component.html
  <button (click)="deleteDefaults()">Delete Defaults</button>
  <button (click)="saveDefaults()">Save Defaults</button>

Added two methods to product-detail.component.ts
  deleteDefaults and saveDefaults