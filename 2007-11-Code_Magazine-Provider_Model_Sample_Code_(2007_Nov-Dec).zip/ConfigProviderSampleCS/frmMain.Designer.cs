namespace DataProviderSampleCS
{
	partial class frmMain
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.lblState = new System.Windows.Forms.Label();
			this.lblEmpType = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.btnRead = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(20, 72);
			this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(100, 20);
			this.label1.TabIndex = 0;
			this.label1.Text = "State Code";
			// 
			// lblState
			// 
			this.lblState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblState.Location = new System.Drawing.Point(184, 72);
			this.lblState.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblState.Name = "lblState";
			this.lblState.Size = new System.Drawing.Size(286, 34);
			this.lblState.TabIndex = 1;
			// 
			// lblEmpType
			// 
			this.lblEmpType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.lblEmpType.Location = new System.Drawing.Point(184, 125);
			this.lblEmpType.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.lblEmpType.Name = "lblEmpType";
			this.lblEmpType.Size = new System.Drawing.Size(286, 34);
			this.lblEmpType.TabIndex = 3;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(20, 125);
			this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(130, 20);
			this.label3.TabIndex = 2;
			this.label3.Text = "Employee Type";
			// 
			// btnRead
			// 
			this.btnRead.Location = new System.Drawing.Point(184, 18);
			this.btnRead.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.btnRead.Name = "btnRead";
			this.btnRead.Size = new System.Drawing.Size(124, 35);
			this.btnRead.TabIndex = 4;
			this.btnRead.Text = "Read Values";
			this.btnRead.UseVisualStyleBackColor = true;
			this.btnRead.Click += new System.EventHandler(this.btnRead_Click);
			// 
			// frmMain
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(585, 182);
			this.Controls.Add(this.btnRead);
			this.Controls.Add(this.lblEmpType);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.lblState);
			this.Controls.Add(this.label1);
			this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
			this.Name = "frmMain";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Configuration Provider Sample";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label lblState;
		private System.Windows.Forms.Label lblEmpType;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button btnRead;

	}
}

