using System;
using System.Collections.Generic;
using System.Text;

using ConfigCommon;

namespace ConfigCommon
{
	public class AppConfig
	{
		private const int DEF_EMPTYPE = -1;

		// Properties for Application
		private static string mstrState = string.Empty;
		private static int mintEmployeeType = DEF_EMPTYPE;

		public static string State
		{
			get 
			{ 
				if (mstrState == string.Empty)
					mstrState = ConfigSettings.GetSetting("State", "");

				return mstrState; 
			}
		}

		public static int EmployeeType
		{
			get 
			{
				if (mintEmployeeType == DEF_EMPTYPE)
					mintEmployeeType = ConfigSettings.GetSetting("EmployeeType", DEF_EMPTYPE);

				return mintEmployeeType; 
			}
		}
	}
}
