using System;
using System.Collections.Generic;
using System.Text;

using System.Configuration;
using Microsoft.Win32;

namespace ConfigCommon
{
	public class RegistryConfigProvider : ConfigProviderBase
	{
		public override string GetSetting(string key, int DefaultValue)
		{
			return GetSetting(key, DefaultValue.ToString());
		}

		public override string GetSetting(string key, string DefaultValue)
		{
			RegistryKey rk = null;
			string strRet = string.Empty;

			rk = Registry.LocalMachine.OpenSubKey(base.Location, true);

			if (rk == null)
			{
				strRet = DefaultValue;
			}
			else
			{
				strRet = rk.GetValue(key, DefaultValue).ToString();
				rk.Close();
			}

			return strRet;
		}
	}
}
