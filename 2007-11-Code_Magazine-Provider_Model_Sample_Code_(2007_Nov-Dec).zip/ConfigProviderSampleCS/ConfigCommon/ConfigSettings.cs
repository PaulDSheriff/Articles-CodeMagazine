using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace ConfigCommon
{
	public class ConfigSettings
	{
		private static ConfigProviderBase ConfigProvider = null;

		private static void InitProvider()
		{
			object section;

			section = ConfigurationManager.GetSection("ConfigSettings");

			ConfigSectionHandler cp = (ConfigSectionHandler)section;

			ConfigProvider = (ConfigProviderBase)Activator.CreateInstance(Type.GetType(cp.Type));
			ConfigProvider.Location = cp.Location;
		}

		public static string GetSetting(string key, string DefaultValue)
		{
			if (ConfigProvider == null)
			{
				InitProvider();
			}

			return ConfigProvider.GetSetting(key, DefaultValue);
		}

		public static int GetSetting(string key, int DefaultValue)
		{
			return Convert.ToInt32(GetSetting(key, DefaultValue.ToString()));
		}
	}
}
