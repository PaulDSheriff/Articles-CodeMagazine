using System;
using System.Collections.Generic;
using System.Text;

using System.Configuration;
using System.Xml;

namespace ConfigCommon
{
	public class XmlConfigProvider : ConfigProviderBase
	{
		public override string GetSetting(string key, int DefaultValue)
		{
			return GetSetting(key, DefaultValue.ToString());
		}

		public override string GetSetting(string key, string DefaultValue)
		{
			XmlDocument xd = null;
			XmlNode xn = null;
			string strQuery;
			string strRet = string.Empty;

			xd = new XmlDocument();
			xd.Load(base.Location);

			strQuery = string.Format(@"/configuration/appSettings/add[@key='{0}']", key);

			xn = xd.SelectSingleNode(strQuery);

			if (xn == null)
			{
				strRet = DefaultValue;
			}
			else
			{
				strRet = xn.Attributes["value"].Value;
			}

			return strRet;
		}
	}
}
