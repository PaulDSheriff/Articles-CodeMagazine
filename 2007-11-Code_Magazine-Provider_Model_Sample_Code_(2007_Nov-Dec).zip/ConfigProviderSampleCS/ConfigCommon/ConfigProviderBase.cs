using System;
using System.Collections.Generic;
using System.Text;

namespace ConfigCommon
{
	public abstract class ConfigProviderBase
	{
		public abstract string GetSetting(string key, string DefaultValue);
		public abstract string GetSetting(string key, int DefaultValue);
		private string mstrLocation = string.Empty;

		public string Location
		{
			get { return mstrLocation; }
			set { mstrLocation = value; }
		}
	}
}
