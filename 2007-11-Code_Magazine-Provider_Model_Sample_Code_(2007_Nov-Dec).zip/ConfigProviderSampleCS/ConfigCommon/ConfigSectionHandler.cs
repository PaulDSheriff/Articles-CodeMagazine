using System;
using System.Collections.Generic;
using System.Text;

using System.Configuration;

namespace ConfigCommon
{
	public class ConfigSectionHandler : ConfigurationSection
	{
		[ConfigurationProperty("type")]
		public string Type
		{
			get { return (string)this["type"]; }
		}

		[ConfigurationProperty("location")]
		public string Location
		{
			get { return (string)this["location"]; }
		}
	}
}
