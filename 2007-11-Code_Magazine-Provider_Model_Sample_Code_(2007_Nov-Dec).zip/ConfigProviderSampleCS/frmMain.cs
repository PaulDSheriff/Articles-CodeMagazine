using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using ConfigCommon;

namespace DataProviderSampleCS
{
	public partial class frmMain : Form
	{
		public frmMain()
		{
			InitializeComponent();
		}

		private void btnRead_Click(object sender, EventArgs e)
		{
			lblState.Text = AppConfig.State;
			lblEmpType.Text = AppConfig.EmployeeType.ToString();
		}
	}
}