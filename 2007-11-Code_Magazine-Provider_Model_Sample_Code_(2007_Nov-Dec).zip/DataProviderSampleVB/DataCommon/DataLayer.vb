Imports System.Configuration

Namespace DataCommon
	Public Class DataLayer
		Public Shared Sub ResetProvider()
			DataProvider = Nothing
		End Sub

#Region "Data Retrieval Methods"
		Public Shared Function GetDataSet(ByVal SQL As String, _
		 ByVal ConnectString As String) As DataSet
			Dim ds As New DataSet
			Dim da As IDbDataAdapter

			' Create Data Adapter
			da = CreateDataAdapter(SQL, ConnectString)

			da.Fill(ds)

			Return ds
		End Function
#End Region

#Region "Create Connection/Command/Parameter/DataAdapter Objects"
		Private Shared DataProvider As IDataProvider = Nothing

		Private Shared Sub InitProvider()
			Dim TypeName As String
			Dim ProviderName As String

			If DataProvider Is Nothing Then
				' Get Provider Name
				ProviderName = ConfigurationManager.AppSettings("ProviderName")
				' Get Type to Create
				TypeName = ConfigurationManager.AppSettings(ProviderName)
				' Create new DataProvider
				DataProvider = CType(Activator.CreateInstance(Type.GetType(TypeName)), IDataProvider)
			End If
		End Sub

		Public Shared Function CreateConnection(ByVal ConnectString As String) As IDbConnection
			Dim cnn As IDbConnection

			' Make Sure Provider is Created
			InitProvider()

			cnn = DataProvider.CreateConnection()
			cnn.ConnectionString = ConnectString

			Return cnn
		End Function

		Public Shared Function CreateCommand(ByVal SQL As String) As IDbCommand
			Dim cmd As IDbCommand

			' Make Sure Provider is Created
			InitProvider()

			cmd = DataProvider.CreateCommand()

			cmd.CommandText = SQL

			Return cmd
		End Function

		Public Shared Function CreateCommand(ByVal SQL As String, ByVal ConnectString As String) As IDbCommand
			Return CreateCommand(SQL, ConnectString, True)
		End Function

		Public Shared Function CreateCommand(ByVal SQL As String, ByVal ConnectString As String, ByVal OpenConnection As Boolean) As IDbCommand
			Dim cmd As IDbCommand


			' Make Sure Provider is Created
			InitProvider()

			cmd = CreateCommand(SQL)

			cmd.Connection = CreateConnection(ConnectString)
			If OpenConnection Then
				cmd.Connection.Open()
			End If

			Return cmd
		End Function

		Public Shared Function CreateDataAdapter(ByVal SQL As String, ByVal ConnectString As String) As IDbDataAdapter
			Dim da As IDbDataAdapter

			' Make Sure Provider is Created
			InitProvider()

			da = DataProvider.CreateDataAdapter()

			da.SelectCommand = CreateCommand(SQL, ConnectString, False)

			Return da
		End Function
#End Region

  End Class
End Namespace