Imports System.Data.OleDb

Namespace DataCommon
	Public Class OleDbDataProvider
		Implements IDataProvider

#Region "OLE DB Specific Methods"
		' The following methods Use OleDb
		Public Function CreateConnection() As IDbConnection Implements IDataProvider.CreateConnection
			Dim cnn As New OleDbConnection

			Return cnn
		End Function

		Public Function CreateCommand() As IDbCommand Implements IDataProvider.CreateCommand
			Dim cmd As New OleDbCommand

			Return cmd
		End Function

		Public Function CreateDataAdapter() As IDbDataAdapter Implements IDataProvider.CreateDataAdapter
			Dim da As New OleDbDataAdapter

			Return da
		End Function
#End Region
	End Class
End Namespace
