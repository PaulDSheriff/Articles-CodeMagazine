Imports DataProviderSampleVB.DataCommon

Public Class frmMain
	Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
		GridLoad()
	End Sub

	Private Sub GridLoad()
    Dim SQL As String = "SELECT * FROM tblProducts"

		grdCust.DataSource = _
		 DataLayer.GetDataSet(SQL, AppConfig.ConnectString).Tables(0)
	End Sub
End Class
