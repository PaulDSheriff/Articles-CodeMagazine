using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using DataCommon;

namespace DataProviderSampleCS
{
	public partial class frmMain : Form
	{
		public frmMain()
		{
			InitializeComponent();
		}

		private void frmMain_Load(object sender, EventArgs e)
		{
			GridLoad();
		}

		private void GridLoad()
		{
			string SQL = "SELECT * FROM tblProducts";

			grdCust.DataSource = 
				DataLayer.GetDataSet(SQL, AppConfig.ConnectString).Tables[0];
		}
	}
}