using System;
using System.Data;
using System.Data.OleDb;

namespace DataCommon
{
	class OleDbDataProvider : IDataProvider
	{
		#region "OLE DB Specific Methods"
		// The following methods use the OLE DB Provider
		public IDbConnection CreateConnection()
		{
			OleDbConnection cnn = new OleDbConnection();

			return cnn;
		}

		public IDbCommand CreateCommand()
		{
			OleDbCommand cmd = new OleDbCommand();

			return cmd;
		}

		public IDbDataAdapter CreateDataAdapter()
		{
			OleDbDataAdapter da = new OleDbDataAdapter();

			return da;
		}
		#endregion
	}
}
