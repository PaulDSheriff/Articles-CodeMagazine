Imports System.Configuration

Namespace ConfigCommon
	Public Class ConfigSectionHandler
		Inherits ConfigurationSection

		<ConfigurationProperty("type")> _
		 Public ReadOnly Property Type() As String
			Get
				Return MyBase.Item("type").ToString()
			End Get
		End Property

		<ConfigurationProperty("location")> _
		Public ReadOnly Property Location() As String
			Get
				Return MyBase.Item("location").ToString()
			End Get
		End Property
	End Class
End Namespace
