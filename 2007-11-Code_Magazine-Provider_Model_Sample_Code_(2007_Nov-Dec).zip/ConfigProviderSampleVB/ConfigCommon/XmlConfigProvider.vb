Imports System.Configuration
Imports System.Xml

Namespace ConfigCommon
	Public Class XmlConfigProvider
		Inherits ConfigProviderBase

		Public Overrides Function GetSetting(ByVal key As String, ByVal DefaultValue As Integer) As String
			Return GetSetting(key, DefaultValue.ToString())
		End Function

		Public Overrides Function GetSetting(ByVal key As String, ByVal DefaultValue As String) As String
			Dim xd As XmlDocument = Nothing
			Dim xn As XmlNode = Nothing
			Dim strQuery As String
			Dim strRet As String = String.Empty

			xd = New XmlDocument()
			xd.Load(MyBase.Location)

			strQuery = String.Format("/configuration/appSettings/add[@key='{0}']", key)

			xn = xd.SelectSingleNode(strQuery)

			If xn Is Nothing Then
				strRet = DefaultValue
			Else
				strRet = xn.Attributes("value").Value
			End If

			Return strRet
		End Function
	End Class
End Namespace
