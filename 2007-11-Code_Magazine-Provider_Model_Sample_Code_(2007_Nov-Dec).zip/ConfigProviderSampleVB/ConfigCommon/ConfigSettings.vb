Imports System.Configuration

Namespace ConfigCommon
	Public Class ConfigSettings
		Private Shared ConfigProvider As ConfigProviderBase = Nothing

		Private Shared Sub InitProvider()
			Dim section As Object
			Dim cp As ConfigSectionHandler

			section = ConfigurationManager.GetSection("ConfigSettings")

			cp = CType(section, ConfigSectionHandler)

			If ConfigProvider Is Nothing Then
				' Create new Configuration Provider
				ConfigProvider = CType(Activator.CreateInstance(Type.GetType(cp.Type)), ConfigProviderBase)
				ConfigProvider.Location = cp.Location
			End If
		End Sub

		Public Shared Function GetSetting(ByVal key As String, ByVal DefaultValue As String) As String
			If ConfigProvider Is Nothing Then
				InitProvider()
			End If

			Return ConfigProvider.GetSetting(key, DefaultValue)
		End Function

		Public Shared Function GetSetting(ByVal Key As String, ByVal DefaultValue As Integer) As Integer
			Return Convert.ToInt32(GetSetting(Key, DefaultValue.ToString()))
		End Function
	End Class
End Namespace
