
Namespace ConfigCommon
	Public Class AppConfig
		Private Const DEF_EMPTYPE As Integer = -1

		Private Shared mstrState As String = String.Empty
		Private Shared mintEmployeeType As Integer = DEF_EMPTYPE

		Public Shared ReadOnly Property State() As String
			Get
				If mstrState = String.Empty Then
					mstrState = ConfigSettings.GetSetting("State", "")
				End If

				Return mstrState
			End Get

		End Property

		Public Shared ReadOnly Property EmployeeType() As Integer
			Get
				If mintEmployeeType = DEF_EMPTYPE Then
					mintEmployeeType = ConfigSettings.GetSetting("EmployeeType", DEF_EMPTYPE)
				End If

				Return mintEmployeeType
			End Get

		End Property
	End Class
End Namespace
