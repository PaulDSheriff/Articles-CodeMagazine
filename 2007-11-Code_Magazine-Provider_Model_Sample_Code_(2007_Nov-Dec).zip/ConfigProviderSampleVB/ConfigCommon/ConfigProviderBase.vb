Namespace ConfigCommon
	Public MustInherit Class ConfigProviderBase
		Public MustOverride Function GetSetting(ByVal key As String, ByVal DefaultValue As Integer) As String
		Public MustOverride Function GetSetting(ByVal key As String, ByVal DefaultValue As String) As String

		Private mstrLocation As String

		Public Property Location() As String
			Get
				Return mstrLocation
			End Get
			Set(ByVal value As String)
				mstrLocation = value
			End Set
		End Property
	End Class
End Namespace