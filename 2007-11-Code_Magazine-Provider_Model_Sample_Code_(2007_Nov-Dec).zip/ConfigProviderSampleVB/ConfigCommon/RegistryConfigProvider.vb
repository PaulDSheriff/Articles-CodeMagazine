Imports Microsoft.Win32
Imports System.Configuration

Namespace ConfigCommon
	Public Class RegistryConfigProvider
		Inherits ConfigProviderBase

		Public Overrides Function GetSetting(ByVal key As String, ByVal DefaultValue As Integer) As String
			Return GetSetting(key, DefaultValue.ToString())
		End Function

		Public Overrides Function GetSetting(ByVal key As String, ByVal DefaultValue As String) As String
			Dim rk As RegistryKey = Nothing
			Dim strRet As String = String.Empty

			rk = Registry.LocalMachine.OpenSubKey(MyBase.Location, True)

			If rk Is Nothing Then
				strRet = DefaultValue
			Else
				strRet = rk.GetValue(key, DefaultValue).ToString()
				rk.Close()
			End If

			Return strRet
		End Function
	End Class
End Namespace
