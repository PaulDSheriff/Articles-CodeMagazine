<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
	Inherits System.Windows.Forms.Form

	'Form overrides dispose to clean up the component list.
	<System.Diagnostics.DebuggerNonUserCode()> _
	Protected Overrides Sub Dispose(ByVal disposing As Boolean)
		If disposing AndAlso components IsNot Nothing Then
			components.Dispose()
		End If
		MyBase.Dispose(disposing)
	End Sub

	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer

	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.  
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> _
	Private Sub InitializeComponent()
		Me.btnRead = New System.Windows.Forms.Button
		Me.lblEmpType = New System.Windows.Forms.Label
		Me.label3 = New System.Windows.Forms.Label
		Me.lblState = New System.Windows.Forms.Label
		Me.label1 = New System.Windows.Forms.Label
		Me.SuspendLayout()
		'
		'btnRead
		'
		Me.btnRead.Location = New System.Drawing.Point(182, 18)
		Me.btnRead.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
		Me.btnRead.Name = "btnRead"
		Me.btnRead.Size = New System.Drawing.Size(124, 35)
		Me.btnRead.TabIndex = 9
		Me.btnRead.Text = "Read Values"
		Me.btnRead.UseVisualStyleBackColor = True
		'
		'lblEmpType
		'
		Me.lblEmpType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.lblEmpType.Location = New System.Drawing.Point(182, 125)
		Me.lblEmpType.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		Me.lblEmpType.Name = "lblEmpType"
		Me.lblEmpType.Size = New System.Drawing.Size(286, 34)
		Me.lblEmpType.TabIndex = 8
		'
		'label3
		'
		Me.label3.AutoSize = True
		Me.label3.Location = New System.Drawing.Point(17, 125)
		Me.label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		Me.label3.Name = "label3"
		Me.label3.Size = New System.Drawing.Size(130, 20)
		Me.label3.TabIndex = 7
		Me.label3.Text = "Employee Type"
		'
		'lblState
		'
		Me.lblState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
		Me.lblState.Location = New System.Drawing.Point(182, 72)
		Me.lblState.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		Me.lblState.Name = "lblState"
		Me.lblState.Size = New System.Drawing.Size(286, 34)
		Me.lblState.TabIndex = 6
		'
		'label1
		'
		Me.label1.AutoSize = True
		Me.label1.Location = New System.Drawing.Point(17, 72)
		Me.label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
		Me.label1.Name = "label1"
		Me.label1.Size = New System.Drawing.Size(100, 20)
		Me.label1.TabIndex = 5
		Me.label1.Text = "State Code"
		'
		'frmMain
		'
		Me.AutoScaleDimensions = New System.Drawing.SizeF(10.0!, 20.0!)
		Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
		Me.ClientSize = New System.Drawing.Size(533, 195)
		Me.Controls.Add(Me.btnRead)
		Me.Controls.Add(Me.lblEmpType)
		Me.Controls.Add(Me.label3)
		Me.Controls.Add(Me.lblState)
		Me.Controls.Add(Me.label1)
		Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
		Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
		Me.Name = "frmMain"
		Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
		Me.Text = "Configuration Provider Sample"
		Me.ResumeLayout(False)
		Me.PerformLayout()

	End Sub
	Private WithEvents btnRead As System.Windows.Forms.Button
	Private WithEvents lblEmpType As System.Windows.Forms.Label
	Private WithEvents label3 As System.Windows.Forms.Label
	Private WithEvents lblState As System.Windows.Forms.Label
	Private WithEvents label1 As System.Windows.Forms.Label

End Class
