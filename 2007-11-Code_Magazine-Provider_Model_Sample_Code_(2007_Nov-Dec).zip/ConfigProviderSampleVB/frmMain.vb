Imports ConfigProviderSampleVB.ConfigCommon

Public Class frmMain
	Private Sub btnRead_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRead.Click
		lblState.Text = AppConfig.State
		lblEmpType.Text = AppConfig.EmployeeType.ToString()
	End Sub
End Class
