namespace AdventureWorks.MAUI.Views;

public partial class UserDetailView : ContentPage
{
	public UserDetailView()
	{
		InitializeComponent();
	}

  private void SaveButton_Clicked(object sender, EventArgs e) {
    // TODO: Respond to the event here
  }
}