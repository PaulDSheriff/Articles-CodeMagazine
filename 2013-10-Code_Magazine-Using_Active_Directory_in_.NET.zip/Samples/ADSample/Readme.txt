﻿Add References to System.DirectoryServices and System.DirectoryServices.AccountManagement

Active Directory is a database based system that provides authentication, directory, policy, and other services in a Windows environment

LDAP (Lightweight Directory Access Protocol) is an application protocol for querying and modifying items in directory service providers like Active Directory, which supports a form of LDAP.

Short answer: AD is a directory services database, and LDAP is one of the protocols you can use to talk to it.

LDAP is a standard, AD is Microsoft's (proprietary) implementation (and more). Wikipedia has a good article that delves into the specifics. I found this document with a very detailed evaluation of AD from an LDAP perspective.

LDAP is a protocol specification for directory data.

Active Directory is Microsoft's Implementation of an LDAP based directory server.

AD also has custom extensions ontop of the LDAP v3 spec such as account lockout, password expiration, etc.
