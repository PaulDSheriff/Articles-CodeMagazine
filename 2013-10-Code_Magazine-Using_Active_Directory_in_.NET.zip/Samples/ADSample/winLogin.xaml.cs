﻿using System;
using System.DirectoryServices;
using System.Windows;

namespace ADSample
{
  public partial class winLogin : Window
  {
    public winLogin()
    {
      InitializeComponent();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
      txtDomain.Text = Environment.UserDomainName;
    }

    private void btnCancel_Click(object sender, RoutedEventArgs e)
    {
      DialogResult = false;
    }

    private void btnLogin_Click(object sender, RoutedEventArgs e)
    {
      // Authenticate user
      if (AuthenticateUser(txtDomain.Text,
                    txtUserName.Text,
                    txtPassword.Password))
        DialogResult = true;
      else
        MessageBox.Show("Unable to Authenticate Using the Supplied Credentials");
    }

    private bool AuthenticateUser(string domainName, string userName, string password)
    {
      bool ret = false;

      try
      {
        DirectoryEntry de = new DirectoryEntry("LDAP://" + domainName,
                            userName, password);
        DirectorySearcher dsearch = new DirectorySearcher(de);
        SearchResult results = null;

        results = dsearch.FindOne();

        ret = true;
      }
      catch
      {
        ret = false;
      }

      return ret;
    }
  }
}
