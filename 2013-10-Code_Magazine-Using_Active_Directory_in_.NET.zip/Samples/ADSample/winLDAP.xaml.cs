﻿using System;
using System.Diagnostics;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Windows;

namespace ADSample
{
  public partial class winLDAP : Window
  {
    public winLDAP()
    {
      InitializeComponent();
    }

    #region Domain Methods
    private void btnCurrentDomain_Click(object sender, RoutedEventArgs e)
    {
      // Get Current Domain
      MessageBox.Show(GetCurrentDomainPath());
    }

    private string GetCurrentDomainPath()
    {
      DirectoryEntry de = new DirectoryEntry("LDAP://RootDSE");

      return "LDAP://" + de.Properties["defaultNamingContext"][0].ToString();
    }

    private void btnDomainName_Click(object sender, RoutedEventArgs e)
    {
      MessageBox.Show(Environment.UserDomainName);
    }
    #endregion

    #region User Methods
    private void btnGetUsers_Click(object sender, RoutedEventArgs e)
    {
      GetAllUsers();
    }

    private void GetAllUsers()
    {
      SearchResultCollection results;
      DirectorySearcher ds = null;
      DirectoryEntry de = new DirectoryEntry(GetCurrentDomainPath());

      ds = new DirectorySearcher(de);
      ds.Filter = "(&(objectCategory=User)(objectClass=person))";

      results = ds.FindAll();

      foreach (SearchResult sr in results)
      {
        Debug.WriteLine(sr.Properties["name"][0].ToString());
        // The following is NOT available
        // Debug.WriteLine(sr.Properties["mail"][0].ToString());
      }
    }

    private void btnGetUserInfo_Click(object sender, RoutedEventArgs e)
    {
      GetAdditionalUserInfo();
    }

    private void GetAdditionalUserInfo()
    {
      SearchResultCollection results;
      DirectorySearcher ds = null;
      DirectoryEntry de = new DirectoryEntry(GetCurrentDomainPath());

      ds = new DirectorySearcher(de);
      // Full Name
      ds.PropertiesToLoad.Add("name");
      // Email Address
      ds.PropertiesToLoad.Add("mail");
      // First Name
      ds.PropertiesToLoad.Add("givenname");
      // Last Name (Surname)
      ds.PropertiesToLoad.Add("sn");
      // Login Name
      ds.PropertiesToLoad.Add("userPrincipalName");
      // Distinguished Name
      ds.PropertiesToLoad.Add("distinguishedName");

      ds.Filter = "(&(objectCategory=User)(objectClass=person))";

      results = ds.FindAll();

      foreach (SearchResult sr in results)
      {
        if (sr.Properties["name"].Count > 0)
          Debug.WriteLine(sr.Properties["name"][0].ToString());
        // If not filled in, then you will get an error
        if (sr.Properties["mail"].Count > 0)
          Debug.WriteLine(sr.Properties["mail"][0].ToString());
        if (sr.Properties["givenname"].Count > 0)
          Debug.WriteLine(sr.Properties["givenname"][0].ToString());
        if (sr.Properties["sn"].Count > 0)
          Debug.WriteLine(sr.Properties["sn"][0].ToString());
        if (sr.Properties["userPrincipalName"].Count > 0)
          Debug.WriteLine(sr.Properties["userPrincipalName"][0].ToString());
        if (sr.Properties["distinguishedName"].Count > 0)
          Debug.WriteLine(sr.Properties["distinguishedName"][0].ToString());
      }
    }

    private DirectorySearcher BuildUserSearcher(DirectoryEntry de)
    {
      DirectorySearcher ds = null;

      ds = new DirectorySearcher(de);
      // Full Name
      ds.PropertiesToLoad.Add("name");
      // Email Address
      ds.PropertiesToLoad.Add("mail");
      // First Name
      ds.PropertiesToLoad.Add("givenname");
      // Last Name (Surname)
      ds.PropertiesToLoad.Add("sn");
      // Login Name
      ds.PropertiesToLoad.Add("userPrincipalName");
      // Distinguished Name
      ds.PropertiesToLoad.Add("distinguishedName");

      return ds;
    }

    private void btnSearchUsers_Click(object sender, RoutedEventArgs e)
    {
      SearchForUsers(txtSearch.Text);
    }

    private void SearchForUsers(string userName)
    {
      SearchResultCollection results;
      DirectorySearcher ds = null;
      DirectoryEntry de = new DirectoryEntry(GetCurrentDomainPath());

      // Build User Searcher
      ds = BuildUserSearcher(de);

      ds.Filter = "(&(objectCategory=User)(objectClass=person)(name=" + userName + "*))";

      results = ds.FindAll();

      foreach (SearchResult sr in results)
      {
        Debug.WriteLine(sr.GetPropertyValue("name"));
        Debug.WriteLine(sr.GetPropertyValue("mail"));
        Debug.WriteLine(sr.GetPropertyValue("givenname"));
        Debug.WriteLine(sr.GetPropertyValue("sn"));
        Debug.WriteLine(sr.GetPropertyValue("userPrincipalName"));
        Debug.WriteLine(sr.GetPropertyValue("distinguishedName"));
      }
    }

    private void btnGetAUser_Click(object sender, RoutedEventArgs e)
    {
      GetAUser(txtSearch.Text);
    }

    private void GetAUser(string userName)
    {
      DirectorySearcher ds = null;
      DirectoryEntry de = new
        DirectoryEntry(GetCurrentDomainPath());
      SearchResult sr;

      // Build User Searcher
      ds = BuildUserSearcher(de);

      // Set the filter to look for a specific user
      ds.Filter = "(&(objectCategory=User)(objectClass=person)(name=" + userName + ")";

      sr = ds.FindOne();

      if (sr != null)
      {
        Debug.WriteLine(sr.GetPropertyValue("name"));
        Debug.WriteLine(sr.GetPropertyValue("mail"));
        Debug.WriteLine(sr.GetPropertyValue("givenname"));
        Debug.WriteLine(sr.GetPropertyValue("sn"));
        Debug.WriteLine(sr.GetPropertyValue("userPrincipalName"));
        Debug.WriteLine(sr.GetPropertyValue("distinguishedName"));
      }
    }
    #endregion

    #region Group Methods
    private void btnGetGroups_Click(object sender, RoutedEventArgs e)
    {
      GetAllGroups();
    }

    private void GetAllGroups()
    {
      SearchResultCollection results;
      DirectorySearcher ds = null;
      DirectoryEntry de = new DirectoryEntry(GetCurrentDomainPath());

      ds = new DirectorySearcher(de);
      // Sort by name
      ds.Sort = new SortOption("name", SortDirection.Ascending);
      ds.PropertiesToLoad.Add("name");
      ds.PropertiesToLoad.Add("memberof");
      ds.PropertiesToLoad.Add("member");

      ds.Filter = "(&(objectCategory=Group))";

      results = ds.FindAll();

      foreach (SearchResult sr in results)
      {
        if (sr.Properties["name"].Count > 0)
          Debug.WriteLine(sr.Properties["name"][0].ToString());

        if (sr.Properties["memberof"].Count > 0)
        {
          Debug.WriteLine("  Member of...");
          foreach (string item in sr.Properties["memberof"])
          {
            Debug.WriteLine("    " + item);
          }
        }
        if (sr.Properties["member"].Count > 0)
        {
          Debug.WriteLine("  Members");
          foreach (string item in sr.Properties["member"])
          {
            Debug.WriteLine("    " + item);
          }
        }
      }
    }
    #endregion
  }
}
