﻿using System.Diagnostics;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Windows;

namespace ADSample
{
  public partial class winAccountMgmt : Window
  {
    public winAccountMgmt()
    {
      InitializeComponent();
    }

    #region GetCurrentDomainPath Method
    // Using the same here as the Account Management objects do not make this easy
    private string GetCurrentDomainPath()
    {
      DirectoryEntry de = new DirectoryEntry("LDAP://RootDSE");

      return de.Properties["defaultNamingContext"][0].ToString();
    }
    #endregion

    private void btnGetUsers_Click(object sender, RoutedEventArgs e)
    {
      PrincipalContext domainContext = new PrincipalContext(ContextType.Domain);
      UserPrincipal up = new UserPrincipal(domainContext);
      PrincipalSearcher searcher = new PrincipalSearcher(up);

      PrincipalSearchResult<Principal> result = searcher.FindAll();
      foreach (Principal item in result)
      {
        Debug.WriteLine(item.Name);
      }
    }
  }
}
