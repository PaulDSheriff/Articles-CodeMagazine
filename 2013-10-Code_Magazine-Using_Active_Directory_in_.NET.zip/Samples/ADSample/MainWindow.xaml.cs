﻿using System;
using System.Windows;

namespace ADSample
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();
    }

    private void btnLDAP_Click(object sender, RoutedEventArgs e)
    {
      winLDAP win = new winLDAP();

      win.Show();
    }

    private void btnAccountManagement_Click(object sender, RoutedEventArgs e)
    {
      winAccountMgmt win = new winAccountMgmt();

      win.Show();
    }

    private void btnLogin_Click(object sender, RoutedEventArgs e)
    {
      winLogin win = new winLogin();

      win.Owner = this;
      win.ShowDialog();
      if (win.DialogResult.HasValue && win.DialogResult.Value)
        MessageBox.Show("User Logged In");
      else
        MessageBox.Show("User NOT Logged In");
    }
  }
}
