﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;
using HTMLTableSamples.EntityClasses;

namespace HTMLTableSamples
{
  public class ProductController : ApiController
  {
    #region Get Method
    // GET api/<controller>
    [HttpGet()]
    public IHttpActionResult Get() {
      IHttpActionResult ret = null;
      List<Product> list = new List<Product>();

      // Test a 500 exception
      //int x = 0;
      //int y = 10;
      //int z;

      //z = y / x;

      list = CreateMockData();
      if (list.Count > 0) {
        ret = Ok(list);
      }
      else {
        ret = NotFound();
      }

      return ret;
    }
    #endregion

    #region CreateMockData Method
    private List<Product> CreateMockData() {
      List<Product> ret = new List<Product>();

      ret.Add(new Product() {
        ProductId = 1,
        ProductName = "Extending Bootstrap with CSS, JavaScript and jQuery",
        IntroductionDate = Convert.ToDateTime("6/11/2015"),
        Url = "http://bit.ly/1SNzc0i",
        Price = Convert.ToDecimal(10.95)
      });

      ret.Add(new Product() {
        ProductId = 2,
        ProductName = "Build your own Bootstrap Business Application Template in MVC",
        IntroductionDate = Convert.ToDateTime("1/29/2015"),
        Url = "http://bit.ly/1I8ZqZg",
        Price = Convert.ToDecimal(10.95)
      });

      ret.Add(new Product() {
        ProductId = 3,
        ProductName = "Building Mobile Web Sites Using Web Forms, Bootstrap, and HTML5",
        IntroductionDate = Convert.ToDateTime("8/28/2014"),
        Url = "http://bit.ly/1J2dcrj",
        Price = Convert.ToDecimal(10.95)
      });

      return ret;
    }
    #endregion

    #region Get(id) Method
    // GET api/<controller>/5
    [HttpGet()]
    public IHttpActionResult Get(int id) {
      IHttpActionResult ret;
      List<Product> list = new List<Product>();
      Product prod = new Product();

      list = CreateMockData();
      prod = list.Find(p => p.ProductId == id);
      if (prod == null) {
        ret = NotFound();
      }
      else {
        ret = Ok(prod);
      }

      return ret;
    }
    #endregion

    #region Post Method
    // POST api/<controller>
    [HttpPost()]
    public IHttpActionResult Post(Product product) {
      IHttpActionResult ret = null;

      if (Add(product)) {
        ret = Created<Product>(Request.RequestUri +
                                  product.ProductId.ToString(),
                                  product);
      }
      else {
        ret = InternalServerError();
      }

      return ret;
    }
    #endregion

    #region Add Method
    private bool Add(Product product) {
      int newId = 0;
      List<Product> list = new List<Product>();

      list = CreateMockData();
      // Get the last id
      newId = list.Max(p => p.ProductId);
      newId++;
      product.ProductId = newId;
      // Add to list
      list.Add(product);

      // TODO: Change this to false to test the NotFound()
      return true;
    }
    #endregion

    #region Put Method
    // PUT api/<controller>/5
    [HttpPut()]
    public IHttpActionResult Put(int id, Product product) {
      IHttpActionResult ret = null;

      if (Exists(id)) {
        if (Update(product)) {
          ret = Ok(product);
        }
        else {
          return InternalServerError();
        }
      }
      else {
        ret = NotFound();
      }

      return ret;
    }
    #endregion

    #region Update Method
    private bool Update(Product product) {
      return true;
    }
    #endregion

    #region Exists Method
    private bool Exists(int id) {
      return true;
    }
    #endregion

    #region Delete Method
    // DELETE api/<controller>/5
    [HttpDelete()]
    public IHttpActionResult Delete(int id) {
      IHttpActionResult ret = null;

      if (Exists(id)) {
        if (DeleteProduct(id)) {
          ret = Ok(true);
        }
        else {
          ret = InternalServerError();
        }
      }
      else {
        ret = NotFound();
      }

      return ret;
    }
    #endregion

    #region DeleteProduct Method
    private bool DeleteProduct(int id) {
      return true;
    }
    #endregion
  }
}