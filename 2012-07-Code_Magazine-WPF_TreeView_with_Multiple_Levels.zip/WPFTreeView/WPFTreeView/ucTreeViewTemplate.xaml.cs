﻿using System.Windows.Controls;

namespace WPFTreeView
{
  public partial class ucTreeViewTemplate : UserControl
  {
    public ucTreeViewTemplate()
    {
      InitializeComponent();
    }
  }
}
