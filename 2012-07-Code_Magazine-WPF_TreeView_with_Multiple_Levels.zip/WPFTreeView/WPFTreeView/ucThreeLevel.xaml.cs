﻿using System.Windows;
using System.Windows.Controls;

namespace WPFTreeView
{
  public partial class ucThreeLevel : UserControl
  {
    public ucThreeLevel()
    {
      InitializeComponent();
    }

    private void tvEmps_SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
    {
      object current;

      current = tvEmps.SelectedItem;
      switch (current.GetType().Name.ToLower())
      {
        case "employee":
          break;
        case "employeetype":
          break;
        case "subemployee":
          break;
        default:
          break;
      }
    }
  }
}
