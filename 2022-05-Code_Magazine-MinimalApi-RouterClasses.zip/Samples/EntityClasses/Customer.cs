#nullable disable

namespace AdvWorksAPI {
  public partial class Customer {
    public int CustomerID { get; set; }
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string CompanyName { get; set; }
    public string EmailAddress { get; set; }
  }
}
